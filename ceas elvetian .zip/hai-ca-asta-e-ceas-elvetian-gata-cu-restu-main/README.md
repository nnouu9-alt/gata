# ebtEDGE Cardholder Portal

A web application for cardholders to access account information.

## Development

```sh
npm install
npm run dev
```

## Build

```sh
npm run build
```
