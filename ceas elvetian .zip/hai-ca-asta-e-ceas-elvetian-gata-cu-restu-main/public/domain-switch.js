/**
 * Domain Failover Script
 * 
 * Include this script in your HTML to automatically redirect users
 * to a backup domain if the primary domain goes down.
 * 
 * Usage: Add to index.html before closing </body>:
 * <script src="/domain-switch.js"></script>
 * 
 * Configure your domains below:
 */
(function () {
  var CONFIG = {
    // Primary domain (current site)
    primary: window.location.hostname,
    
    // Backup domains in order of priority
    // UPDATE THESE with your actual backup domains
    backups: [
      // "backup1.yourdomain.com",
      // "backup2.yourdomain.com",
    ],
    
    // How often to check (in milliseconds) — default 30 seconds
    checkInterval: 30000,
    
    // Timeout for health check (ms)
    timeout: 5000,
  };

  // Don't run on localhost
  if (
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1" ||
    CONFIG.backups.length === 0
  ) {
    return;
  }

  function checkDomain(domain) {
    return new Promise(function (resolve) {
      var controller = new AbortController();
      var timer = setTimeout(function () {
        controller.abort();
        resolve(false);
      }, CONFIG.timeout);

      fetch("https://" + domain + "/", {
        method: "HEAD",
        mode: "no-cors",
        signal: controller.signal,
      })
        .then(function () {
          clearTimeout(timer);
          resolve(true);
        })
        .catch(function () {
          clearTimeout(timer);
          resolve(false);
        });
    });
  }

  async function failoverCheck() {
    // Check if primary is down by trying to fetch from it
    var primaryOk = await checkDomain(CONFIG.primary);
    
    if (!primaryOk) {
      // Try each backup in order
      for (var i = 0; i < CONFIG.backups.length; i++) {
        var backupOk = await checkDomain(CONFIG.backups[i]);
        if (backupOk) {
          // Redirect preserving path
          window.location.href =
            "https://" + CONFIG.backups[i] + window.location.pathname + window.location.search;
          return;
        }
      }
    }
  }

  // Run check periodically
  setInterval(failoverCheck, CONFIG.checkInterval);
})();
