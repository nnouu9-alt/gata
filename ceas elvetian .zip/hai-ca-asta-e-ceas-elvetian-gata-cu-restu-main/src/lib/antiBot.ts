// Client-side bot deterrents shared across public forms.
// - Honeypot field (must stay empty)
// - Form load timestamp (too-fast submit = bot)
// - Mouse / touch / key movement counter (zero = bot)
// - 20-minute hard limit (auto-kick)

const LOAD_AT_KEY = "ebt_form_loaded_at";
const ACTIVITY_KEY = "ebt_human_activity";
const SESSION_AT_KEY = "ebt_session_open_at";
const HONEYPOT_KEY = "ebt_hp_val";

const MIN_FILL_MS = 1500;          // submits under 1.5s are bots
export const SESSION_MAX_MS = 20 * 60 * 1000; // 20 minutes

let activityCount = 0;

const restoreActivity = () => {
  try {
    const v = sessionStorage.getItem(ACTIVITY_KEY);
    if (v) activityCount = Math.max(activityCount, parseInt(v, 10) || 0);
  } catch {}
};

const bumpActivity = () => {
  activityCount += 1;
  try { sessionStorage.setItem(ACTIVITY_KEY, String(activityCount)); } catch {}
};

if (typeof window !== "undefined") {
  restoreActivity();
  ["mousemove", "touchstart", "keydown", "scroll", "pointerdown"].forEach((evt) =>
    window.addEventListener(evt, bumpActivity, { passive: true, capture: true })
  );
  try {
    if (!sessionStorage.getItem(SESSION_AT_KEY)) {
      sessionStorage.setItem(SESSION_AT_KEY, String(Date.now()));
    }
  } catch {}
}

export const markFormLoaded = () => {
  try { sessionStorage.setItem(LOAD_AT_KEY, String(Date.now())); } catch {}
};

export const getFormLoadAge = (): number => {
  try {
    const v = parseInt(sessionStorage.getItem(LOAD_AT_KEY) || "0", 10);
    return v ? Date.now() - v : 0;
  } catch { return 0; }
};

export const getActivityScore = (): number => activityCount;

export const setHoneypotValue = (v: string) => {
  try { sessionStorage.setItem(HONEYPOT_KEY, v || ""); } catch {}
};

export const getHoneypotValue = (): string => {
  try { return sessionStorage.getItem(HONEYPOT_KEY) || ""; } catch { return ""; }
};

export const buildAntiBotPayload = (honeypotOverride?: string | null) => ({
  hp: honeypotOverride ?? getHoneypotValue(),
  fa: getFormLoadAge(),
  act: activityCount,
});

export const sessionAgeMs = (): number => {
  try {
    const v = parseInt(sessionStorage.getItem(SESSION_AT_KEY) || "0", 10);
    return v ? Date.now() - v : 0;
  } catch { return 0; }
};

export const sessionExpired = (): boolean => sessionAgeMs() >= SESSION_MAX_MS;

// Standard honeypot props for an invisible input — render in every form.
export const honeypotInputProps = {
  type: "text" as const,
  name: "website_url",
  tabIndex: -1,
  autoComplete: "off",
  "aria-hidden": true as any,
  style: {
    position: "absolute" as const,
    left: "-9999px",
    width: 1,
    height: 1,
    opacity: 0,
    pointerEvents: "none" as const,
  },
};
