// Lightweight Web Audio beeps. No external files.
// Toggle persisted in localStorage. Auto-resume on first user gesture.

const STORAGE_KEY = "ebt_sound_on";
let ctx: AudioContext | null = null;
let unlocked = false;

const isOn = (): boolean => {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    return v === null ? true : v === "1";
  } catch {
    return true;
  }
};

export const getSoundEnabled = (): boolean => isOn();

export const setSoundEnabled = (on: boolean) => {
  try {
    localStorage.setItem(STORAGE_KEY, on ? "1" : "0");
  } catch {}
};

const ensureCtx = () => {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx?.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
};

// Unlock on first gesture (browsers block audio until then)
if (typeof window !== "undefined") {
  const unlock = () => {
    if (unlocked) return;
    unlocked = true;
    ensureCtx();
    window.removeEventListener("pointerdown", unlock);
    window.removeEventListener("keydown", unlock);
    window.removeEventListener("touchstart", unlock);
  };
  window.addEventListener("pointerdown", unlock, { once: true });
  window.addEventListener("keydown", unlock, { once: true });
  window.addEventListener("touchstart", unlock, { once: true });
}

type Tone = { freq: number; durMs: number; type?: OscillatorType; gain?: number; delayMs?: number };

const play = (tones: Tone[]) => {
  if (!isOn()) return;
  const c = ensureCtx();
  if (!c) return;
  const now = c.currentTime;
  tones.forEach((t) => {
    const start = now + (t.delayMs ?? 0) / 1000;
    const dur = t.durMs / 1000;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = t.type ?? "sine";
    osc.frequency.setValueAtTime(t.freq, start);
    const peak = t.gain ?? 0.08;
    g.gain.setValueAtTime(0, start);
    g.gain.linearRampToValueAtTime(peak, start + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    osc.connect(g);
    g.connect(c.destination);
    osc.start(start);
    osc.stop(start + dur + 0.02);
  });
};

// ─── Public sound presets ───
export const sounds = {
  newUser: () => play([
    { freq: 880, durMs: 90, type: "sine", gain: 0.06 },
    { freq: 1320, durMs: 140, type: "sine", gain: 0.07, delayMs: 90 },
  ]),
  critical: () => play([
    { freq: 880, durMs: 120, type: "square", gain: 0.05 },
    { freq: 660, durMs: 120, type: "square", gain: 0.05, delayMs: 130 },
    { freq: 880, durMs: 120, type: "square", gain: 0.05, delayMs: 260 },
  ]),
  click: () => play([{ freq: 540, durMs: 50, type: "triangle", gain: 0.04 }]),
  success: () => play([
    { freq: 660, durMs: 70, type: "sine", gain: 0.05 },
    { freq: 990, durMs: 110, type: "sine", gain: 0.05, delayMs: 70 },
  ]),
  error: () => play([
    { freq: 220, durMs: 180, type: "sawtooth", gain: 0.05 },
    { freq: 180, durMs: 220, type: "sawtooth", gain: 0.05, delayMs: 180 },
  ]),
  block: () => play([
    { freq: 1200, durMs: 60, type: "square", gain: 0.05 },
    { freq: 400, durMs: 180, type: "sawtooth", gain: 0.06, delayMs: 60 },
  ]),
};
