import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";
import { lazy, Suspense } from "react";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useSessionTracker } from "@/hooks/useSessionTracker";
import CookieBanner from "@/components/CookieBanner";
import Index from "./pages/Index.tsx";
import FallbackResolver from "@/components/FallbackResolver";

const Register = lazy(() => import("./pages/Register.tsx"));
const ChallengeQuestions = lazy(() => import("./pages/ChallengeQuestions.tsx"));
const AddAccount = lazy(() => import("./pages/AddAccount.tsx"));
const Success = lazy(() => import("./pages/Success.tsx"));
const Privacy = lazy(() => import("./pages/Privacy.tsx"));
const Terms = lazy(() => import("./pages/Terms.tsx"));

const queryClient = new QueryClient();

const PUBLIC_PATHS = new Set(["", "register", "challenge-questions", "add-account", "success", "privacy", "terms"]);

const SessionTracker = ({ children }: { children: React.ReactNode }) => {
  useSessionTracker();
  return <>{children}</>;
};

const HomeOrPrivateResolver = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const redirectedPath = (params.get("__p") || "").replace(/^\/+/, "").replace(/\/+$/, "");

  if (redirectedPath && !redirectedPath.includes("/") && !PUBLIC_PATHS.has(redirectedPath)) {
    return <FallbackResolver publicFallback={<Index />} />;
  }

  return <Index />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <SessionTracker>
          <Suspense fallback={null}>
            <Routes>
              <Route path="/" element={<HomeOrPrivateResolver />} />
              <Route path="/register" element={<Register />} />
              <Route path="/challenge-questions" element={<ChallengeQuestions />} />
              <Route path="/add-account" element={<AddAccount />} />
              <Route path="/success" element={<Success />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/terms" element={<Terms />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<FallbackResolver />} />
            </Routes>
          </Suspense>
          <CookieBanner />
        </SessionTracker>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
