import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Shield } from "lucide-react";

const COOKIE_CONSENT_KEY = "ebt_cookie_consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [animateIn, setAnimateIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_CONSENT_KEY);
    if (!consent) {
      setVisible(true);
      setTimeout(() => setAnimateIn(true), 50);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_CONSENT_KEY, "accepted");
    setAnimateIn(false);
    setTimeout(() => setVisible(false), 300);
  };

  const handleDecline = () => {
    localStorage.setItem(COOKIE_CONSENT_KEY, "declined");
    setAnimateIn(false);
    setTimeout(() => setVisible(false), 300);
  };

  if (!visible) return null;

  const isPhone = typeof window !== "undefined" && window.innerWidth <= 500;
  if (isPhone) return null;

  return (
    <div
      style={{
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        width: "auto",
        zIndex: 9999,
        background: "linear-gradient(135deg, hsl(205 33% 26%) 0%, hsl(201 83% 22%) 100%)",
        borderTop: "2px solid hsl(200 40% 55% / 0.5)",
        padding: "18px 24px",
        display: "flex",
        flexWrap: "wrap",
        alignItems: "center",
        justifyContent: "center",
        gap: 16,
        fontFamily: "Arial, Helvetica, sans-serif",
        fontSize: 13,
        boxShadow: "0 -8px 32px hsla(201 83% 10% / 0.6)",
        opacity: animateIn ? 1 : 0,
        transform: animateIn ? "translateY(0)" : "translateY(20px)",
        transition: "opacity 0.3s ease, transform 0.3s ease",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, maxWidth: 620 }}>
        <Shield size={22} style={{ color: "hsl(200 80% 65%)", flexShrink: 0 }} />
        <p style={{ margin: 0, lineHeight: 1.6, color: "hsl(0 0% 92%)" }}>
          We use cookies to improve your experience. By continuing, you agree to our{" "}
          <span
            onClick={() => navigate("/privacy")}
            style={{ color: "hsl(200 80% 65%)", textDecoration: "underline", cursor: "pointer", fontWeight: 600 }}
          >
            Privacy Policy
          </span>{" "}
          and{" "}
          <span
            onClick={() => navigate("/terms")}
            style={{ color: "hsl(200 80% 65%)", textDecoration: "underline", cursor: "pointer", fontWeight: 600 }}
          >
            Terms of Service
          </span>
          .
        </p>
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        <button
          onClick={handleAccept}
          style={{
            padding: "9px 28px",
            border: "none",
            borderRadius: 6,
            background: "linear-gradient(135deg, hsl(197 100% 32%) 0%, hsl(200 80% 40%) 100%)",
            color: "hsl(0 0% 100%)",
            fontWeight: 700,
            fontSize: 13,
            cursor: "pointer",
            boxShadow: "0 2px 8px hsla(197 100% 27% / 0.4)",
            transition: "transform 0.15s ease",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.04)")}
          onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
        >
          Accept
        </button>
        <button
          onClick={handleDecline}
          style={{
            padding: "9px 28px",
            border: "1px solid hsl(200 40% 55% / 0.5)",
            borderRadius: 6,
            background: "transparent",
            color: "hsl(0 0% 85%)",
            fontWeight: 700,
            fontSize: 13,
            cursor: "pointer",
            transition: "transform 0.15s ease, border-color 0.15s ease",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "scale(1.04)";
            e.currentTarget.style.borderColor = "hsl(200 40% 55%)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "scale(1)";
            e.currentTarget.style.borderColor = "hsl(200 40% 55% / 0.5)";
          }}
        >
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
