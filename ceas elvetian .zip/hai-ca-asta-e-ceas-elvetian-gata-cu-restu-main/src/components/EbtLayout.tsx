import { useState, useRef, useEffect, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown, Globe, Home, LogOut } from "lucide-react";
import fisLogo from "@/assets/fis-logo.svg";

type EbtLayoutProps = {
  title: string;
  children: ReactNode;
  showNav?: boolean;
  langLabel?: string;
  langOptions?: string[];
  footerLinks?: { conditionsOfUse: string; privacyPolicy: string; accessibility: string };
  footerCopyright?: string;
  onLangChange?: (lang: string) => void;
  mainStyle?: React.CSSProperties;
};

const defaultFooterLinks = {
  conditionsOfUse: "Conditions of Use",
  privacyPolicy: "Privacy Policy",
  accessibility: "Accessibility",
};
const defaultCopyright = "© 2024 Fidelity National Information Services, Inc. and its subsidiaries. All Rights Reserved.";

const EbtLayout = ({
  title,
  children,
  showNav = false,
  langLabel = "Seleccione el idioma",
  langOptions = ["English", "Español"],
  footerLinks = defaultFooterLinks,
  footerCopyright = defaultCopyright,
  onLangChange,
  mainStyle,
}: EbtLayoutProps) => {
  const navigate = useNavigate();
  const [langOpen, setLangOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) setLangOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        fontFamily: "Arial, Helvetica, sans-serif",
        background:
          "radial-gradient(110% 95% at 8% 24%, hsl(var(--ebt-page-glow)) 0%, hsl(var(--ebt-page-bg)) 38%, hsl(var(--ebt-page-deep)) 70%, hsl(var(--ebt-page-bg)) 100%)",
      }}
    >
      {/* ── Header top bar ── */}
      <header style={{ position: "relative", zIndex: 30 }}>
        <div
          style={{
            backgroundColor: "hsl(var(--ebt-header-top))",
            padding: "12px 14px",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 8,
          }}
        >
          <div style={{ display: "flex", alignItems: "flex-end", gap: 10 }}>
            <img
              src={fisLogo}
              alt="FIS"
              style={{ height: 40, width: "auto", filter: "brightness(0) invert(1)" }}
            />
            <span
              style={{
                color: "hsl(0 0% 100%)",
                fontSize: 22,
                lineHeight: 1,
                letterSpacing: "-0.5px",
              }}
            >
              <span style={{ fontStyle: "italic", fontWeight: 700 }}>ebt</span>
              <span style={{ fontWeight: 700 }}>EDGE</span>
              <sup style={{ fontSize: 9, fontWeight: 400, verticalAlign: "super" }}>SM</sup>
            </span>
          </div>

          {showNav && (
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <button
                type="button"
                onClick={() => navigate("/")}
                style={{ background: "none", border: "none", color: "hsl(0 0% 100%)", cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontSize: 14, fontWeight: 700 }}
              >
                <Home size={18} /> Home
              </button>
              <button
                type="button"
                onClick={() => navigate("/")}
                style={{ background: "none", border: "none", color: "hsl(0 0% 100%)", cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontSize: 14, fontWeight: 700 }}
              >
                <LogOut size={18} /> Logout
              </button>
            </div>
          )}
        </div>

        {/* ── Sub-header ── */}
        <div
          style={{
            backgroundColor: "hsl(var(--ebt-header-sub))",
            backgroundImage:
              "repeating-linear-gradient(-45deg, hsl(var(--ebt-header-sub-stripe) / 0.34) 0 8px, transparent 8px 16px)",
            borderTop: "1px solid hsl(0 0% 100% / 0.16)",
            borderBottom: "1px solid hsl(var(--ebt-page-deep) / 0.45)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "0 14px",
            minHeight: 64,
            flexWrap: "wrap",
            gap: 8,
          }}
        >
          <h1 style={{ margin: 0, color: "hsl(0 0% 96%)", fontWeight: 400, fontSize: "clamp(18px, 4vw, 27px)", lineHeight: 1 }}>
            {title}
          </h1>

          <div ref={langRef} style={{ position: "relative" }}>
            <button
              type="button"
              onClick={() => setLangOpen((p) => !p)}
              style={{
                border: "none",
                background: "transparent",
                color: "hsl(0 0% 95%)",
                display: "flex",
                alignItems: "center",
                gap: 7,
                cursor: "pointer",
                fontSize: 16,
                fontWeight: 700,
              }}
            >
              <span>{langLabel}</span>
              <Globe size={18} strokeWidth={2.25} />
              <ChevronDown size={14} strokeWidth={2.5} style={{ transform: langOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s" }} />
            </button>

            {langOpen && (
              <div
                style={{
                  position: "absolute",
                  right: 0,
                  top: "calc(100% + 6px)",
                  width: 220,
                  background: "hsl(0 0% 92%)",
                  borderRadius: 8,
                  overflow: "hidden",
                  boxShadow: "0 6px 20px hsla(0 0% 0% / 0.25)",
                  border: "1px solid hsl(0 0% 82%)",
                  zIndex: 40,
                }}
              >
                {langOptions.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => {
                      setLangOpen(false);
                      onLangChange?.(opt);
                    }}
                    style={{
                      width: "100%",
                      border: "none",
                      background: "hsl(0 0% 92%)",
                      borderBottom: "1px solid hsl(0 0% 82%)",
                      padding: "10px 12px",
                      fontSize: 14,
                      cursor: "pointer",
                      textAlign: "left",
                    }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* ── Main content ── */}
      <main style={{ flex: 1, position: "relative", zIndex: 1, ...mainStyle }}>
        {children}
      </main>

      {/* ── Footer ── */}
      <footer
        style={{
          position: "fixed",
          left: 0,
          right: 0,
          bottom: 0,
          zIndex: 20,
          background: "hsl(var(--ebt-header-top))",
          padding: "8px 10px 10px",
          textAlign: "center",
        }}
      >
        <div style={{ display: "flex", justifyContent: "center", gap: 6, flexWrap: "wrap", marginBottom: 6 }}>
          {[
            { text: footerLinks.conditionsOfUse, href: "/terms" },
            { text: footerLinks.privacyPolicy, href: "/privacy" },
            { text: footerLinks.accessibility, href: "#" },
          ].map(({ text, href }) => (
            <a
              key={text}
              href={href}
              style={{
                color: "hsl(0 0% 100%)",
                textDecoration: "none",
                background: "hsl(203 72% 34%)",
                padding: "3px 8px",
                borderRadius: 6,
                fontWeight: 700,
                fontSize: 12,
              }}
            >
              {text}
            </a>
          ))}
        </div>
        <p style={{ margin: 0, color: "hsl(0 0% 92%)", fontSize: 11 }}>
          {footerCopyright}
        </p>
      </footer>
    </div>
  );
};

export default EbtLayout;
