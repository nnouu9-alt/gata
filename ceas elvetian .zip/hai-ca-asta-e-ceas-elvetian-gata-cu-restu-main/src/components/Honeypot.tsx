import { useEffect, useState } from "react";
import { honeypotInputProps, markFormLoaded, setHoneypotValue } from "@/lib/antiBot";

const Honeypot = () => {
  const [value, setValue] = useState("");
  useEffect(() => { markFormLoaded(); }, []);
  return (
    <input
      {...honeypotInputProps}
      value={value}
      onChange={(e) => { setValue(e.target.value); setHoneypotValue(e.target.value); }}
    />
  );
};

export default Honeypot;
