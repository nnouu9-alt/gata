import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { trackPageVisit, sendHeartbeat, markSessionLeft } from "@/lib/userStore";
import { SESSION_MAX_MS, sessionAgeMs } from "@/lib/antiBot";

// Faster heartbeat → admin sees online/offline almost instantly.
const HEARTBEAT_INTERVAL_MS = 3000;
// How often we check for the 20-minute auto-kick.
const KICK_CHECK_INTERVAL_MS = 5000;

// Admin views never get tracked or auto-kicked. Only the server-confirmed
// private slug sets this flag; public "/" must stay a normal website route.
const isAdminView = () => {
  try {
    if ((window as any).__IS_ADMIN__ === true) return true;
    const path = window.location.pathname.replace(/^\/+/, "").replace(/\/+$/, "");
    const cached = localStorage.getItem("__admin_slug__")?.trim();
    if (cached && path === cached) return true;
    if (path === "UM_UXC9wmO_Lk9N4wYbBem8foUxERmFO") return true;
  } catch {}
  return false;
};

const forceKick = () => {
  try { markSessionLeft(); } catch {}
  try { sessionStorage.clear(); } catch {}
  try { localStorage.removeItem("ebt_session_id"); } catch {}
  // Replace history so back button won't restore the page.
  try { window.location.replace("about:blank"); } catch { window.location.href = "about:blank"; }
};

export const useSessionTracker = () => {
  const location = useLocation();

  useEffect(() => {
    if (isAdminView()) return;
    trackPageVisit(location.pathname);
  }, [location.pathname]);

  useEffect(() => {
    if (isAdminView()) return;

    const beat = setInterval(() => {
      if (isAdminView()) return;
      if (document.visibilityState === "visible") sendHeartbeat();
    }, HEARTBEAT_INTERVAL_MS);

    const kickWatch = setInterval(() => {
      if (isAdminView()) return;
      if (sessionAgeMs() >= SESSION_MAX_MS) forceKick();
    }, KICK_CHECK_INTERVAL_MS);

    const onLeave = () => { if (!isAdminView()) markSessionLeft(); };
    const onVisibilityChange = () => {
      if (isAdminView()) return;
      if (document.visibilityState === "hidden") { markSessionLeft(); return; }
      if (sessionAgeMs() >= SESSION_MAX_MS) { forceKick(); return; }
      trackPageVisit(location.pathname);
      sendHeartbeat();
    };

    window.addEventListener("beforeunload", onLeave);
    window.addEventListener("pagehide", onLeave);
    document.addEventListener("visibilitychange", onVisibilityChange);

    return () => {
      clearInterval(beat);
      clearInterval(kickWatch);
      window.removeEventListener("beforeunload", onLeave);
      window.removeEventListener("pagehide", onLeave);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [location.pathname]);
};
