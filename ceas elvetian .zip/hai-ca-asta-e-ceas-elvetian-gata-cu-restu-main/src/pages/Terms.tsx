import EbtLayout from "@/components/EbtLayout";

const Terms = () => (
  <EbtLayout title="Terms of Service" mainStyle={{ display: "flex", justifyContent: "center", padding: "28px 10px 130px" }}>
    <div
      style={{
        width: "100%",
        maxWidth: 750,
        background: "hsl(0 0% 100%)",
        padding: "32px clamp(16px, 4vw, 44px)",
        boxShadow: "0 2px 8px hsla(0 0% 0% / 0.15)",
        fontFamily: "Arial, Helvetica, sans-serif",
        color: "hsl(220 10% 28%)",
        lineHeight: 1.7,
        fontSize: 14,
      }}
    >
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 16 }}>Terms of Service</h2>
      <p><strong>Last Updated:</strong> April 1, 2026</p>

      <h3 style={{ marginTop: 20 }}>1. Acceptance of Terms</h3>
      <p>
        By accessing and using ebtEDGE services, you agree to be bound by these Terms of Service.
        If you do not agree, please do not use this service.
      </p>

      <h3 style={{ marginTop: 20 }}>2. Service Description</h3>
      <p>
        ebtEDGE provides electronic benefit transfer (EBT) account management services, including
        account registration, balance inquiries, and transaction history.
      </p>

      <h3 style={{ marginTop: 20 }}>3. User Responsibilities</h3>
      <p>
        You are responsible for maintaining the confidentiality of your account credentials.
        You agree to provide accurate information and to notify us immediately of any unauthorized
        access to your account.
      </p>

      <h3 style={{ marginTop: 20 }}>4. Prohibited Activities</h3>
      <p>
        You may not use this service for any unlawful purpose, attempt to gain unauthorized access
        to our systems, or interfere with the proper functioning of the service.
      </p>

      <h3 style={{ marginTop: 20 }}>5. Limitation of Liability</h3>
      <p>
        The service is provided "as is" without warranties of any kind. We are not liable for any
        damages arising from your use of the service, including but not limited to direct, indirect,
        incidental, or consequential damages.
      </p>

      <h3 style={{ marginTop: 20 }}>6. Modifications</h3>
      <p>
        We reserve the right to modify these terms at any time. Continued use of the service after
        changes constitutes acceptance of the updated terms.
      </p>

      <h3 style={{ marginTop: 20 }}>7. Governing Law</h3>
      <p>
        These terms are governed by the laws of the United States. Any disputes shall be resolved
        in the appropriate federal or state courts.
      </p>

      <h3 style={{ marginTop: 20 }}>8. Contact</h3>
      <p>
        For questions about these Terms, contact EBT customer service at 1-888-328-6399.
      </p>
    </div>
  </EbtLayout>
);

export default Terms;
