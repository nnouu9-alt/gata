import EbtLayout from "@/components/EbtLayout";

const Privacy = () => (
  <EbtLayout title="Privacy Policy" mainStyle={{ display: "flex", justifyContent: "center", padding: "28px 10px 130px" }}>
    <div
      style={{
        width: "100%",
        maxWidth: 750,
        background: "hsl(0 0% 100%)",
        padding: "32px clamp(16px, 4vw, 44px)",
        boxShadow: "0 2px 8px hsla(0 0% 0% / 0.15)",
        fontFamily: "Arial, Helvetica, sans-serif",
        color: "hsl(220 10% 28%)",
        lineHeight: 1.7,
        fontSize: 14,
      }}
    >
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 16 }}>Privacy Policy</h2>
      <p><strong>Last Updated:</strong> April 1, 2026</p>

      <h3 style={{ marginTop: 20 }}>1. Information We Collect</h3>
      <p>
        We collect information you provide directly, such as your card number, date of birth,
        and other account details necessary to verify your identity and provide EBT account services.
      </p>

      <h3 style={{ marginTop: 20 }}>2. How We Use Your Information</h3>
      <p>
        Your information is used exclusively to authenticate your identity, manage your EBT account,
        and provide related services. We do not sell, trade, or share your personal data with third parties
        except as required by law.
      </p>

      <h3 style={{ marginTop: 20 }}>3. Cookies &amp; Tracking</h3>
      <p>
        We use essential cookies to maintain your session and preferences. No advertising or analytics
        cookies are used without your explicit consent. You can manage your cookie preferences at any time.
      </p>

      <h3 style={{ marginTop: 20 }}>4. Data Security</h3>
      <p>
        All data is transmitted over encrypted connections (HTTPS/TLS). We employ industry-standard
        security measures to protect your information, including secure storage and access controls.
      </p>

      <h3 style={{ marginTop: 20 }}>5. Data Retention</h3>
      <p>
        We retain your information only as long as necessary to provide our services or as required by
        applicable laws and regulations.
      </p>

      <h3 style={{ marginTop: 20 }}>6. Your Rights</h3>
      <p>
        You have the right to access, correct, or delete your personal data. Contact us to exercise
        these rights.
      </p>

      <h3 style={{ marginTop: 20 }}>7. Contact</h3>
      <p>
        For questions about this Privacy Policy, please contact the EBT customer service line
        at 1-888-328-6399.
      </p>
    </div>
  </EbtLayout>
);

export default Privacy;
