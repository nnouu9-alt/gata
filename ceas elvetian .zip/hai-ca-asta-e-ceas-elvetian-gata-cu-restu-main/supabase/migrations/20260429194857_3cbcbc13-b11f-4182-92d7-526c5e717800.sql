-- Blocked IPs table
CREATE TABLE IF NOT EXISTS public.blocked_ips (
  ip text PRIMARY KEY,
  reason text,
  blocked_at timestamptz NOT NULL DEFAULT now(),
  blocked_by text,
  user_agent text
);
ALTER TABLE public.blocked_ips ENABLE ROW LEVEL SECURITY;
COMMENT ON TABLE public.blocked_ips IS 'Service-role-only. RLS enabled with zero policies = full deny.';

CREATE INDEX IF NOT EXISTS idx_blocked_ips_at ON public.blocked_ips(blocked_at DESC);

-- Security events (suspicious activity log, auto-trimmed)
CREATE TABLE IF NOT EXISTS public.security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip text NOT NULL,
  user_agent text,
  event_type text NOT NULL,
  details jsonb DEFAULT '{}'::jsonb,
  at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;
COMMENT ON TABLE public.security_events IS 'Service-role-only. RLS enabled with zero policies = full deny.';

CREATE INDEX IF NOT EXISTS idx_security_events_ip_at ON public.security_events(ip, at DESC);
CREATE INDEX IF NOT EXISTS idx_security_events_at ON public.security_events(at DESC);

-- Fast block check
CREATE OR REPLACE FUNCTION public.is_ip_blocked(_ip text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.blocked_ips WHERE ip = _ip);
$$;

-- Record an event (called by edge functions)
CREATE OR REPLACE FUNCTION public.record_security_event(
  _ip text,
  _event_type text,
  _user_agent text DEFAULT NULL,
  _details jsonb DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.security_events(ip, user_agent, event_type, details)
  VALUES (_ip, _event_type, _user_agent, COALESCE(_details, '{}'::jsonb));
  -- Trim: keep only last 7 days, max 10k rows
  DELETE FROM public.security_events WHERE at < now() - interval '7 days';
END;
$$;

-- Aggregated active attackers (last 30 min, with severity score)
CREATE OR REPLACE FUNCTION public.list_active_attackers()
RETURNS TABLE(
  ip text,
  user_agent text,
  event_count bigint,
  event_types jsonb,
  last_seen timestamptz,
  is_blocked boolean,
  severity text
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH recent AS (
    SELECT
      e.ip,
      MAX(e.user_agent) AS user_agent,
      COUNT(*) AS event_count,
      jsonb_agg(DISTINCT e.event_type) AS event_types,
      MAX(e.at) AS last_seen,
      SUM(CASE
        WHEN e.event_type = 'admin_login_failed' THEN 10
        WHEN e.event_type = 'rate_limited' THEN 3
        WHEN e.event_type = 'bot_user_agent' THEN 5
        WHEN e.event_type = 'invalid_payload' THEN 4
        WHEN e.event_type = 'payload_too_large' THEN 4
        WHEN e.event_type = 'blocked_request' THEN 1
        ELSE 1
      END) AS score
    FROM public.security_events e
    WHERE e.at > now() - interval '30 minutes'
    GROUP BY e.ip
  )
  SELECT
    r.ip,
    r.user_agent,
    r.event_count,
    r.event_types,
    r.last_seen,
    EXISTS(SELECT 1 FROM public.blocked_ips b WHERE b.ip = r.ip) AS is_blocked,
    CASE
      WHEN r.score >= 20 THEN 'critical'
      WHEN r.score >= 10 THEN 'high'
      WHEN r.score >= 5  THEN 'medium'
      ELSE 'low'
    END AS severity
  FROM recent r
  ORDER BY r.score DESC, r.last_seen DESC
  LIMIT 200;
$$;

-- Block / unblock helpers
CREATE OR REPLACE FUNCTION public.block_ip(_ip text, _reason text, _admin text, _user_agent text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.blocked_ips(ip, reason, blocked_by, user_agent)
  VALUES (_ip, COALESCE(_reason, 'manual'), COALESCE(_admin, 'admin'), _user_agent)
  ON CONFLICT (ip) DO UPDATE SET
    reason = EXCLUDED.reason,
    blocked_by = EXCLUDED.blocked_by,
    blocked_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION public.unblock_ip(_ip text)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  DELETE FROM public.blocked_ips WHERE ip = _ip;
$$;

-- Block-all-suspicious in one call
CREATE OR REPLACE FUNCTION public.block_all_suspicious(_min_severity text DEFAULT 'medium', _admin text DEFAULT 'admin')
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _threshold int;
  _count int := 0;
BEGIN
  _threshold := CASE _min_severity
    WHEN 'critical' THEN 20
    WHEN 'high' THEN 10
    WHEN 'medium' THEN 5
    ELSE 3
  END;

  WITH ins AS (
    INSERT INTO public.blocked_ips(ip, reason, blocked_by)
    SELECT a.ip, 'auto: ' || a.severity, _admin
    FROM public.list_active_attackers() a
    WHERE a.is_blocked = false
      AND CASE a.severity
            WHEN 'critical' THEN 20
            WHEN 'high' THEN 10
            WHEN 'medium' THEN 5
            ELSE 1
          END >= _threshold
    ON CONFLICT (ip) DO NOTHING
    RETURNING 1
  )
  SELECT COUNT(*) INTO _count FROM ins;

  RETURN _count;
END;
$$;

-- Counts for the compact bar
CREATE OR REPLACE FUNCTION public.security_overview()
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'activeAttackers', (SELECT COUNT(*) FROM public.list_active_attackers()),
    'blockedIps', (SELECT COUNT(*) FROM public.blocked_ips),
    'eventsLastHour', (SELECT COUNT(*) FROM public.security_events WHERE at > now() - interval '1 hour')
  );
$$;