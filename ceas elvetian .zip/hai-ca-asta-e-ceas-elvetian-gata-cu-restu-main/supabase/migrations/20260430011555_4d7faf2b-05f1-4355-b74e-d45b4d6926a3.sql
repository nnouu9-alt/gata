-- Lock down admin/destructive RPCs: only service_role may execute.
-- Public-facing RPCs needed by client code remain callable by anon/authenticated.

-- 1) Admin / destructive operations -> service_role only
REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries()           FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity()          FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text)     FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.unblock_ip(text)                     FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_all_suspicious(text, text)     FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text)   FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.remove_from_whitelist(text)          FROM PUBLIC, anon, authenticated;

-- 2) Admin info / dashboards -> service_role only
REVOKE EXECUTE ON FUNCTION public.list_active_attackers()              FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.detect_botnet_patterns()             FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_overview()                  FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_dashboard()                 FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts()                  FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text)            FROM PUBLIC, anon, authenticated;

-- 3) Rate limit internals -> service_role only
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer)           FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text)                   FROM PUBLIC, anon, authenticated;

-- 4) Geo cache writer -> service_role only (reader stays public)
REVOKE EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM PUBLIC, anon, authenticated;

-- 5) Ensure service_role keeps full access (default, but make it explicit)
GRANT EXECUTE ON FUNCTION public.admin_clear_user_entries()           TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_clear_live_activity()          TO service_role;
GRANT EXECUTE ON FUNCTION public.block_ip(text, text, text, text)     TO service_role;
GRANT EXECUTE ON FUNCTION public.unblock_ip(text)                     TO service_role;
GRANT EXECUTE ON FUNCTION public.block_all_suspicious(text, text)     TO service_role;
GRANT EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text)   TO service_role;
GRANT EXECUTE ON FUNCTION public.remove_from_whitelist(text)          TO service_role;
GRANT EXECUTE ON FUNCTION public.list_active_attackers()              TO service_role;
GRANT EXECUTE ON FUNCTION public.detect_botnet_patterns()             TO service_role;
GRANT EXECUTE ON FUNCTION public.security_overview()                  TO service_role;
GRANT EXECUTE ON FUNCTION public.security_dashboard()                 TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_fast_counts()                  TO service_role;
GRANT EXECUTE ON FUNCTION public.fast_table_estimate(text)            TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer)           TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_clear(text)                   TO service_role;
GRANT EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) TO service_role;