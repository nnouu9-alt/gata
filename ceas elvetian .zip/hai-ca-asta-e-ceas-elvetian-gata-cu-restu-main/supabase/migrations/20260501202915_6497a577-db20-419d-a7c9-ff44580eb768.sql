
CREATE OR REPLACE FUNCTION public.public_stats_cached()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _total bigint;
  _row public.stats_cache%ROWTYPE;
  _online bigint;
BEGIN
  SELECT * INTO _row FROM public.stats_cache WHERE key = 'user_entries_total';
  IF _row.key IS NULL OR _row.updated_at < now() - interval '3 seconds' THEN
    SELECT COUNT(*) INTO _total FROM public.user_entries;
    INSERT INTO public.stats_cache(key, value, updated_at)
    VALUES ('user_entries_total', _total, now())
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at;
  ELSE
    _total := _row.value;
  END IF;

  SELECT COUNT(*) INTO _online
  FROM public.live_sessions
  WHERE last_seen > now() - interval '30 seconds'
    AND COALESCE(status, '') <> 'left';

  RETURN jsonb_build_object('totalEntries', _total, 'visitorsOnline', _online);
END;
$$;

REVOKE ALL ON FUNCTION public.public_stats_cached() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.public_stats_cached() TO service_role;
