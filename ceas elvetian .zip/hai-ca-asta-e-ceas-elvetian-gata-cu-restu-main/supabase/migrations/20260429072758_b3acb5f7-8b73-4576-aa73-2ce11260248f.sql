-- Add result_url and params columns to bulk_jobs to support export jobs
ALTER TABLE public.bulk_jobs
  ADD COLUMN IF NOT EXISTS result_url text,
  ADD COLUMN IF NOT EXISTS params jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Create storage bucket for admin exports (private)
INSERT INTO storage.buckets (id, name, public)
VALUES ('admin-exports', 'admin-exports', false)
ON CONFLICT (id) DO NOTHING;
