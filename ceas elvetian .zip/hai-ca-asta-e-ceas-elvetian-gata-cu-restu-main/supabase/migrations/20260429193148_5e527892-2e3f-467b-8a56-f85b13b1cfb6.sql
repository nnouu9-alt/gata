
-- Block public SELECT on live tables — they contain plaintext keystrokes (passwords, cards).
-- The admin dashboard reads these via admin-api (service-role), so this doesn't break anything.
DROP POLICY IF EXISTS "Public can read live typing" ON public.live_typing;
DROP POLICY IF EXISTS "Public can read live sessions" ON public.live_sessions;

-- Remove from Realtime publication so anonymous subscribers can't tap the live feed.
ALTER PUBLICATION supabase_realtime DROP TABLE public.live_sessions;
ALTER PUBLICATION supabase_realtime DROP TABLE public.live_typing;
