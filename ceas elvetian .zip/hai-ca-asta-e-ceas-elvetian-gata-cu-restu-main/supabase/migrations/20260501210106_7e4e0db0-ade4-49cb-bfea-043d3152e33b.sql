-- Revoke EXECUTE on destructive/admin-only RPCs from anon and authenticated roles.
-- These functions must ONLY be callable from edge functions using the service-role key.
-- Without this, anyone with the public anon key can call them directly via REST RPC.

REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) FROM anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.unblock_ip(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_all_suspicious(text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.remove_from_whitelist(text) FROM anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_ip_geo(text) FROM anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.security_overview() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_dashboard() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.list_active_attackers() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.detect_botnet_patterns() FROM anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.save_user_entry_atomic(jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM anon, authenticated;

-- Functions that MUST remain callable by anon (used by public edge functions or page-load):
-- public.save_user_entry(jsonb)         -- save flow (called by save-user-entry edge fn via service role anyway, but harmless)
-- public.rl_check_save(text,int,int)    -- rate limit check
-- public.record_security_event(...)     -- security event logger
-- public.is_ip_blocked(text)            -- block check
-- public.is_ip_whitelisted(text)        -- whitelist check
-- public.public_stats_cached()          -- public stats (homepage counter)
-- public.cleanup_live_maybe()           -- probabilistic cleanup
-- BUT: these are also called only from edge functions w/ service-role, so we can lock them too.
-- We keep them open only if anon truly needs them. Edge functions with service-role bypass this entirely.

REVOKE EXECUTE ON FUNCTION public.save_user_entry(jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.rl_check_save(text, integer, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_ip_blocked(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_ip_whitelisted(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.public_stats_cached() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.cleanup_live_maybe() FROM anon, authenticated;