-- Explicit DENY policies for all tables: anon + authenticated cannot access directly.
-- Edge functions use service_role which bypasses RLS, so functionality is preserved.

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'admin_audit_log',
    'admin_rate_limit',
    'blocked_ips',
    'bulk_jobs',
    'ip_geo_cache',
    'ip_whitelist',
    'live_sessions',
    'live_typing',
    'security_events',
    'user_entries'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    -- Ensure RLS is enabled
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);

    -- Drop any prior deny policies (idempotent)
    EXECUTE format('DROP POLICY IF EXISTS "deny_anon_all" ON public.%I', t);
    EXECUTE format('DROP POLICY IF EXISTS "deny_authenticated_all" ON public.%I', t);

    -- Explicit DENY for anon
    EXECUTE format($f$
      CREATE POLICY "deny_anon_all" ON public.%I
      AS RESTRICTIVE
      FOR ALL
      TO anon
      USING (false)
      WITH CHECK (false)
    $f$, t);

    -- Explicit DENY for authenticated
    EXECUTE format($f$
      CREATE POLICY "deny_authenticated_all" ON public.%I
      AS RESTRICTIVE
      FOR ALL
      TO authenticated
      USING (false)
      WITH CHECK (false)
    $f$, t);
  END LOOP;
END $$;