ALTER TABLE public.live_typing REPLICA IDENTITY FULL;
ALTER TABLE public.live_sessions REPLICA IDENTITY FULL;
DO $$ BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.live_sessions; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;