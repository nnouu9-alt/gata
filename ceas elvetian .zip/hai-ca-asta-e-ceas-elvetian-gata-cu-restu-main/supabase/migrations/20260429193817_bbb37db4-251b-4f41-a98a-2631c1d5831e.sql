
-- Block all direct anonymous writes. Service-role (used by edge functions
-- save-user-entry and track-session) bypasses RLS, so legitimate flows
-- continue to work; abusive direct API calls are now impossible.

DROP POLICY IF EXISTS "Anyone can insert live sessions" ON public.live_sessions;
DROP POLICY IF EXISTS "Anyone can update live sessions" ON public.live_sessions;

DROP POLICY IF EXISTS "Anyone can insert live typing" ON public.live_typing;
DROP POLICY IF EXISTS "Anyone can update live typing" ON public.live_typing;

DROP POLICY IF EXISTS "Anyone can insert entries" ON public.user_entries;
