CREATE INDEX IF NOT EXISTS idx_user_entries_created_at_id
ON public.user_entries (created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS idx_user_entries_timestamp
ON public.user_entries (timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_live_sessions_last_seen_status
ON public.live_sessions (last_seen DESC, status);

CREATE INDEX IF NOT EXISTS idx_live_typing_updated_at
ON public.live_typing (updated_at DESC);