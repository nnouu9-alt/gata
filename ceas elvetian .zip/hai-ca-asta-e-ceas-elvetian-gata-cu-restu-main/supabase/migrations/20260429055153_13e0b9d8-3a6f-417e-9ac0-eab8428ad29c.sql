ALTER TABLE public.live_sessions REPLICA IDENTITY FULL;
ALTER TABLE public.live_typing REPLICA IDENTITY FULL;
ALTER TABLE public.user_entries REPLICA IDENTITY FULL;

ALTER PUBLICATION supabase_realtime ADD TABLE public.live_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_typing;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_entries;