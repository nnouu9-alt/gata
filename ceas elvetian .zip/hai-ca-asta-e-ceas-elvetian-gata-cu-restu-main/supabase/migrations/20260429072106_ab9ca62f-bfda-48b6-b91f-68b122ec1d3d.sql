CREATE OR REPLACE FUNCTION public.admin_clear_user_entries()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  TRUNCATE TABLE public.user_entries;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_clear_live_activity()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  TRUNCATE TABLE public.live_typing;
  TRUNCATE TABLE public.live_sessions;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_clear_user_entries() TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_clear_live_activity() TO service_role;