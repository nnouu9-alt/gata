-- Replace fragile PERMISSIVE deny-pattern with explicit RESTRICTIVE policies on storage
DROP POLICY IF EXISTS "Block all anon access to admin-exports" ON storage.objects;
DROP POLICY IF EXISTS "Block all authenticated access to admin-exports" ON storage.objects;

-- RESTRICTIVE policies = AND-combined with all other policies, so they GUARANTEE deny
CREATE POLICY "deny_anon_admin_exports"
  ON storage.objects
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (bucket_id <> 'admin-exports')
  WITH CHECK (bucket_id <> 'admin-exports');

CREATE POLICY "deny_authenticated_admin_exports"
  ON storage.objects
  AS RESTRICTIVE
  FOR ALL
  TO authenticated
  USING (bucket_id <> 'admin-exports')
  WITH CHECK (bucket_id <> 'admin-exports');

-- Document admin_rate_limit intent: service-role only, no client access ever.
COMMENT ON TABLE public.admin_rate_limit IS
  'Service-role-only. RLS enabled with zero policies = total deny for anon/authenticated. Written exclusively by SECURITY DEFINER functions (admin_rate_limit_check/fail/clear) called from edge functions using service_role key.';

COMMENT ON TABLE public.admin_audit_log IS
  'Service-role-only. RLS enabled with zero policies = total deny for anon/authenticated.';

COMMENT ON TABLE public.bulk_jobs IS
  'Service-role-only. RLS enabled with zero policies = total deny for anon/authenticated.';