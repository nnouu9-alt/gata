-- 1. Deblochează IP-ul tău acum
DELETE FROM public.blocked_ips WHERE ip IN (SELECT ip FROM public.ip_whitelist);

-- 2. Repară block_all_suspicious — să excludă whitelisted
CREATE OR REPLACE FUNCTION public.block_all_suspicious(_min_severity text DEFAULT 'medium'::text, _admin text DEFAULT 'admin'::text)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  _threshold int;
  _count int := 0;
BEGIN
  _threshold := CASE _min_severity
    WHEN 'critical' THEN 20
    WHEN 'high' THEN 10
    WHEN 'medium' THEN 5
    ELSE 3
  END;

  WITH ins AS (
    INSERT INTO public.blocked_ips(ip, reason, blocked_by)
    SELECT a.ip, 'auto: ' || a.severity, _admin
    FROM public.list_active_attackers() a
    WHERE a.is_blocked = false
      AND NOT public.is_ip_whitelisted(a.ip)  -- ⬅️ FIX: skip whitelisted
      AND CASE a.severity
            WHEN 'critical' THEN 20
            WHEN 'high' THEN 10
            WHEN 'medium' THEN 5
            ELSE 1
          END >= _threshold
    ON CONFLICT (ip) DO NOTHING
    RETURNING 1
  )
  SELECT COUNT(*) INTO _count FROM ins;

  RETURN _count;
END;
$function$;

-- 3. Index pentru performanță (scanările pe security_events sunt frecvente)
CREATE INDEX IF NOT EXISTS idx_security_events_ip_at ON public.security_events(ip, at DESC);
CREATE INDEX IF NOT EXISTS idx_security_events_at ON public.security_events(at DESC);
CREATE INDEX IF NOT EXISTS idx_blocked_ips_blocked_at ON public.blocked_ips(blocked_at DESC);

-- 4. Cleanup automat: șterge security_events vechi (păstrăm doar 7 zile, deja se face în record_security_event dar întărim)
-- Asta e deja în record_security_event, ok.