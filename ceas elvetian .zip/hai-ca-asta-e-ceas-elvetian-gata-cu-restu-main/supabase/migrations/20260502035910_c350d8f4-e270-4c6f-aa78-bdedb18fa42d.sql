CREATE OR REPLACE FUNCTION public.cleanup_old_data()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _sec_events bigint;
  _sessions bigint;
  _typing bigint;
  _save_rl bigint;
  _admin_rl bigint;
  _audit bigint;
  _bulk bigint;
  _geo bigint;
BEGIN
  WITH d AS (DELETE FROM public.security_events WHERE at < now() - interval '7 days' RETURNING 1)
    SELECT COUNT(*) INTO _sec_events FROM d;

  WITH d AS (DELETE FROM public.live_sessions WHERE last_seen < now() - interval '24 hours' RETURNING 1)
    SELECT COUNT(*) INTO _sessions FROM d;

  WITH d AS (DELETE FROM public.live_typing WHERE updated_at < now() - interval '1 hour' RETURNING 1)
    SELECT COUNT(*) INTO _typing FROM d;

  WITH d AS (DELETE FROM public.save_rate_limit WHERE window_start < now() - interval '1 hour' RETURNING 1)
    SELECT COUNT(*) INTO _save_rl FROM d;

  WITH d AS (DELETE FROM public.admin_rate_limit WHERE first_fail_at < now() - interval '24 hours' AND (blocked_until IS NULL OR blocked_until < now()) RETURNING 1)
    SELECT COUNT(*) INTO _admin_rl FROM d;

  WITH d AS (DELETE FROM public.admin_audit_log WHERE at < now() - interval '90 days' RETURNING 1)
    SELECT COUNT(*) INTO _audit FROM d;

  WITH d AS (DELETE FROM public.bulk_jobs WHERE status IN ('completed', 'failed', 'error') AND updated_at < now() - interval '7 days' RETURNING 1)
    SELECT COUNT(*) INTO _bulk FROM d;

  WITH d AS (DELETE FROM public.ip_geo_cache WHERE cached_at < now() - interval '30 days' RETURNING 1)
    SELECT COUNT(*) INTO _geo FROM d;

  RETURN jsonb_build_object(
    'security_events', _sec_events,
    'live_sessions', _sessions,
    'live_typing', _typing,
    'save_rate_limit', _save_rl,
    'admin_rate_limit', _admin_rl,
    'admin_audit_log', _audit,
    'bulk_jobs', _bulk,
    'ip_geo_cache', _geo,
    'ran_at', now()
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.cleanup_old_data() FROM PUBLIC, anon, authenticated;

CREATE EXTENSION IF NOT EXISTS pg_cron;