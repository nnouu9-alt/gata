-- Tighten update policies to avoid permissive USING (true)
drop policy if exists "Public can update live sessions" on public.live_sessions;
create policy "Public can update live sessions"
on public.live_sessions
for update
to anon, authenticated
using (
  length(trim(session_id)) >= 8
  and status in ('active', 'idle', 'left')
)
with check (
  length(trim(session_id)) >= 8
  and status in ('active', 'idle', 'left')
  and coalesce(array_length(pages_visited, 1), 0) <= 40
);

drop policy if exists "Public can update live typing" on public.live_typing;
create policy "Public can update live typing"
on public.live_typing
for update
to anon, authenticated
using (
  length(trim(session_id)) >= 8
)
with check (
  length(trim(session_id)) >= 8
  and coalesce(array_length(field_keys, 1), 0) <= 30
);