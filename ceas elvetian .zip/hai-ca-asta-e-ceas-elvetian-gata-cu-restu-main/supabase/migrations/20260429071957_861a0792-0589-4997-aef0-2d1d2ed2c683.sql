CREATE INDEX IF NOT EXISTS idx_user_entries_type_created_at
ON public.user_entries (type, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_live_sessions_status_last_seen
ON public.live_sessions (status, last_seen DESC);

CREATE INDEX IF NOT EXISTS idx_live_typing_recent_session
ON public.live_typing (updated_at DESC, session_id);

CREATE OR REPLACE FUNCTION public.fast_table_estimate(_table_name text)
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT GREATEST(COALESCE(c.reltuples, 0)::bigint, 0)
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public'
    AND c.relname = _table_name
  LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.admin_fast_counts()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT jsonb_build_object(
    'totalEntries', public.fast_table_estimate('user_entries'),
    'liveSessions', public.fast_table_estimate('live_sessions'),
    'liveTyping', public.fast_table_estimate('live_typing')
  );
$$;