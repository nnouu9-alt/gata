
CREATE TABLE IF NOT EXISTS public.bulk_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL,
  total integer NOT NULL DEFAULT 0,
  processed integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'queued',
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.bulk_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read bulk jobs" ON public.bulk_jobs FOR SELECT USING (true);
CREATE POLICY "Public can insert bulk jobs" ON public.bulk_jobs FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can update bulk jobs" ON public.bulk_jobs FOR UPDATE USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_bulk_jobs_status ON public.bulk_jobs(status, created_at DESC);
