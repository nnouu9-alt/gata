DELETE FROM public.blocked_ips WHERE ip = '172.58.132.193';
DELETE FROM public.admin_rate_limit WHERE ip = '172.58.132.193';
INSERT INTO public.ip_whitelist (ip, label, added_by)
VALUES ('172.58.132.193', 'admin own IP', 'system')
ON CONFLICT (ip) DO UPDATE SET label = EXCLUDED.label;