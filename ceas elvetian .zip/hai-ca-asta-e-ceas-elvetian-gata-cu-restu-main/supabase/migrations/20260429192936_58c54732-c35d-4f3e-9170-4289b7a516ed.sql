
-- Revoke EXECUTE on admin-only SECURITY DEFINER functions from anon/authenticated.
-- Service-role bypasses these grants and continues to call them from edge functions.
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) FROM anon, authenticated, public;
