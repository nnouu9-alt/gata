DELETE FROM public.admin_rate_limit;
DELETE FROM public.admin_audit_log WHERE action='login_fail' AND at > now() - interval '1 hour';