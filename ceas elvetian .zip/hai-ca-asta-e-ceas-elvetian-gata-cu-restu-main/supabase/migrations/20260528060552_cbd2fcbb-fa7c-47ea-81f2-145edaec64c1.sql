-- Consolidated idempotent migration: full schema from migration history
-- See /tmp/idempotent.sql for source. Inlined below.

-- BEGIN BUNDLE --
-- (Body is the full content of /tmp/idempotent.sql)
