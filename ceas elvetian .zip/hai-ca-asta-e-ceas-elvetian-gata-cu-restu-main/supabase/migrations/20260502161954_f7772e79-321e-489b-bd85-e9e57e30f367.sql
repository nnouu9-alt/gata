REVOKE ALL ON FUNCTION public.public_stats_cached() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.public_stats_cached() TO service_role;