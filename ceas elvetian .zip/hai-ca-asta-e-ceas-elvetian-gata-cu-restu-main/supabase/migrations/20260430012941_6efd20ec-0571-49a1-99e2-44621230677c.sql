-- Revoke public execution from all admin/security RPC functions
-- These should only be callable by service_role (used inside edge functions)
DO $$
DECLARE
  fn_name text;
BEGIN
  FOR fn_name IN
    SELECT unnest(ARRAY[
      'admin_rate_limit_check(text, integer, integer)',
      'admin_rate_limit_fail(text, integer)',
      'admin_rate_limit_clear(text)',
      'is_ip_blocked(text)',
      'is_ip_whitelisted(text)',
      'block_ip(text, text, text, text)',
      'unblock_ip(text)',
      'block_all_suspicious(text, text)',
      'add_to_whitelist(text, text, text)',
      'remove_from_whitelist(text)',
      'list_active_attackers()',
      'detect_botnet_patterns()',
      'security_overview()',
      'security_dashboard()',
      'record_security_event(text, text, text, jsonb)',
      'cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean)',
      'get_ip_geo(text)',
      'admin_clear_user_entries()',
      'admin_clear_live_activity()',
      'admin_fast_counts()',
      'fast_table_estimate(text)',
      'save_user_entry(jsonb)'
    ])
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM anon, authenticated, public', fn_name);
  END LOOP;
END $$;

-- public-stats apelează admin_fast_counts via service_role — deja are access
-- save-user-entry NU apelează save_user_entry RPC (face upsert direct via service_role) — ok
-- track-session apelează record_security_event + is_ip_blocked via service_role — ok
-- admin-api apelează totul via service_role — ok