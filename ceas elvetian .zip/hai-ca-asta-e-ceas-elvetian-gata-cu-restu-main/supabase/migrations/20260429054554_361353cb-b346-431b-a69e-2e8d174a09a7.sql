-- LIVE SESSIONS - reconstruire
DROP TABLE IF EXISTS public.live_sessions CASCADE;
CREATE TABLE public.live_sessions (
  session_id text PRIMARY KEY,
  user_id text,
  current_page text,
  pages_visited jsonb DEFAULT '[]'::jsonb,
  status text DEFAULT 'active',
  user_agent text,
  ip text,
  started_at timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.live_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert live sessions"
  ON public.live_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update live sessions"
  ON public.live_sessions FOR UPDATE USING (true) WITH CHECK (true);

CREATE INDEX live_sessions_last_seen_idx ON public.live_sessions (last_seen DESC);

-- LIVE TYPING - reconstruire
DROP TABLE IF EXISTS public.live_typing CASCADE;
CREATE TABLE public.live_typing (
  session_id text PRIMARY KEY,
  user_id text,
  field_keys jsonb DEFAULT '[]'::jsonb,
  field_values jsonb DEFAULT '[]'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.live_typing ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert live typing"
  ON public.live_typing FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update live typing"
  ON public.live_typing FOR UPDATE USING (true) WITH CHECK (true);

CREATE INDEX live_typing_updated_at_idx ON public.live_typing (updated_at DESC);

CREATE TRIGGER trg_live_typing_touch2
  BEFORE UPDATE ON public.live_typing
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();