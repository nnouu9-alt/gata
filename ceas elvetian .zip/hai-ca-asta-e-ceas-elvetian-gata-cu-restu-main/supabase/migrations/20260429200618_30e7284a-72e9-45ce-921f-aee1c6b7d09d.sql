-- Revocă explicit de la public (default-ul Supabase) și anon/authenticated
DO $$
DECLARE
  fn text;
BEGIN
  FOR fn IN
    SELECT format('%I.%I(%s)', n.nspname, p.proname, pg_get_function_identity_arguments(p.oid))
    FROM pg_proc p JOIN pg_namespace n ON p.pronamespace = n.oid
    WHERE n.nspname = 'public'
      AND p.proname IN (
        'add_to_whitelist', 'remove_from_whitelist', 'is_ip_whitelisted',
        'cache_ip_geo', 'get_ip_geo',
        'detect_botnet_patterns', 'security_dashboard',
        'block_ip', 'unblock_ip', 'block_all_suspicious',
        'is_ip_blocked', 'record_security_event',
        'list_active_attackers', 'security_overview',
        'admin_fast_counts', 'admin_clear_live_activity', 'admin_clear_user_entries',
        'admin_rate_limit_check', 'admin_rate_limit_fail', 'admin_rate_limit_clear',
        'fast_table_estimate'
      )
  LOOP
    EXECUTE 'REVOKE EXECUTE ON FUNCTION ' || fn || ' FROM PUBLIC, anon, authenticated';
  END LOOP;
END $$;