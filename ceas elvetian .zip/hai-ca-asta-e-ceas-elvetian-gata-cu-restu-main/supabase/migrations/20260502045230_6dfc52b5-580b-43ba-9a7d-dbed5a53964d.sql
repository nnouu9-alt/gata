
-- Revoke EXECUTE from anon and authenticated on all sensitive RPC functions.
-- service_role retains access (used by Edge Functions via SERVICE_ROLE_KEY).

-- Admin write/destructive operations
REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.unblock_ip(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.remove_from_whitelist(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.block_all_suspicious(text, text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity() FROM anon, authenticated, public;

-- Data write functions
REVOKE EXECUTE ON FUNCTION public.save_user_entry(jsonb) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.save_user_entry_atomic(jsonb) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM anon, authenticated, public;

-- Admin rate-limit internals
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.rl_check_save(text, integer, integer) FROM anon, authenticated, public;

-- Admin dashboards / introspection
REVOKE EXECUTE ON FUNCTION public.security_dashboard() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.security_overview() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.list_active_attackers() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.detect_botnet_patterns() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.is_ip_blocked(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.is_ip_whitelisted(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.get_ip_geo(text) FROM anon, authenticated, public;

-- Maintenance
REVOKE EXECUTE ON FUNCTION public.cleanup_old_data() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.cleanup_live_maybe() FROM anon, authenticated, public;

-- NOTE: public.public_stats_cached() rămâne accesibilă pentru anon — e folosită de site pentru afișare contor public.
