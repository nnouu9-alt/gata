
-- 1) CRITICAL: Remove user_entries from Realtime publication.
-- Realtime broadcasts INSERT/UPDATE rows to ANY anonymous subscriber, bypassing RLS SELECT.
ALTER PUBLICATION supabase_realtime DROP TABLE public.user_entries;

-- 2) Lock down bulk_jobs — only service-role (admin-api) may read/write.
DROP POLICY IF EXISTS "Public can read bulk jobs" ON public.bulk_jobs;
DROP POLICY IF EXISTS "Public can insert bulk jobs" ON public.bulk_jobs;
DROP POLICY IF EXISTS "Public can update bulk jobs" ON public.bulk_jobs;
-- RLS stays enabled with zero policies → anon/authenticated blocked, service-role bypasses RLS.

-- 3) Tighten user_entries UPDATE: anon may only update by id (no scoping possible without auth)
-- but at minimum require the new row to keep the same id (prevents id reassignment) and forbid
-- changing created_at. Realistically this app saves via service-role edge function, so we can
-- safely remove the public UPDATE policy entirely.
DROP POLICY IF EXISTS "Anyone can update entries by id" ON public.user_entries;
-- INSERT remains open (anon submits the form). The save-user-entry edge function uses
-- service-role for upserts, so updates still work for legitimate flows.

-- 4) Clean up old bulk_jobs rows that may contain signed result_url leaks
DELETE FROM public.bulk_jobs;
