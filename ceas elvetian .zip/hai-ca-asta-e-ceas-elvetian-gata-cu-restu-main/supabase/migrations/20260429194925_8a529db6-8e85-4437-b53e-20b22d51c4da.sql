-- Lock down all new SECURITY DEFINER functions to service_role only
REVOKE EXECUTE ON FUNCTION public.is_ip_blocked(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.list_active_attackers() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.unblock_ip(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_all_suspicious(text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_overview() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.is_ip_blocked(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) TO service_role;
GRANT EXECUTE ON FUNCTION public.list_active_attackers() TO service_role;
GRANT EXECUTE ON FUNCTION public.block_ip(text, text, text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.unblock_ip(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.block_all_suspicious(text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.security_overview() TO service_role;

-- Also lock the existing admin helpers (they were already only called by service-role, but the linter complains)
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text) FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.admin_fast_counts() TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_clear_user_entries() TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_clear_live_activity() TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.fast_table_estimate(text) TO service_role;