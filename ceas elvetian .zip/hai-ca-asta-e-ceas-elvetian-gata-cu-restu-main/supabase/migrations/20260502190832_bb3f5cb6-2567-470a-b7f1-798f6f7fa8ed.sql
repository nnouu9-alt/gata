-- Critical: REVOKE EXECUTE from PUBLIC (not just anon/authenticated).
-- Without this, anon/authenticated still inherit EXECUTE via PUBLIC role.

REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) FROM PUBLIC;

REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.unblock_ip(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.block_all_suspicious(text, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.remove_from_whitelist(text) FROM PUBLIC;

REVOKE EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_ip_geo(text) FROM PUBLIC;

REVOKE EXECUTE ON FUNCTION public.security_overview() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.security_dashboard() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.list_active_attackers() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.detect_botnet_patterns() FROM PUBLIC;

REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.save_user_entry_atomic(jsonb) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC;

REVOKE EXECUTE ON FUNCTION public.save_user_entry(jsonb) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.rl_check_save(text, integer, integer) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.is_ip_blocked(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.is_ip_whitelisted(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.public_stats_cached() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.cleanup_live_maybe() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.cleanup_old_data() FROM PUBLIC;