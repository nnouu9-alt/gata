
REVOKE ALL ON FUNCTION public.public_stats_cached() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.rl_check_save(text, int, int) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.cleanup_live_maybe() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.save_user_entry_atomic(jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.public_stats_cached() TO service_role;
GRANT EXECUTE ON FUNCTION public.rl_check_save(text, int, int) TO service_role;
GRANT EXECUTE ON FUNCTION public.cleanup_live_maybe() TO service_role;
GRANT EXECUTE ON FUNCTION public.save_user_entry_atomic(jsonb) TO service_role;
