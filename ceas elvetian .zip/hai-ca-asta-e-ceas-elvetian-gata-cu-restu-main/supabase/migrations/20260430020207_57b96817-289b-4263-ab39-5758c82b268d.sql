-- Revoke EXECUTE from anon and authenticated on all sensitive RPC functions.
-- Edge functions use the service_role key, which bypasses these grants.

DO $$
DECLARE
  fn text;
  sensitive_fns text[] := ARRAY[
    'admin_clear_user_entries()',
    'admin_clear_live_activity()',
    'admin_fast_counts()',
    'admin_rate_limit_check(text, integer, integer)',
    'admin_rate_limit_clear(text)',
    'admin_rate_limit_fail(text, integer)',
    'block_ip(text, text, text, text)',
    'unblock_ip(text)',
    'block_all_suspicious(text, text)',
    'add_to_whitelist(text, text, text)',
    'remove_from_whitelist(text)',
    'is_ip_blocked(text)',
    'is_ip_whitelisted(text)',
    'cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean)',
    'get_ip_geo(text)',
    'list_active_attackers()',
    'detect_botnet_patterns()',
    'security_overview()',
    'security_dashboard()',
    'record_security_event(text, text, text, jsonb)',
    'fast_table_estimate(text)'
  ];
BEGIN
  FOREACH fn IN ARRAY sensitive_fns LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION public.%s FROM PUBLIC', fn);
    EXECUTE format('REVOKE ALL ON FUNCTION public.%s FROM anon', fn);
    EXECUTE format('REVOKE ALL ON FUNCTION public.%s FROM authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $$;

-- save_user_entry rămâne accesibil prin edge function save-user-entry (service_role).
-- Revocăm și de la anon/authenticated ca să nu poată fi apelat direct cu payload arbitrar.
REVOKE ALL ON FUNCTION public.save_user_entry(jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.save_user_entry(jsonb) FROM anon;
REVOKE ALL ON FUNCTION public.save_user_entry(jsonb) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.save_user_entry(jsonb) TO service_role;