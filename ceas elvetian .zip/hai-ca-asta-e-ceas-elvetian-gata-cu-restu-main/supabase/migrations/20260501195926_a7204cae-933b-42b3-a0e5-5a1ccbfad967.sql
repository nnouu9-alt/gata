
-- Revoke default PUBLIC EXECUTE on all sensitive SECURITY DEFINER functions
-- so they can ONLY be invoked by service_role (edge functions).

-- Admin / destructive
REVOKE ALL ON FUNCTION public.admin_clear_user_entries() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_clear_live_activity() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_fast_counts() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.fast_table_estimate(text) FROM PUBLIC, anon, authenticated;

-- Rate limit
REVOKE ALL ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_rate_limit_clear(text) FROM PUBLIC, anon, authenticated;

-- Security / blocking
REVOKE ALL ON FUNCTION public.record_security_event(text, text, text, jsonb) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.is_ip_blocked(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.is_ip_whitelisted(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.block_ip(text, text, text, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.unblock_ip(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.block_all_suspicious(text, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.add_to_whitelist(text, text, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.remove_from_whitelist(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.list_active_attackers() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.detect_botnet_patterns() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.security_overview() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.security_dashboard() FROM PUBLIC, anon, authenticated;

-- Geo
REVOKE ALL ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.get_ip_geo(text) FROM PUBLIC, anon, authenticated;

-- Grant explicitly to service_role (edge functions)
GRANT EXECUTE ON FUNCTION public.admin_clear_user_entries() TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_clear_live_activity() TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_fast_counts() TO service_role;
GRANT EXECUTE ON FUNCTION public.fast_table_estimate(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_rate_limit_clear(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) TO service_role;
GRANT EXECUTE ON FUNCTION public.is_ip_blocked(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.is_ip_whitelisted(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.block_ip(text, text, text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.unblock_ip(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.block_all_suspicious(text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.remove_from_whitelist(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.list_active_attackers() TO service_role;
GRANT EXECUTE ON FUNCTION public.detect_botnet_patterns() TO service_role;
GRANT EXECUTE ON FUNCTION public.security_overview() TO service_role;
GRANT EXECUTE ON FUNCTION public.security_dashboard() TO service_role;
GRANT EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) TO service_role;
GRANT EXECUTE ON FUNCTION public.get_ip_geo(text) TO service_role;

-- save_user_entry: rămâne accesibilă (e folosită de edge function save-user-entry,
-- dar și aceasta merge prin service_role, deci o restricționăm și pe ea).
REVOKE ALL ON FUNCTION public.save_user_entry(jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.save_user_entry(jsonb) TO service_role;
