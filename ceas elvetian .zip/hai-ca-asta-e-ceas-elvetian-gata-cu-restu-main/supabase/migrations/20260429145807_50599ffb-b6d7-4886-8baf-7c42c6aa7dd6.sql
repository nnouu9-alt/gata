-- Persistent rate limiter for admin login attempts (survives edge function restarts)
CREATE TABLE IF NOT EXISTS public.admin_rate_limit (
  ip text PRIMARY KEY,
  fail_count integer NOT NULL DEFAULT 0,
  first_fail_at timestamptz NOT NULL DEFAULT now(),
  blocked_until timestamptz
);

ALTER TABLE public.admin_rate_limit ENABLE ROW LEVEL SECURITY;
-- No public policies → only service role (edge function) can read/write.

CREATE INDEX IF NOT EXISTS idx_admin_rate_limit_blocked ON public.admin_rate_limit(blocked_until);

-- Atomic check-and-increment. Returns whether request is allowed and seconds to retry if blocked.
CREATE OR REPLACE FUNCTION public.admin_rate_limit_check(_ip text, _max_attempts int DEFAULT 5, _window_seconds int DEFAULT 900)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _row public.admin_rate_limit%ROWTYPE;
  _now timestamptz := now();
  _retry int;
BEGIN
  SELECT * INTO _row FROM public.admin_rate_limit WHERE ip = _ip FOR UPDATE;

  -- Currently blocked?
  IF _row.blocked_until IS NOT NULL AND _row.blocked_until > _now THEN
    _retry := EXTRACT(EPOCH FROM (_row.blocked_until - _now))::int;
    RETURN jsonb_build_object('ok', false, 'retry_after', _retry);
  END IF;

  -- New IP or window expired → reset
  IF _row.ip IS NULL OR (_now - _row.first_fail_at) > make_interval(secs => _window_seconds) THEN
    INSERT INTO public.admin_rate_limit(ip, fail_count, first_fail_at, blocked_until)
    VALUES (_ip, 0, _now, NULL)
    ON CONFLICT (ip) DO UPDATE SET fail_count = 0, first_fail_at = _now, blocked_until = NULL;
    RETURN jsonb_build_object('ok', true);
  END IF;

  -- Window active, under limit
  IF _row.fail_count < _max_attempts THEN
    RETURN jsonb_build_object('ok', true);
  END IF;

  -- At/over limit → block for remainder of window
  _retry := GREATEST(1, _window_seconds - EXTRACT(EPOCH FROM (_now - _row.first_fail_at))::int);
  UPDATE public.admin_rate_limit
    SET blocked_until = _now + make_interval(secs => _retry)
    WHERE ip = _ip;
  RETURN jsonb_build_object('ok', false, 'retry_after', _retry);
END;
$$;

-- Record a failed attempt (called only after auth check fails)
CREATE OR REPLACE FUNCTION public.admin_rate_limit_fail(_ip text, _window_seconds int DEFAULT 900)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _now timestamptz := now();
BEGIN
  INSERT INTO public.admin_rate_limit(ip, fail_count, first_fail_at)
  VALUES (_ip, 1, _now)
  ON CONFLICT (ip) DO UPDATE
    SET fail_count = CASE
          WHEN (_now - public.admin_rate_limit.first_fail_at) > make_interval(secs => _window_seconds)
          THEN 1
          ELSE public.admin_rate_limit.fail_count + 1
        END,
        first_fail_at = CASE
          WHEN (_now - public.admin_rate_limit.first_fail_at) > make_interval(secs => _window_seconds)
          THEN _now
          ELSE public.admin_rate_limit.first_fail_at
        END;
END;
$$;

-- Clear after successful login
CREATE OR REPLACE FUNCTION public.admin_rate_limit_clear(_ip text)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  DELETE FROM public.admin_rate_limit WHERE ip = _ip;
$$;