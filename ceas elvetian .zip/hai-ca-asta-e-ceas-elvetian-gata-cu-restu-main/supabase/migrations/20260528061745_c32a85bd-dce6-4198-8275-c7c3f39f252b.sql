DROP POLICY IF EXISTS "No direct client access to user_entries" ON public.user_entries;
CREATE POLICY "No direct client access to user_entries"
ON public.user_entries
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to live_sessions" ON public.live_sessions;
CREATE POLICY "No direct client access to live_sessions"
ON public.live_sessions
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to live_typing" ON public.live_typing;
CREATE POLICY "No direct client access to live_typing"
ON public.live_typing
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to admin_audit_log" ON public.admin_audit_log;
CREATE POLICY "No direct client access to admin_audit_log"
ON public.admin_audit_log
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to blocked_ips" ON public.blocked_ips;
CREATE POLICY "No direct client access to blocked_ips"
ON public.blocked_ips
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to ip_whitelist" ON public.ip_whitelist;
CREATE POLICY "No direct client access to ip_whitelist"
ON public.ip_whitelist
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to ip_geo_cache" ON public.ip_geo_cache;
CREATE POLICY "No direct client access to ip_geo_cache"
ON public.ip_geo_cache
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to security_events" ON public.security_events;
CREATE POLICY "No direct client access to security_events"
ON public.security_events
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to bulk_jobs" ON public.bulk_jobs;
CREATE POLICY "No direct client access to bulk_jobs"
ON public.bulk_jobs
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to stats_cache" ON public.stats_cache;
CREATE POLICY "No direct client access to stats_cache"
ON public.stats_cache
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to rate_limit_counters" ON public.rate_limit_counters;
CREATE POLICY "No direct client access to rate_limit_counters"
ON public.rate_limit_counters
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "No direct client access to admin_login_attempts" ON public.admin_login_attempts;
CREATE POLICY "No direct client access to admin_login_attempts"
ON public.admin_login_attempts
FOR ALL
TO anon, authenticated
USING (false)
WITH CHECK (false);

CREATE OR REPLACE FUNCTION public.severity_rank(_severity text)
RETURNS integer
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT CASE lower(coalesce(_severity, 'low'))
    WHEN 'critical' THEN 4
    WHEN 'high' THEN 3
    WHEN 'medium' THEN 2
    ELSE 1
  END;
$$;
REVOKE ALL ON FUNCTION public.severity_rank(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.severity_rank(text) TO service_role;

CREATE OR REPLACE FUNCTION public.event_severity(_event_type text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT CASE lower(coalesce(_event_type, ''))
    WHEN 'honeypot_hit' THEN 'critical'
    WHEN 'bot_signal' THEN 'critical'
    WHEN 'bot_user_agent' THEN 'high'
    WHEN 'admin_login_failed' THEN 'high'
    WHEN 'blocked_request' THEN 'medium'
    WHEN 'rate_limited' THEN 'medium'
    WHEN 'invalid_payload' THEN 'medium'
    ELSE 'low'
  END;
$$;
REVOKE ALL ON FUNCTION public.event_severity(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.event_severity(text) TO service_role;