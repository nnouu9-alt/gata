CREATE POLICY "Public can read live sessions"
  ON public.live_sessions FOR SELECT USING (true);

CREATE POLICY "Public can read live typing"
  ON public.live_typing FOR SELECT USING (true);