
-- Explicit DENY-all on admin-exports bucket for anon + authenticated.
-- Service-role bypasses RLS so edge functions still work.
CREATE POLICY "Block all anon access to admin-exports"
ON storage.objects FOR ALL
TO anon
USING (bucket_id <> 'admin-exports')
WITH CHECK (bucket_id <> 'admin-exports');

CREATE POLICY "Block all authenticated access to admin-exports"
ON storage.objects FOR ALL
TO authenticated
USING (bucket_id <> 'admin-exports')
WITH CHECK (bucket_id <> 'admin-exports');
