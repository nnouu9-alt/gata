REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.fast_table_estimate(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_fast_counts() TO service_role;