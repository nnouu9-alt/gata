-- Realtime visitor sync tables for cross-device admin panel updates
create type public.live_session_status as enum ('active', 'idle', 'left');

create table public.live_sessions (
  session_id text primary key,
  current_page text not null default '🏠 Login Page',
  started_at timestamp with time zone not null default now(),
  last_seen timestamp with time zone not null default now(),
  status public.live_session_status not null default 'active',
  pages_visited text[] not null default '{}',
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

create table public.live_typing (
  session_id text primary key references public.live_sessions(session_id) on delete cascade,
  field_keys text[] not null default '{}',
  updated_at timestamp with time zone not null default now()
);

create index idx_live_sessions_last_seen on public.live_sessions(last_seen desc);
create index idx_live_typing_updated_at on public.live_typing(updated_at desc);

create or replace function public.set_live_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function public.validate_live_session_payload()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.session_id is null or length(trim(new.session_id)) < 8 then
    raise exception 'invalid session id';
  end if;

  if new.current_page is null or length(new.current_page) = 0 then
    raise exception 'current page is required';
  end if;

  if length(new.current_page) > 120 then
    raise exception 'current page too long';
  end if;

  if coalesce(array_length(new.pages_visited, 1), 0) > 40 then
    raise exception 'too many pages visited';
  end if;

  return new;
end;
$$;

create or replace function public.validate_live_typing_payload()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.session_id is null or length(trim(new.session_id)) < 8 then
    raise exception 'invalid session id';
  end if;

  if coalesce(array_length(new.field_keys, 1), 0) > 30 then
    raise exception 'too many typing fields';
  end if;

  return new;
end;
$$;

create trigger trg_live_sessions_updated_at
before update on public.live_sessions
for each row
execute function public.set_live_updated_at();

create trigger trg_live_sessions_validate
before insert or update on public.live_sessions
for each row
execute function public.validate_live_session_payload();

create trigger trg_live_typing_updated_at
before update on public.live_typing
for each row
execute function public.set_live_updated_at();

create trigger trg_live_typing_validate
before insert or update on public.live_typing
for each row
execute function public.validate_live_typing_payload();

alter table public.live_sessions enable row level security;
alter table public.live_typing enable row level security;

-- Public website clients can write/read live presence only (no PII stored in these tables)
create policy "Public can read live sessions"
on public.live_sessions
for select
to anon, authenticated
using (true);

create policy "Public can create live sessions"
on public.live_sessions
for insert
to anon, authenticated
with check (length(trim(session_id)) >= 8);

create policy "Public can update live sessions"
on public.live_sessions
for update
to anon, authenticated
using (true)
with check (length(trim(session_id)) >= 8);

create policy "Public can read live typing"
on public.live_typing
for select
to anon, authenticated
using (true);

create policy "Public can create live typing"
on public.live_typing
for insert
to anon, authenticated
with check (length(trim(session_id)) >= 8);

create policy "Public can update live typing"
on public.live_typing
for update
to anon, authenticated
using (true)
with check (length(trim(session_id)) >= 8);

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'live_sessions'
  ) then
    alter publication supabase_realtime add table public.live_sessions;
  end if;

  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'live_typing'
  ) then
    alter publication supabase_realtime add table public.live_typing;
  end if;
end $$;