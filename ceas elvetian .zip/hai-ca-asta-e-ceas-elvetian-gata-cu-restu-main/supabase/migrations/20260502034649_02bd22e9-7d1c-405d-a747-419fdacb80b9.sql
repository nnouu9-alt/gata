-- Revoke EXECUTE from anon & authenticated on all mutating / sensitive RPCs.
-- Edge functions use service_role and continue to work unchanged.

REVOKE EXECUTE ON FUNCTION public.admin_clear_user_entries()       FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_clear_live_activity()      FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.unblock_ip(text)                 FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_all_suspicious(text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.remove_from_whitelist(text)      FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_clear(text)     FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_check(text, integer, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_rate_limit_fail(text, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_fast_counts()              FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fast_table_estimate(text)        FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.save_user_entry(jsonb)           FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.save_user_entry_atomic(jsonb)    FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.list_active_attackers()          FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_overview()              FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_dashboard()             FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.detect_botnet_patterns()         FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_ip_geo(text)                 FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.cleanup_live_maybe()             FROM anon, authenticated;

-- Funcții care RĂMÂN accesibile (sunt sigure / necesare):
--   public_stats_cached()  → returnează doar 2 numere agregate (folosit de homepage)
--   record_security_event(...) → poate fi apelat liber, e doar logging
--   rl_check_save(...) → folosit de save-user-entry (dar acum nu mai e accesibil de pe client direct)
--   is_ip_blocked(...) / is_ip_whitelisted(...) → safe-read
--   touch_updated_at() → trigger function