-- Schedule cleanup_old_data to run every 6 hours
DO $$
DECLARE
  _existing_jobid bigint;
BEGIN
  SELECT jobid INTO _existing_jobid FROM cron.job WHERE jobname = 'cleanup-old-data-6h';
  IF _existing_jobid IS NOT NULL THEN
    PERFORM cron.unschedule(_existing_jobid);
  END IF;
END $$;

SELECT cron.schedule(
  'cleanup-old-data-6h',
  '0 */6 * * *',
  $$SELECT public.cleanup_old_data();$$
);