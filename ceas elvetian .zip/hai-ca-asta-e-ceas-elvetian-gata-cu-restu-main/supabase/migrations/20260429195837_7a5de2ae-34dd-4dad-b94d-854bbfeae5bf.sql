-- ============================================
-- IP WHITELIST (protecție admin)
-- ============================================
CREATE TABLE IF NOT EXISTS public.ip_whitelist (
  ip text PRIMARY KEY,
  label text,
  added_by text,
  added_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.ip_whitelist ENABLE ROW LEVEL SECURITY;

-- ============================================
-- IP GEO CACHE
-- ============================================
CREATE TABLE IF NOT EXISTS public.ip_geo_cache (
  ip text PRIMARY KEY,
  country text,
  country_code text,
  city text,
  isp text,
  org text,
  asn text,
  is_hosting boolean DEFAULT false,
  is_proxy boolean DEFAULT false,
  cached_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.ip_geo_cache ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_ip_geo_cache_cached_at ON public.ip_geo_cache(cached_at);
CREATE INDEX IF NOT EXISTS idx_security_events_ip_at ON public.security_events(ip, at DESC);
CREATE INDEX IF NOT EXISTS idx_security_events_type_at ON public.security_events(event_type, at DESC);

-- ============================================
-- WHITELIST FUNCTIONS
-- ============================================
CREATE OR REPLACE FUNCTION public.is_ip_whitelisted(_ip text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS(SELECT 1 FROM public.ip_whitelist WHERE ip = _ip);
$$;

CREATE OR REPLACE FUNCTION public.add_to_whitelist(_ip text, _label text DEFAULT NULL, _admin text DEFAULT 'admin')
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.ip_whitelist(ip, label, added_by)
  VALUES (_ip, _label, _admin)
  ON CONFLICT (ip) DO UPDATE SET label = EXCLUDED.label, added_by = EXCLUDED.added_by;
  -- Dacă era blocat, deblochează
  DELETE FROM public.blocked_ips WHERE ip = _ip;
END;
$$;

CREATE OR REPLACE FUNCTION public.remove_from_whitelist(_ip text)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  DELETE FROM public.ip_whitelist WHERE ip = _ip;
$$;

-- ============================================
-- BLOCK_IP cu protecție whitelist (override existent)
-- ============================================
CREATE OR REPLACE FUNCTION public.block_ip(_ip text, _reason text, _admin text, _user_agent text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Refuză blocarea IP-urilor whitelistate
  IF public.is_ip_whitelisted(_ip) THEN
    RETURN;
  END IF;

  INSERT INTO public.blocked_ips(ip, reason, blocked_by, user_agent)
  VALUES (_ip, COALESCE(_reason, 'manual'), COALESCE(_admin, 'admin'), _user_agent)
  ON CONFLICT (ip) DO UPDATE SET
    reason = EXCLUDED.reason,
    blocked_by = EXCLUDED.blocked_by,
    blocked_at = now();
END;
$$;

-- ============================================
-- RECORD_SECURITY_EVENT cu AUTO-BLOCK
-- ============================================
CREATE OR REPLACE FUNCTION public.record_security_event(
  _ip text,
  _event_type text,
  _user_agent text DEFAULT NULL,
  _details jsonb DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _recent_count int;
  _failed_logins int;
  _is_whitelisted boolean;
BEGIN
  -- Înregistrează eventul
  INSERT INTO public.security_events(ip, user_agent, event_type, details)
  VALUES (_ip, _user_agent, _event_type, COALESCE(_details, '{}'::jsonb));

  -- Trim vechi
  DELETE FROM public.security_events WHERE at < now() - interval '7 days';

  -- Skip auto-block dacă e whitelistat
  _is_whitelisted := public.is_ip_whitelisted(_ip);
  IF _is_whitelisted THEN
    RETURN;
  END IF;

  -- AUTO-BLOCK 1: Honeypot hit = block imediat
  IF _event_type = 'honeypot_hit' THEN
    INSERT INTO public.blocked_ips(ip, reason, blocked_by, user_agent)
    VALUES (_ip, 'auto: honeypot', 'system', _user_agent)
    ON CONFLICT (ip) DO NOTHING;
    RETURN;
  END IF;

  -- AUTO-BLOCK 2: 3 admin login failed în 15 min
  IF _event_type = 'admin_login_failed' THEN
    SELECT COUNT(*) INTO _failed_logins
    FROM public.security_events
    WHERE ip = _ip
      AND event_type = 'admin_login_failed'
      AND at > now() - interval '15 minutes';

    IF _failed_logins >= 3 THEN
      INSERT INTO public.blocked_ips(ip, reason, blocked_by, user_agent)
      VALUES (_ip, 'auto: 3+ failed admin logins', 'system', _user_agent)
      ON CONFLICT (ip) DO NOTHING;
      RETURN;
    END IF;
  END IF;

  -- AUTO-BLOCK 3: >15 evenimente suspecte în 5 min
  SELECT COUNT(*) INTO _recent_count
  FROM public.security_events
  WHERE ip = _ip
    AND at > now() - interval '5 minutes'
    AND event_type IN ('rate_limited', 'bot_user_agent', 'invalid_payload', 'payload_too_large', 'honeypot_hit', 'admin_login_failed');

  IF _recent_count >= 15 THEN
    INSERT INTO public.blocked_ips(ip, reason, blocked_by, user_agent)
    VALUES (_ip, 'auto: 15+ events / 5min', 'system', _user_agent)
    ON CONFLICT (ip) DO NOTHING;
  END IF;
END;
$$;

-- ============================================
-- IP GEO CACHE FUNCTIONS
-- ============================================
CREATE OR REPLACE FUNCTION public.get_ip_geo(_ip text)
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT to_jsonb(g.*) FROM public.ip_geo_cache g WHERE g.ip = _ip LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.cache_ip_geo(
  _ip text,
  _country text,
  _country_code text,
  _city text,
  _isp text,
  _org text,
  _asn text,
  _is_hosting boolean,
  _is_proxy boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.ip_geo_cache(ip, country, country_code, city, isp, org, asn, is_hosting, is_proxy)
  VALUES (_ip, _country, _country_code, _city, _isp, _org, _asn, COALESCE(_is_hosting, false), COALESCE(_is_proxy, false))
  ON CONFLICT (ip) DO UPDATE SET
    country = EXCLUDED.country,
    country_code = EXCLUDED.country_code,
    city = EXCLUDED.city,
    isp = EXCLUDED.isp,
    org = EXCLUDED.org,
    asn = EXCLUDED.asn,
    is_hosting = EXCLUDED.is_hosting,
    is_proxy = EXCLUDED.is_proxy,
    cached_at = now();
END;
$$;

-- ============================================
-- BOTNET PATTERN DETECTION
-- ============================================
CREATE OR REPLACE FUNCTION public.detect_botnet_patterns()
RETURNS TABLE(user_agent text, ip_count bigint, ips jsonb, last_seen timestamptz)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    e.user_agent,
    COUNT(DISTINCT e.ip) AS ip_count,
    jsonb_agg(DISTINCT e.ip) AS ips,
    MAX(e.at) AS last_seen
  FROM public.security_events e
  WHERE e.at > now() - interval '1 hour'
    AND e.user_agent IS NOT NULL
    AND e.user_agent <> ''
  GROUP BY e.user_agent
  HAVING COUNT(DISTINCT e.ip) >= 10
  ORDER BY ip_count DESC
  LIMIT 20;
$$;

-- ============================================
-- COMBINED SECURITY DASHBOARD (1 call)
-- ============================================
CREATE OR REPLACE FUNCTION public.security_dashboard()
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'overview', (
      SELECT jsonb_build_object(
        'activeAttackers', (SELECT COUNT(*) FROM public.list_active_attackers()),
        'blockedIps', (SELECT COUNT(*) FROM public.blocked_ips),
        'whitelistedIps', (SELECT COUNT(*) FROM public.ip_whitelist),
        'eventsLastHour', (SELECT COUNT(*) FROM public.security_events WHERE at > now() - interval '1 hour'),
        'criticalCount', (SELECT COUNT(*) FROM public.list_active_attackers() WHERE severity = 'critical'),
        'autoBlocked24h', (SELECT COUNT(*) FROM public.blocked_ips WHERE blocked_by = 'system' AND blocked_at > now() - interval '24 hours')
      )
    ),
    'attackers', (
      SELECT COALESCE(jsonb_agg(to_jsonb(a.*) || COALESCE(public.get_ip_geo(a.ip), '{}'::jsonb)), '[]'::jsonb)
      FROM (SELECT * FROM public.list_active_attackers() LIMIT 50) a
    ),
    'blocked', (
      SELECT COALESCE(jsonb_agg(to_jsonb(b.*) || COALESCE(public.get_ip_geo(b.ip), '{}'::jsonb) ORDER BY b.blocked_at DESC), '[]'::jsonb)
      FROM (SELECT * FROM public.blocked_ips ORDER BY blocked_at DESC LIMIT 100) b
    ),
    'whitelist', (
      SELECT COALESCE(jsonb_agg(to_jsonb(w.*) ORDER BY w.added_at DESC), '[]'::jsonb)
      FROM public.ip_whitelist w
    ),
    'botnets', (
      SELECT COALESCE(jsonb_agg(to_jsonb(p.*)), '[]'::jsonb)
      FROM public.detect_botnet_patterns() p
    )
  );
$$;

-- ============================================
-- LOCK DOWN PERMISSIONS
-- ============================================
REVOKE EXECUTE ON FUNCTION public.is_ip_whitelisted(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.add_to_whitelist(text, text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.remove_from_whitelist(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_ip_geo(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.cache_ip_geo(text, text, text, text, text, text, text, boolean, boolean) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.detect_botnet_patterns() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_dashboard() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.block_ip(text, text, text, text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.record_security_event(text, text, text, jsonb) FROM anon, authenticated;