// redeploy 1779944431
// redeploy: 1779943933
// redeploy: 1779946460
// Server-side route validation. Receives a path segment and returns whether
// it matches the secret slug stored in ADMIN_SLUG. The slug NEVER appears in
// the client bundle — not even as a hash. Constant-time compare + rate limit.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { makeCorsHeaders, safeEqual } from "../_shared/cors.ts";
import { isPreviewRequest } from "../_shared/preview.ts";

const normalizeSlug = (value: string | null | undefined) => {
  const raw = (value ?? "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .trim();
  if (!raw) return "";
  let decoded = raw;
  try { decoded = decodeURIComponent(raw); } catch {}
  return decoded.replace(/^\/+/, "").replace(/\/+$/, "").split(/[?#]/)[0].trim();
};

const json = (data: unknown, status = 200, req: Request) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...makeCorsHeaders(req), "Content-Type": "application/json" },
  });

const BOT_UA_PATTERNS = [
  "curl/", "wget/", "python-requests", "python-urllib", "go-http-client",
  "java/", "okhttp/", "httpclient", "libwww-perl", "scrapy", "httpie",
  "postmanruntime", "insomnia", "axios/", "node-fetch",
];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: makeCorsHeaders(req) });
  if (req.method !== "POST") return json({ ok: false }, 405, req);

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("cf-connecting-ip") || "unknown";
  const userAgent = (req.headers.get("user-agent") || "").toLowerCase();

  // Always return same shape — never leak whether the secret is configured
  const slug = normalizeSlug(Deno.env.get("ADMIN_SLUG"));

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const sb = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // Block bots immediately — they have no business probing routes
  if (BOT_UA_PATTERNS.some((p) => userAgent.includes(p))) {
    try {
      await sb.rpc("record_security_event", {
        _ip: ip, _event_type: "bot_user_agent",
        _user_agent: userAgent.slice(0, 300),
        _details: { path: "route-check" } as any,
      });
    } catch {}
    return json({ ok: false }, 200, req);
  }

  // Hard block check — skipped for Lovable preview origins.
  const previewOrigin = isPreviewRequest(req);
  if (!previewOrigin) {
    try {
      const { data: blocked } = await sb.rpc("is_ip_blocked", { _ip: ip });
      if (blocked === true) return json({ ok: false }, 200, req);
    } catch {}
  }

  // Rate limit: max 10 route checks per minute per IP.
  try {
    const { data: rl } = await sb.rpc("rl_check_save", {
      _ip: ip, _max: 10, _window_seconds: 60,
    });
    if (rl && (rl as any).ok === false) {
      try {
        await sb.rpc("record_security_event", {
          _ip: ip, _event_type: "rate_limited",
          _user_agent: userAgent.slice(0, 300),
          _details: { path: "route-check" } as any,
        });
      } catch {}
      return json({ ok: false }, 200, req);
    }
  } catch {}

  let body: any;
  try { body = await req.json(); } catch { return json({ ok: false }, 200, req); }

  const candidate = normalizeSlug(typeof body?.p === "string" ? body.p : "");
  if (!candidate || candidate.length > 200 || candidate.includes("/")) {
    return json({ ok: false }, 200, req);
  }

  if (!slug) return json({ ok: false }, 200, req);

  const match = await safeEqual(candidate, slug);

  if (!match) {
    try {
      await sb.rpc("record_security_event", {
        _ip: ip, _event_type: "invalid_payload",
        _user_agent: userAgent.slice(0, 300),
        _details: { path: "route-check", reason: "no_match" } as any,
      });
    } catch {}
  }

  return json({ ok: match }, 200, req);
});
