// redeploy 1779944431
// redeploy: 1779943933
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { makeCorsHeaders, safeEqual as safeEqualHash } from '../_shared/cors.ts'

let _req: Request | null = null
const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...(_req ? makeCorsHeaders(_req) : {}), 'Content-Type': 'application/json' },
  })

const te = new TextEncoder()
const fromB64u = (value: string) => {
  const base64 = value.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(value.length / 4) * 4, '=')
  return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
}
const b64u = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
const signPayload = async (payload: string) => {
  const secret = Deno.env.get('ADMIN_SESSION_SECRET')
  if (!secret || secret.length < 16) throw new Error('ADMIN_SESSION_SECRET not configured')
  const key = await crypto.subtle.importKey('raw', te.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  return b64u(new Uint8Array(await crypto.subtle.sign('HMAC', key, te.encode(payload))))
}
async function checkAdminToken(token: unknown, _ip: string): Promise<boolean> {
  if (typeof token !== 'string' || !token.includes('.')) return false
  const [payload, sig] = token.split('.')
  if (!payload || !sig || !(await safeEqualHash(sig, await signPayload(payload)))) return false
  try {
    const data = JSON.parse(new TextDecoder().decode(fromB64u(payload)))
    return Number(data?.layer) >= 1 && Number(data?.exp) > Date.now()
  } catch { return false }
}

Deno.serve(async (req) => {
  _req = req
  if (req.method === 'OPTIONS') return new Response('ok', { headers: makeCorsHeaders(req) })
  try {
    if (req.method !== 'POST') return json({ ok: false, error: 'method_not_allowed' }, 405)
    let body: any = {}
    try { body = await req.json() } catch {}
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0].trim() || req.headers.get('cf-connecting-ip') || 'unknown'
    if (!(await checkAdminToken(body?.token, ip))) return json({ ok: false, error: 'unauthorized' }, 401)
    const id = typeof body?.id === 'string' ? body.id : ''
    if (!id) return json({ ok: false, error: 'missing_id' }, 400)

    const sb = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
      { auth: { persistSession: false } },
    )
    const { data, error } = await sb
      .from('bulk_jobs')
      .select('id, kind, total, processed, status, error_message, result_url, updated_at')
      .eq('id', id)
      .maybeSingle()
    if (error) return json({ ok: false, error: 'server_error' }, 500)
    if (!data) return json({ ok: false, error: 'not_found' }, 404)
    return json({ ok: true, job: data })
  } catch (_e: any) {
    return json({ ok: false, error: 'server_error' }, 500)
  }
})
