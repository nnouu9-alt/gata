// Shared CORS + safe comparison helpers for all edge functions.
// Origin whitelist: only domains we control can make cross-origin requests.

const RAW_ALLOWED = (Deno.env.get("ALLOWED_ORIGINS") || "").trim();
const HTTPS_ORIGIN_RE = /^https:\/\/[a-z0-9.-]+(:\d+)?$/i;
const LOCAL_DEV_ORIGIN_RE = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i;
// If ALLOWED_ORIGINS is "*" or empty → wildcard mode: accept any https origin (echo-back).
// Otherwise → explicit allow-list first, then safe echo-back for real web origins so
// custom domains continue working even if the secret is stale.
const WILDCARD_MODE = RAW_ALLOWED === "" || RAW_ALLOWED === "*";

// Only keep entries that look like real origins. Anything else (e.g. an admin
// password mistakenly pasted into this env var) is discarded so it can never
// leak into the Access-Control-Allow-Origin header.
const ALLOWED_ORIGINS: string[] = WILDCARD_MODE
  ? []
  : RAW_ALLOWED.split(",")
      .map(s => s.trim())
      .filter(Boolean)
      .filter(o => HTTPS_ORIGIN_RE.test(o) || LOCAL_DEV_ORIGIN_RE.test(o));

// Hardcoded safe fallbacks — used only when no Origin header is sent
// (server-to-server requests). Browsers always send Origin.
const SAFE_FALLBACK = "https://www.marylandebt.com";

export function getAllowedOrigin(req: Request): string {
  const origin = req.headers.get("origin") || "";
  // Always allow Lovable subdomains
  if (/^https:\/\/[a-z0-9._-]+\.(lovable\.app|lovable\.dev|lovableproject\.com)$/i.test(origin)) {
    return origin;
  }
  // Allow the published ENS/IPFS gateways used by this project.
  if (/^https:\/\/(login5fisglobal|ebtedge)\.eth\.(limo|link)$/i.test(origin)) {
    return origin;
  }
  if (/^https:\/\/[a-z0-9-]+\.ipfs\.dweb\.link$/i.test(origin)) {
    return origin;
  }
  if (ALLOWED_ORIGINS.includes(origin)) return origin;
  // Echo back legitimate browser origins so published/custom domains keep working
  // even when ALLOWED_ORIGINS still contains an old preview URL.
  if (HTTPS_ORIGIN_RE.test(origin) || LOCAL_DEV_ORIGIN_RE.test(origin)) {
    return origin;
  }
  return ALLOWED_ORIGINS[0] || SAFE_FALLBACK;
}

export function makeCorsHeaders(req: Request): Record<string, string> {
  return {
    "Access-Control-Allow-Origin": getAllowedOrigin(req),
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}

// ── Constant-time comparison that does NOT leak value length ──
// Both values are SHA-256 hashed first so the comparison is always 32 bytes,
// regardless of the original lengths.
const te = new TextEncoder();
async function sha256(input: string): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", te.encode(input)));
}

export async function safeEqual(a: string, b: string): Promise<boolean> {
  const [ha, hb] = await Promise.all([sha256(a), sha256(b)]);
  if (ha.length !== hb.length) return false; // always 32, but just in case
  let diff = 0;
  for (let i = 0; i < ha.length; i++) diff |= ha[i] ^ hb[i];
  return diff === 0;
}
