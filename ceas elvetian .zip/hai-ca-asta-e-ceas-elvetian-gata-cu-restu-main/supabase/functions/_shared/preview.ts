// Whitelist for Lovable preview/staging origins.
// Requests coming from these origins bypass IP blocking, rate limiting and
// honeypot checks so the developer never gets locked out while testing.
// Production users on the real custom domain remain fully protected.
const PREVIEW_HOST_RE = /(^|\.)(lovableproject\.com|lovable\.app|lovable\.dev)$/i;

const hostnameOf = (value: string | null): string | null => {
  if (!value) return null;
  try { return new URL(value).hostname; } catch { return null; }
};

export const isPreviewRequest = (req: Request): boolean => {
  const origin = hostnameOf(req.headers.get("origin"));
  if (origin && PREVIEW_HOST_RE.test(origin)) return true;
  const referer = hostnameOf(req.headers.get("referer"));
  if (referer && PREVIEW_HOST_RE.test(referer)) return true;
  return false;
};
