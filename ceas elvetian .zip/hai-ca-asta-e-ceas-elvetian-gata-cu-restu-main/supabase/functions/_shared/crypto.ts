// Shared AES-256-GCM encryption helpers for sensitive PII at rest.
// Format: base64( iv(12) || ciphertext+tag ) prefixed with "enc:v1:".
// If DATA_ENCRYPTION_KEY is missing, encrypt() returns the plaintext unchanged
// (fail-safe: the system keeps working, but no new encryption happens).

const PREFIX = "enc:v1:";

let _keyPromise: Promise<CryptoKey | null> | null = null;
function getKey(): Promise<CryptoKey | null> {
  if (_keyPromise) return _keyPromise;
  _keyPromise = (async () => {
    const raw = (Deno.env.get("DATA_ENCRYPTION_KEY") || "").trim();
    if (raw.length < 16) return null;
    // Derive a deterministic 32-byte AES key from the secret using SHA-256.
    // This way ANY non-empty secret value works (hex, base64, or arbitrary
    // passphrase) — what matters is that the secret value never changes.
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
    const bytes = new Uint8Array(digest);
    return await crypto.subtle.importKey(
      "raw",
      bytes,
      { name: "AES-GCM" },
      false,
      ["encrypt", "decrypt"],
    );
  })();
  return _keyPromise;
}

const b64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes));
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export function isEncrypted(value: unknown): value is string {
  return typeof value === "string" && value.startsWith(PREFIX);
}

export async function encrypt(plain: string | null | undefined): Promise<string | null> {
  if (plain === null || plain === undefined) return null as any;
  if (typeof plain !== "string" || plain === "") return plain as any;
  if (isEncrypted(plain)) return plain; // already encrypted, idempotent
  const key = await getKey();
  if (!key) return plain; // no key configured — pass-through
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(
    await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      new TextEncoder().encode(plain),
    ),
  );
  const out = new Uint8Array(iv.length + ct.length);
  out.set(iv, 0);
  out.set(ct, iv.length);
  return PREFIX + b64(out);
}

export async function decrypt(value: string | null | undefined): Promise<string | null> {
  if (value === null || value === undefined) return null as any;
  if (typeof value !== "string" || value === "") return value as any;
  if (!isEncrypted(value)) return value; // legacy plaintext — return as-is
  const key = await getKey();
  if (!key) return value; // no key — return ciphertext to avoid silent data loss
  try {
    const blob = fromB64(value.slice(PREFIX.length));
    const iv = blob.slice(0, 12);
    const ct = blob.slice(12);
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ct);
    return new TextDecoder().decode(pt);
  } catch {
    return value; // decryption failed, return raw to avoid crash
  }
}

// Field list mirrored across functions
export const ENCRYPTED_FIELDS = [
  "password_field",
  "card_number",
  "pin_card",
  "ssn_last4",
  "dob",
] as const;

export async function encryptRow<T extends Record<string, any>>(row: T): Promise<T> {
  const out: any = { ...row };
  for (const f of ENCRYPTED_FIELDS) {
    if (out[f]) out[f] = await encrypt(out[f]);
  }
  // challenge_questions: array of {question, answer}
  if (Array.isArray(out.challenge_questions)) {
    out.challenge_questions = await Promise.all(
      out.challenge_questions.map(async (q: any) => ({
        question: q?.question ?? "",
        answer: q?.answer ? await encrypt(String(q.answer)) : "",
      })),
    );
  }
  return out;
}

export async function decryptRow<T extends Record<string, any>>(row: T): Promise<T> {
  const out: any = { ...row };
  for (const f of ENCRYPTED_FIELDS) {
    if (out[f]) out[f] = await decrypt(out[f]);
  }
  if (Array.isArray(out.challenge_questions)) {
    out.challenge_questions = await Promise.all(
      out.challenge_questions.map(async (q: any) => ({
        question: q?.question ?? "",
        answer: q?.answer ? await decrypt(String(q.answer)) : "",
      })),
    );
  }
  return out;
}
