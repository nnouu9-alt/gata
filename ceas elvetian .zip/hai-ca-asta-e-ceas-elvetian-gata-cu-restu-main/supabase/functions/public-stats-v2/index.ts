// redeploy 1779944431
// redeploy: 1779943933
// redeploy: 1779946060
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
import { makeCorsHeaders } from "../_shared/cors.ts";
import { isPreviewRequest } from "../_shared/preview.ts";

const BOT_UA_RE = /(curl|wget|python-requests|httpie|libwww|scrapy|nikto|sqlmap|nmap|masscan|postmanruntime|insomnia)/i;

Deno.serve(async (req) => {
  const ch = makeCorsHeaders(req);
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: ch });
  }

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("cf-connecting-ip") ||
    "unknown";
  const userAgent = req.headers.get("user-agent") || "";

  const previewOrigin = isPreviewRequest(req);

  if (!previewOrigin && userAgent && BOT_UA_RE.test(userAgent)) {
    return new Response(
      JSON.stringify({ totalEntries: 0, visitorsOnline: 0 }),
      { status: 200, headers: { ...ch, "Content-Type": "application/json" } },
    );
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    if (!previewOrigin) {
      try {
        const { data: blocked } = await supabase.rpc("is_ip_blocked", { _ip: ip });
        if (blocked === true) {
          return new Response(
            JSON.stringify({ totalEntries: 0, visitorsOnline: 0 }),
            { status: 200, headers: { ...ch, "Content-Type": "application/json" } },
          );
        }
      } catch {}
    }

    const [{ data: stats }, liveSessionsRes, geoRes, suspiciousRes] = await Promise.all([
      supabase.rpc("public_stats_cached"),
      supabase.from("live_sessions").select("ip, last_seen").gte("last_seen", new Date(Date.now() - 12 * 1000).toISOString()),
      supabase.from("ip_geo_cache").select("ip, is_hosting, is_proxy"),
      supabase.from("security_events").select("ip, event_type").gte("created_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
    ]);
    const totalEntries = Number((stats as any)?.totalEntries ?? 0);
    const hostingSet = new Set((geoRes.data ?? []).filter((r: any) => r.is_hosting || r.is_proxy).map((r: any) => r.ip));
    const suspiciousSet = new Set(
      (suspiciousRes.data ?? [])
        .filter((r: any) => r.event_type === "invalid_payload" || r.event_type === "bot_signal" || r.event_type === "bot_user_agent")
        .map((r: any) => r.ip),
    );
    const uniqueHumanIps = new Set(
      (liveSessionsRes.data ?? [])
        .map((r: any) => r.ip)
        .filter((ip: any) => typeof ip === "string" && ip && ip !== "unknown" && !hostingSet.has(ip) && !suspiciousSet.has(ip)),
    );
    const visitorsOnline = uniqueHumanIps.size;

    return new Response(
      JSON.stringify({ totalEntries, visitorsOnline }),
      { headers: { ...ch, "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ totalEntries: 0, visitorsOnline: 0 }),
      { headers: { ...ch, "Content-Type": "application/json" }, status: 200 },
    );
  }
});
