// redeploy 1779944431
// redeploy: 1779943933
// redeploy: 1779946460
// Public-facing tracker. Service-role writes to live_sessions / live_typing
// so anon clients no longer need direct DB write access. Includes per-IP
// rate limiting + payload size caps to prevent abuse.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { makeCorsHeaders } from "../_shared/cors.ts";
import { isPreviewRequest } from "../_shared/preview.ts";

let _req: Request | null = null;
const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...(_req ? makeCorsHeaders(_req) : {}), "Content-Type": "application/json" },
  });

// Tracking is non-critical UI telemetry. Returning 403 for blocked IPs makes
// the Lovable preview surface it as a runtime error/blank screen, so security
// denials are reported as successful no-op responses instead.
const skipped = (reason: string, retryAfterMs = 10 * 60_000) =>
  json({ ok: true, skipped: reason, retryAfterMs, blocked: false });

// ── In-memory rate limiter (per edge instance) ──
// Cap: 60 requests / IP / 60s. Tracking sends ~2-4 req/min normally, so this
// only hits abusive clients trying to flood the table.
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = 60;
const ipHits = new Map<string, number[]>();

const isRateLimited = (ip: string): boolean => {
  const now = Date.now();
  const arr = ipHits.get(ip) ?? [];
  const fresh = arr.filter((t) => now - t < RATE_WINDOW_MS);
  fresh.push(now);
  ipHits.set(ip, fresh);
  // Cleanup stale entries occasionally
  if (ipHits.size > 5000) {
    for (const [k, v] of ipHits) {
      const f = v.filter((t) => now - t < RATE_WINDOW_MS);
      if (f.length === 0) ipHits.delete(k);
      else ipHits.set(k, f);
    }
  }
  return fresh.length > RATE_MAX;
};

const SAFE_STR = (v: unknown, max = 200): string | null => {
  if (typeof v !== "string") return null;
  const s = v.trim();
  if (!s) return null;
  return s.slice(0, max);
};

const SAFE_TS = (v: unknown): string => {
  if (typeof v === "string") {
    const d = new Date(v);
    if (!isNaN(d.getTime())) return d.toISOString();
  }
  return new Date().toISOString();
};

const STATUS_VALUES = new Set(["active", "left", "idle"]);
const MAX_PAGES = 50;
const MAX_FIELDS = 30;
const MAX_VALUE_LEN = 500;

const BOT_UA_RE = /(curl|wget|python-requests|httpie|libwww|scrapy|bot\b|crawler|spider|nikto|sqlmap|nmap|masscan)/i;

// Honeypot path patterns — fake routes attackers/scanners try
const HONEYPOT_RE = /(\/wp-admin|\/wp-login|\/\.env|\/admin\.php|\/phpmyadmin|\/xmlrpc\.php|\/\.git|\/config\.php|\/\.aws|\/shell\.php|\/cgi-bin)/i;

Deno.serve(async (req: Request) => {
  _req = req;
  if (req.method === "OPTIONS") return new Response("ok", { headers: makeCorsHeaders(req) });
  if (req.method !== "POST") return json({ ok: false, error: "method_not_allowed" }, 405);

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("cf-connecting-ip") ||
    "unknown";
  const userAgent = req.headers.get("user-agent") || "";

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const sb = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

  // Fire-and-forget security event recorder
  const recordEvent = (eventType: string, details: Record<string, unknown> = {}) => {
    sb.rpc("record_security_event", {
      _ip: ip,
      _event_type: eventType,
      _user_agent: userAgent.slice(0, 300),
      _details: details as any,
    }).then(() => {}, () => {});
  };

  // Block check — bypassed for Lovable preview origins (dev never gets locked out).
  const previewOrigin = isPreviewRequest(req);
  if (!previewOrigin) {
    try {
      const { data: blocked } = await sb.rpc("is_ip_blocked", { _ip: ip });
      if (blocked === true) {
        recordEvent("blocked_request", { path: "track-session" });
        return skipped("blocked");
      }
    } catch { /* fail-open on infra error */ }
  }

  // Honeypot detection — if currentPage hits a fake route, instant block
  // We sniff body before full validation; if path matches honeypot pattern, record + block
  const referer = req.headers.get("referer") || "";
  if (HONEYPOT_RE.test(referer)) {
    recordEvent("honeypot_hit", { source: "referer", value: referer.slice(0, 200) });
    return skipped("honeypot");
  }

  // Suspicious user-agent
  if (userAgent && BOT_UA_RE.test(userAgent)) {
    recordEvent("bot_user_agent", { ua: userAgent.slice(0, 200) });
  }

  if (isRateLimited(ip)) {
    recordEvent("rate_limited", {});
    return json({ ok: false, error: "rate_limited" }, 429);
  }

  // Hard cap on payload size
  const cl = Number(req.headers.get("content-length") ?? "0");
  if (cl > 50_000) {
    recordEvent("payload_too_large", { size: cl });
    return json({ ok: false, error: "payload_too_large" }, 413);
  }

  let body: any;
  try { body = await req.json(); }
  catch { recordEvent("invalid_payload", { reason: "json_parse" }); return json({ ok: false, error: "invalid_json" }, 400); }

  const kind = body?.kind;
  if (kind !== "session" && kind !== "typing") {
    recordEvent("invalid_payload", { reason: "bad_kind" });
    return json({ ok: false, error: "invalid_kind" }, 400);
  }

  const sessionId = SAFE_STR(body?.sessionId, 100);
  if (!sessionId) {
    recordEvent("invalid_payload", { reason: "missing_session" });
    return json({ ok: false, error: "missing_session_id" }, 400);
  }

  try {
    if (kind === "session") {
      const currentPage = SAFE_STR(body?.currentPage, 200) ?? "unknown";
      // Honeypot check on reported page
      if (HONEYPOT_RE.test(currentPage)) {
        recordEvent("honeypot_hit", { source: "currentPage", value: currentPage.slice(0, 200) });
        return skipped("honeypot");
      }
      // Block admin-slug-like paths from polluting live sessions (random 20+ char paths)
      if (/^\/[A-Za-z0-9_-]{20,}\/?$/.test(currentPage)) {
        return json({ ok: true, skipped: "admin_like" });
      }
      const startedAt = SAFE_TS(body?.startedAt);
      const status = STATUS_VALUES.has(body?.status) ? body.status : "active";
      const pagesRaw = Array.isArray(body?.pagesVisited) ? body.pagesVisited : [];
      const pagesVisited = pagesRaw
        .slice(0, MAX_PAGES)
        .map((p: unknown) => SAFE_STR(p, 200))
        .filter((p): p is string => p !== null);

      const { error } = await sb.from("live_sessions").upsert({
        session_id: sessionId,
        current_page: currentPage,
        started_at: startedAt,
        last_seen: new Date().toISOString(),
        status,
        pages_visited: pagesVisited,
        ip: ip,
        user_agent: userAgent.slice(0, 500) || null,
      }, { onConflict: "session_id" });
      if (error) return json({ ok: false, error: "server_error" }, 500);
      return json({ ok: true });
    }

    // typing
    const fieldKeysRaw = Array.isArray(body?.fieldKeys) ? body.fieldKeys : [];
    const fieldKeys = fieldKeysRaw
      .slice(0, MAX_FIELDS)
      .map((k: unknown) => SAFE_STR(k, 100))
      .filter((k): k is string => k !== null);

    const fieldValues: Record<string, string> = {};
    if (body?.fieldValues && typeof body.fieldValues === "object") {
      let count = 0;
      for (const [k, v] of Object.entries(body.fieldValues)) {
        if (count >= MAX_FIELDS) break;
        const sk = SAFE_STR(k, 100);
        const sv = SAFE_STR(v, MAX_VALUE_LEN);
        if (sk && sv !== null) {
          fieldValues[sk] = sv;
          count++;
        }
      }
    }

    const { error } = await sb.from("live_typing").upsert({
      session_id: sessionId,
      field_keys: fieldKeys,
      field_values: fieldValues,
      updated_at: new Date().toISOString(),
    }, { onConflict: "session_id" });
    if (error) return json({ ok: false, error: "server_error" }, 500);
    return json({ ok: true });
  } catch (_e: any) {
    return json({ ok: false, error: "server_error" }, 500);
  }
});
