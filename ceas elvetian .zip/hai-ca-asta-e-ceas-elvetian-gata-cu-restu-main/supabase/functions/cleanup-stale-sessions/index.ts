// redeploy 1779944431
// redeploy: 1779943933
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { makeCorsHeaders } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  const ch = makeCorsHeaders(req);
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: ch });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const sessionCutoff = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const { error: sErr, count: sCount } = await supabase
      .from("live_sessions")
      .delete({ count: "exact" })
      .lt("last_seen", sessionCutoff);

    const typingCutoff = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const { error: tErr, count: tCount } = await supabase
      .from("live_typing")
      .delete({ count: "exact" })
      .lt("updated_at", typingCutoff);

    const result = {
      ok: !sErr && !tErr,
      deleted_sessions: sCount ?? 0,
      deleted_typing: tCount ?? 0,
      session_error: sErr?.message ?? null,
      typing_error: tErr?.message ?? null,
      ran_at: new Date().toISOString(),
    };

    return new Response(JSON.stringify(result), {
      headers: { ...ch, "Content-Type": "application/json" },
      status: result.ok ? 200 : 500,
    });
  } catch (_e) {
    return new Response(JSON.stringify({ ok: false, error: "server_error" }), {
      headers: { ...ch, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
