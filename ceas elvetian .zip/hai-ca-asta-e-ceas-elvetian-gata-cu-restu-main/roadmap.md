# Roadmap

- [x] Șterge panoul "Security · Attacker Control" din admin (UI + polling)
- [ ] Audit: risc de pierdere a datelor userilor (coadă/retry la salvare)
- [ ] Audit: dubluri de request la fiecare tastare + memorie
- [ ] Raport către user înainte de orice altă modificare
